"""Derive exact team151 source set, then retain local miss-only payload hop."""
from pathlib import Path
import json,hashlib,difflib
R=Path(__file__).resolve().parent
TEAM=Path('D:/FPGA/team_downloads/20261031_team_update/unpacked/FPGA_team_update_20261031/changes/FPGA_handoff_20261030/A_lens_20261030/candidate_host_angle_v2_product_stage')
SNAP=R/'FPGA_handoff_20261030/A_lens_20261030/candidate_host_angle_v2_product_stage'
OUT=R/'work_v2/candidate_team_merge1'
sha=lambda b:hashlib.sha256(b).hexdigest()
if OUT.exists():raise SystemExit('Refuse overwrite')
m=json.loads((TEAM/'project/source_manifest.json').read_text());reconstructed={};mapping={}
for n,h in m['source_sha256'].items():
 p=TEAM/'sources'/n
 if not p.exists():p=SNAP/'sources'/n
 data=p.read_bytes();variants=[data,data.replace(b'\r\n',b'\n'),data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
 exact=next(b for b in variants if sha(b)==h)
 reconstructed[n]=exact;mapping[n]={'origin':str(p),'raw_sha256':sha(data),'team_sha256':h}
assert len(reconstructed)==151
(OUT/'sources').mkdir(parents=True);(OUT/'project').mkdir()
for n,b in reconstructed.items():(OUT/'sources'/n).write_bytes(b)
p=OUT/'sources/ddr_quad_tile_cache.v';before=p.read_text();text=before
changes=[('F_PREP=4,F_SELECT=5;','F_PREP=4,F_SELECT=5,F_CAPTURE=6;'),
 ('reg[3071:0]fill_data;','reg[3071:0]fill_data;reg[3071:0]incoming_data;'),
 ("  if(!rst_n)fill_data<=0;\n  else if(fill_state==F_WRITE)fill_data<={384'd0,fill_data[3071:384]};\n  else if(fill_state==F_WAIT)fill_data<=packed_rsp_block;",
 "  if(!rst_n)begin fill_data<=0;incoming_data<=0;end\n  else begin\n   if(fill_state==F_WAIT)incoming_data<=packed_rsp_block;\n   if(fill_state==F_WRITE)fill_data<={384'd0,fill_data[3071:384]};\n   else if(fill_state==F_CAPTURE)fill_data<=incoming_data;\n  end"),
 ('else begin fill_word<=0;fill_state<=F_WRITE;watchdog<=0;end','else begin fill_word<=0;fill_state<=F_CAPTURE;watchdog<=0;end'),
 ('    F_WRITE:if(fill_word==14)begin','    F_CAPTURE:fill_state<=F_WRITE;\n    F_WRITE:if(fill_word==14)begin')]
for old,new in changes:
 assert text.count(old)==1,old
 text=text.replace(old,new)
p.write_text(text,encoding='utf-8',newline='\n')
(OUT/'cache_merge.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='team/cache',tofile='merged/cache')),encoding='utf-8')
# Keep local reviewed full-flow recipe; add no new clock/exception changes.
tcl=(R/'work_v2/candidate_v2_timing2/project/build_full.tcl').read_text().replace((R/'work_v2/candidate_v2_timing2').as_posix(),OUT.as_posix())
(OUT/'project/build_full.tcl').write_text(tcl,encoding='utf-8',newline='\n')
m.update(source_sha256={q.name:sha(q.read_bytes()) for q in (OUT/'sources').iterdir()},
 build_tcl_sha256=sha((OUT/'project/build_full.tcl').read_bytes()),qualified=False,
 merge_parent_team_manifest_sha256=sha((TEAM/'project/source_manifest.json').read_bytes()),
 merge_decision='Team13 RTL retained; local F_CAPTURE miss hop adapted4096->3072 packedRGB24. Five-stage bridge and bounded-coordinate lens stage already cover local changes.',
 hardware_accepted=False,previous_video_results_inherited=False)
(OUT/'project/source_manifest.json').write_text(json.dumps(m,indent=2),encoding='utf-8')
(OUT/'team_reconstruction.json').write_text(json.dumps(mapping,indent=2),encoding='utf-8')
print(OUT)
