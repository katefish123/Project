# Three-way cache / bridge / lens pipeline review — 2026-10-31

Read-only review. No RTL/script changes, simulation, PDS, or device access were performed. Review artifacts here are not release qualification.

## Decision for the root integrator

| File | Executable selection | Preserve / avoid |
|---|---|---|
| `quad_packet_bridge.v` | Select the complete team five-stage implementation as a new integration candidate. | It contains the local reciprocal divide stage plus a separate expected-neighbour/validation stage. Do not stack the local decode implementation on top a second time. |
| `lens_affine_instance.v` | Select the complete team implementation as a new integration candidate. | It contains the equivalent local bounded 12-bit sample/address stage plus one affine-before-Brown stage. Keep all tag/inside/error/fraction fields on those stages; do not add another duplicate sample stage. |
| `ddr_quad_tile_cache.v` | Start from the complete team cache, then deliberately port the local F_CAPTURE input hop in **packed RGB24 form**. | Keep 128 ways, 128-word row fill, two rows per tile, 192-bit even/odd RAM words, the team N stage, registered S/L match stages, invalidation fence and relookup wait. Do not resolve only the conflict markers: most team state changes are outside those blocks. |

This is a selection recommendation for new testing, not authorization to promote team sources or inherit physical qualification. No new deterministic Critical/Important packet-loss or pixel-order bug was established in the reviewed three complete team modules. The mixed conflict-marker file must never be compiled.

## Baseline and evidence identity

Team root: `D:/FPGA/team_downloads/20261031_team_update/unpacked/FPGA_team_update_20261031`.
Team source prefix (T): `changes/FPGA_handoff_20261030/A_lens_20261030/candidate_host_angle_v2_product_stage/sources`.
Local prefix (L): `D:/FPGA/host_angle_resume_20261031/work_v2/candidate_v2_timing2/sources`.
Original prefix (B): `D:/FPGA/host_angle_resume_20261031/FPGA_handoff_20261030/A_lens_20261030/candidate_host_angle_v2_product_stage/sources`.

The bundle contains no README markdown. Its `update_manifest.json` names repository `katefish123/PythonProject_update`, baseline commit `eeecd20e1b44b2984ac9aee2cdb0893ed341d9e1`, 13 RTL changes and 98 delivered files. All 98 delivered path/byte-count/SHA256 entries were independently checked and match. The recorded Git baseline blob for cache, bridge, lens and engine matches the actual original V2 source (allowing CRLF-to-LF representation). Exact SHA256s are in `PIPELINE_BINDING.json`; three independent base-to-team and local-to-team textual diffs are saved alongside this report.

`validation.json:2` says passed=true only for patch application, original remote baseline and delivered-source inventory. It is **not native PDS or release pass**. `changes/.../verification/latency_update_20261031/native_audit.json:2-18` explicitly has passed=false, qualified=false, 104 rows, setup minimum -1.302ns and hold minimum -0.766ns. Its `status.json` exit0 only records completion of the build process. `candidate.../validation_summary.json:2-7` also denies software/native/board/release qualification. No team physical success is inherited here. The parent reports all five local video cases passed; this review did not rerun or requalify them.

## Bridge: complementary fifth elastic stage

T `quad_packet_bridge.v:25-32` implements raw -> divide -> decoded -> verify -> packet. Each ready is `!valid || next_ready`, and each corresponding payload changes only under that ready, so a full downstream stall retains the entire descriptor and derived position. The forward construction uses old register values on each clock, including simultaneous consume/refill. Reset clears all five valid bits (`:68`), including the new verify stage.

The local reciprocal multiply/decode remains at T `:38-44`: 1920=128*15, quotient `(n*34953)>>19` for unsigned n in [0,65535]; the original full 24-bit address remains independently range checked. The new verify stage (`:77-85`) captures descriptor, x/y, all three 32-bit expected neighbour addresses, bad tag and range decision together. The packet stage (`:70-75`) compares those aligned fields and sticky-faults illegal descriptors while forcing inside=false. Original 32-bit neighbour equations are retained; a range check is not silently replaced by truncated x/y. Production dimensions are 1920x1080. Invalid/nonpositive parameter dimensions are outside this recommendation.

Required fresh checks: consecutive accepts through all five stages; stall at every stage; reset with all stages occupied; malformed tag/addr00/neighbours; nearest at x1919/y1079; generic non-1920 decode; abort/old-generation responses using the actual processor credit accounting. Adding one proc stage is not evidence of altered arithmetic and is not by itself a credit increase.

## Lens: complete team version subsumes local address cut

T `lens_affine_instance.v:35-53` registers affine valid/range, full 25-bit nearest+destination tag and the same 20-bit coordinate slices before Brown. It adds one cycle to the local path without changing affine arithmetic, rounding or coefficient values. Local post-Brown coordinate/address cut is present as T `:62-81`: inside is decided at original full signed width, only inside coordinates are stored in 12 bits, nearest/tag/error/fractions are captured together, and final row addresses remain the same 24-bit multiply/add equations. Moving fraction zero gating from the output edge into the sample edge is aligned to the same transaction.

These mapper stages have no ready port, so all valid bits advance each clock. The processor must reserve from issue until descriptor pop, rather than assume a fixed pipeline latency. T `frame_processor_stream.v:65-86,158-160` uses those reservation counters; the new stage must still be reset by the same math reset on abort. All affine parameters remain a caller-held frame snapshot; this change does not make live coefficient changes mid-frame safe.

Required fresh checks: RAW/nearest/bilinear, 0/90/non-integer angle, consecutive parameter commits only at legal frame boundaries, bubbles, abort during either added stage, positive/negative/outside coordinates and the original integer B pixel oracle. Current-source hashes must replace earlier local hashes. Do not describe trial R50/18mm constants as physical calibration or paper-frame correction.

## Cache: preserve both independent cuts

### What the team changes

T `ddr_quad_tile_cache.v:25-42,68-73,207-223` packs each DDR 32-bit source word's bits[23:0] into consecutive RGB24 pixels. One 128-word row is 3072 bits; every fill step consumes 384 bits (16 pixels), writing eight even pixels and eight odd pixels. `fill_word` remains 0,2,...14; memory addresses and tile dimensions are unchanged. Padding bits[31:24] are intentionally discarded, not reordered. RAM rows are 192 bits instead of 256; capacity is still 128 ways in actual top integration, not V3 cache64.

T `:95-108,230-239,263-281` adds N ownership of selected complete RAM words. M first reads/captures a boundary's left words (`read_right`), then retains phase=1 until N can accept the right words. N retains all four selected words and metadata while R is blocked. Because M may move to N in the same cycle N moves to R, non-boundary hit initiation can remain one/UI; a boundary still takes the two required read halves. A following L may reuse RAM only after M's payload is captured. A fill may start with N/R occupied because those stages own copied data, not live RAM outputs. Do not weaken `m_complete`, `m_space`, or `fill_start` to bypass those lifetimes.

T `:129-157` separately registers S and retained-L row/column matches. T `:293-308,337-338` includes two essential fences: invalidate_pending keeps new-generation lookup from consuming old valid tags, and l_lookup_wait holds retained-miss relookup until freshly installed tags have reached the registered comparison outputs. The original local design has neither registered compare stage, so copying old relookup timing would consume stale match results. Five-candidate victim order/modulo, protected-way ownership and frame-key invalidation must travel as one complete implementation.

### Why the team engine does not replace the local input hop

T `ddr_word_engine_result_burst.v:166-173` still makes `rsp_source_line` a direct concatenation of `source_cache` registers. Removing the response_kind zero mux reduces logic, and the one-hot lane write enable (`:207-218`) changes cache-write control, but neither creates a register between engine source_cache and cache fill_data. The reported old V2 path source_cache[11][73] -> fill_data[2890] was almost entirely routing delay. Team T cache `:209-210` still captures packed_rsp_block directly in WAIT, with only wires dropping padding bytes. Thus the original engine-to-cache physical hop remains, now 3072 rather than 4096 bits. Its physical improvement is unproven.

L cache `:25,47,142-148,248-252` deliberately added incoming_data and F_CAPTURE. Port the **lifetime**, not the old bit layout:

1. Declare `incoming_data[3071:0]`, retain team `fill_data[3071:0]` and packed_rsp_block wiring.
2. In F_WAIT sample incoming_data <= packed_rsp_block (sampling throughout WAIT is harmless; the actual response edge owns the retained data).
3. Judge raw mem_rsp_valid, mem_rsp_write and the existing watchdog on the original WAIT edge. Only a valid read response transitions to F_CAPTURE with fill_word=0.
4. F_CAPTURE copies incoming_data into fill_data and advances to F_WRITE.
5. F_WRITE shifts by384 and writes the team's 192-bit even/odd slices. The first write uses the copied old fill_data; the last write/fill tag/line-valid/relookup fence remain team logic.
6. Reset the extra input payload as in local implementation, and clear/hold its valid ownership through the FSM. Fault suppresses write/command/response visibility; speculative incoming payload itself does not become owned by an invalid response.

This adds one cycle per row fill relative to team cache. It deliberately changes miss timing, not response ordering or warm-hit throughput; merged full-frame timing must be measured. It might improve placement, but a zero-logic routing path can remain long on either side of an added register. No timing benefit is guaranteed.

Keeping local 4096-bit incoming_data while shifting the packed fill by384 is invalid unless explicit pack is inserted at the correct edge. Keeping team WAIT direct fill_data while blindly retaining local F_CAPTURE does not implement the intended registered two-hop data path. Reset/state definitions and both conflict regions must be resolved together.

### Tests must not claim a stronger baseline than they use

The team native/small cache testbench does check independent expected RGB vectors, response stall stability, command alignment/one owner, reset while blocked, request stalls, generation/base changes and arbitrary or X-valued high-byte padding. These are useful for RGB24 packing and N-stage output lifetime.

However `tests/component_regression/cache_native/ddr_quad_tile_cache_reference.v:95-108,217-262` already contains the packed RGB24 RAM and N stage. Therefore the `CACHE_EXTRA_STAGE_LATENCY` comparison in `cache_native/tb.sv:84-85` proves zero extra warm latency only relative to that **intermediate packed/N reference**, not original V2 or local timing2. It must not be described as an end-to-end old-V2 cycle equivalence proof. The reference also lacks the final registered match/relookup-wait change. The independent expected vectors still provide data checks, but shared structural bugs in the packed/N stage are not excluded by old/new equality.

Merged-cache acceptance should explicitly cover: non-boundary II1; boundaries at x7/127/1919 and bottom y1079; held N/R plus boundary M; fill while N/R drain; old generation in M/N while the new S changes key; first relookup after each installed row/tile; reset during F_WAIT/F_CAPTURE/F_WRITE; wrong-type response; accepted-response timeout and delayed acceptance separately; exact 128-way capacity/replacement trace; X padding ignored. Reuse existing frozen stimuli where applicable, without silently imposing original cycle counts on the new deliberate stages.

The F_CMD-or-F_WAIT watchdog condition at T `:318` is present in B `:227` and L `:233`; it is not a new team regression and not fixed by this merge. Prolonged pre-accept backpressure remains an inherited documented contract risk. Do not represent pipeline changes as a response-watchdog repair.

## Merge and promotion boundary

The merge summary's ten nonconflicting RTL files mean local==baseline so the text merge is straightforward; this is not an independent protocol approval for those ten broader changes. In particular the team engine/source-path/display/top changes must be bound to the new integrated source set and exercised together. Copying only three team files cannot inherit the team's all-source video observations; copying all thirteen cannot inherit local tests or original physical qualification.

Before promotion: freeze a new exact manifest; reject conflict markers; rerun the existing five native video modes with merged source hashes plus focused elastic/cache lifecycle checks; audit unchanged FDC/PLL/B leaf/vendor bytes and I/O; require actual complete native 104-row dual-corner timing and I/O on the final compiled project; bind final routed DB, fresh explicit same-DB STA worker report and bitgen/mask. Neither current local PDS nor team native audit is qualified by this report. No V3 cache64 performance or failed bridge bench is inherited.
