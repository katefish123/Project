import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,json,difflib
R=Path(__file__).resolve().parent
snap=R/'FPGA_handoff_20261030/A_lens_20261030'
new=R/'work_v2/candidate_team_merge1/sources'
old=snap/'candidate_host_angle_v2_product_stage/sources'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# New local copies only; original runners/evidence are left untouched.
s= (R/'cache_validation/run_cache.py').read_text()
s=s.replace("old=WORK/'candidate_v2_timing1/sources/ddr_quad_tile_cache.v';new=old if args.baseline_only else WORK/'candidate_v2_timing2/sources/ddr_quad_tile_cache.v'",f"old=Path({str(old/'ddr_quad_tile_cache.v')!r});new=old if args.baseline_only else Path({str(new/'ddr_quad_tile_cache.v')!r})")
(R/'cache_team_validation/run_cache.py').write_text(s)
s=(R/'bridge_validation/check_bridge_decode_ported.py').read_text()
line=next(l for l in s.splitlines() if l.startswith('ROOT=Path'))
s=s.replace(line,f"ROOT=Path(__file__).resolve().parent;R=Path({str(new.parent)!r});OLD=Path({str(old.parent)!r})")
(R/'bridge_team_validation/check_bridge_decode_ported.py').write_text(s)
s=(R/'bridge_validation/run_extended.py').read_text()
(R/'bridge_team_validation/run_extended.py').write_text(s)
(R/'bridge_team_validation/verification').mkdir(exist_ok=True)
manifest={'baseline_source_sha256':{n:sha(old/n) for n in ['ddr_quad_tile_cache.v','quad_packet_bridge.v']},'candidate_source_sha256':{n:sha(new/n) for n in ['ddr_quad_tile_cache.v','quad_packet_bridge.v']},'scope':'new merged modules vs immutable handoff V2 originals; no intermediate team reference','hardware_accessed':False}
(R/'cache_team_validation/preparation.json').write_text(json.dumps(manifest,indent=2)+'\n')
(R/'bridge_team_validation/preparation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
