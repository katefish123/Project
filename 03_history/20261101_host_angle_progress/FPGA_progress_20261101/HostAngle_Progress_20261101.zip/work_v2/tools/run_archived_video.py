"""Rerun SHA-bound archived V2 benches with freshly regenerated exact fixtures.

Original tb_1080p30.sv is absent. This deliberately named migration runner
rebinds only six readmemh paths, preserving archived scoreboard/DDR/deadlines.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import argparse,datetime,hashlib,json,re,shutil,subprocess,time,difflib
import check_lens_video as oracle
ROOT=Path(__file__).resolve().parents[1]
SNAP=ROOT.parent/'FPGA_handoff_20261030/A_lens_20261030'
TOOLS=Path('D:/softwares/modelsim/win64')
CASES={
 'zero':('video_20261030_135116_949527_71c14726',0,None,False,False),
 'ninety':('video_20261030_135116_949527_a6d685fb',90,None,False,False),
 'switch':('video_20261030_135116_965544_57108aba',0,90,False,False),
 'raw':('video_20261030_135942_518802_be4a8060',0,None,True,False),
 'nearest':('video_20261030_135942_519642_30d8ed4b',12,None,False,True),
}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def bound_json(path,expected):
 data=path.read_bytes()
 options=[data,data.replace(b'\r\n',b'\n'),data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
 matched=next(b for b in options if hashlib.sha256(b).hexdigest()==expected)
 return json.loads(matched),{'path':str(path),'snapshot_sha256':sha(path),'canonical_sha256':expected}

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--case',choices=CASES,required=True)
 a=ap.parse_args();candidate=a.candidate.resolve()
 archive,angle,alt,raw,nearest=CASES[a.case]
 old=SNAP/'verification'/archive;historical=json.loads((old/'verification.json').read_text())
 expected={'angle_deg':angle,'alternating_angle_deg':alt,'raw':raw,'nearest':nearest,'frames':6,'pixel_phase_ns':0,'measurement_only':False}
 assert all(historical['parameters'][n]==v for n,v in expected.items())
 original=old/'tb_lens_video.sv';data=original.read_bytes()
 historical_fixtures,fixture_root_binding=bound_json(old/'fixtures.json',historical['fixtures_sha256'])
 # Git may have checked a text file out as CRLF. Recover only known bytes.
 options=[data,data.replace(b'\r\n',b'\n'),data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
 data=next(b for b in options if hashlib.sha256(b).hexdigest()==historical['bench_sha256'])
 original_text=data.decode('utf-8').replace('\r\n','\n')
 manifest=candidate/'project/source_manifest.json'
 hashes={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
 assert hashes==json.loads(manifest.read_text())['source_sha256']
 out=ROOT/'verification'/('archived_video_'+a.case+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
 out.mkdir();print('ARCHIVED_VIDEO '+str(out),flush=True)
 oracle.CANDIDATE=candidate
 oracle.CALIBRATION=ROOT/'calibration/r50_18mm_hdmi_trial.json'
 primary=out/'primary';primary.mkdir();oracle.fixtures(primary,angle,nearest)
 alternate=primary
 if alt is not None:
  alternate=out/'alternate';alternate.mkdir();oracle.fixtures(alternate,alt,nearest)
 fixture_binding={}
 for label,folder in [('primary',primary),('alternate',alternate)]:
  historical_folder=old/('alternate' if label=='alternate' and alt is not None else 'primary')
  key='alternate_sha256' if label=='alternate' else 'primary_sha256'
  f,child_binding=bound_json(historical_folder/'fixtures.json',historical_fixtures[key])
  # All simulation inputs must be byte-identical, not just visually similar.
  for name in ('source.hex','expected.hex','H40.hex'):
   assert sha(folder/name)==f['files'][name],(label,name)
  fixture_binding[label]={'generated_record_sha256':sha(folder/'fixtures.json'),
      'historical_record':str(historical_folder/'fixtures.json'),'historical_record_sha256':sha(historical_folder/'fixtures.json'),
      'historical_chain_binding':child_binding,
      'exact_simulation_files':{n:sha(folder/n) for n in ('source.hex','expected.hex','H40.hex')}}
 paths={'source_fixture':primary/'source.hex','source_alt':alternate/'source.hex',
  'expected_fixture':primary/'expected.hex','expected_alt':alternate/'expected.hex',
  'expected_h':primary/'H40.hex','expected_h_alt':alternate/'H40.hex'}
 def remap(m):
  array=m[2];assert array in paths
  return '$readmemh("'+paths[array].as_posix()+'",'+array+');'
 text,count=re.subn(r'\$readmemh\("([^"]+)",(\w+)\);',remap,original_text)
 assert count==6
 test=out/'tb_lens_video.sv';test.write_text(text,encoding='utf-8',newline='\n')
 (out/'archived_bench.original.sv').write_bytes(data)
 (out/'path_only.diff').write_text(''.join(difflib.unified_diff(original_text.splitlines(True),text.splitlines(True))),encoding='utf-8')
 shutil.copyfile(Path(__file__),out/'runner_snapshot.py')
 ini=out/'modelsim.ini';shutil.copyfile(TOOLS.parent/'modelsim.ini',ini)
 excluded={'ddr3_ip.v','ddr3_ip_ddrphy_top.v','ddr3_ip_slice_top_v1_10.v','config_pll_27m_10m.v','video_pll_27m_148m5.v'}
 files=sorted(p for p in (candidate/'sources').glob('*.v') if p.name not in excluded)
 record={'scope':__doc__,'case':a.case,'parameters':expected,'candidate':str(candidate),
  'source_sha256':hashes,'manifest_sha256':sha(manifest),'archive_bench_sha256':hashlib.sha256(data).hexdigest(),
  'archive_report_sha256':sha(old/'verification.json'),'bench_sha256':sha(test),'runner_sha256':sha(Path(__file__)),
  'oracle_tool_sha256':sha(Path(oracle.__file__)),'fixtures':fixture_binding,'historical_fixture_root':fixture_root_binding,'hardware_accessed':False}
 (out/'inputs.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
 executions=[];start=time.monotonic()
 def run(argv,log):
  args=[v.as_posix() if isinstance(v,Path) else str(v) for v in argv]
  with (out/log).open('w',encoding='utf-8') as f:
   p=subprocess.run(args,cwd=out,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
  executions.append({'argv':args,'cwd':str(out),'exit_code':p.returncode,'log':log,'log_sha256':sha(out/log)})
  (out/'execution.json').write_text(json.dumps(executions,indent=2),encoding='utf-8')
  if p.returncode:raise RuntimeError(log)
 run([TOOLS/'vlib.exe',out/'work'],'library.log')
 run([TOOLS/'vmap.exe','-modelsimini',ini,'work',out/'work'],'mapping.log')
 run([TOOLS/'vlog.exe','-sv','-modelsimini',ini,*files,test],'compile.log')
 do=out/'run.do';do.write_text('onerror {quit -code 2 -f}\nonbreak {resume}\nonfinish stop\nrun -all\nquit -f\n')
 failure=None
 try:run([TOOLS/'vsim.exe','-modelsimini',ini,'-c','-voptargs=+acc=r+tb_raw_pipeline','-gFRAMES=6',
    '-gCORRECTED='+str(int(not raw)),'-gRGB_PATTERN='+str(int(raw)),'work.tb_raw_pipeline','-do',do],'simulation.log')
 except RuntimeError as e:failure=str(e)
 output=(out/'simulation.log').read_text(errors='replace');compiled=(out/'compile.log').read_text(errors='replace')
 stable=hashes=={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
 match=re.search(r'FRESH30_RESULT swaps=(\d+) first_ns=(\d+) last_ns=(\d+) max_gap_ns=(\d+)',output)
 fresh=dict(zip(['swaps','first_ns','last_ns','max_gap_ns'],map(int,match.groups()))) if match else None
 clean=not re.search(r'\*\* (?:Fatal|Error|Warning)(?:\s|:)',output+compiled)
 passed=bool(not failure and stable and clean and 'PASS LENS_ANGLE_VIDEO' in output and fresh and fresh['swaps']>=6 and fresh['max_gap_ns']<=33333500)
 result={'passed':passed,'qualifies_simulated_30fps':passed,'hardware_accessed':False,
  'case':a.case,'candidate':str(candidate),'source_sha256':hashes,'inputs_sha256':sha(out/'inputs.json'),
  'execution_sha256':sha(out/'execution.json'),'sources_unchanged':stable,'freshness':fresh,'failure':failure,
  'bench_kind':'archived derived V2 bench, six path substitutions only; absent original bench not recovered',
  'simulation_log_sha256':sha(out/'simulation.log'),'compile_log_sha256':sha(out/'compile.log'),
  'elapsed_seconds':time.monotonic()-start,'observations':[s for s in output.splitlines() if any(n in s for n in ('FRESH','PASS ','ANGLE_FRAME_DONE','** Fatal','** Error','** Warning'))]}
 (out/'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps({k:result[k] for k in ('passed','case','freshness','failure','elapsed_seconds','observations')},indent=2),flush=True);raise SystemExit(0 if passed else 1)

if __name__=='__main__':main()
