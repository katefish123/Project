"""Offline actual-report and mutation checks for the relocated native auditor."""
from pathlib import Path
import json,tempfile
import audit_resume_native as a

def rejected(call):
 try:call()
 except ValueError:return
 raise RuntimeError('Invalid evidence accepted')

rejected(lambda:a.timing(a.COVERAGE))
current=a.io(a.ARCHIVE/'place_route/video_correct_ddr_top.prr',a.ARCHIVE/'place_route/video_correct_ddr_top_prr.prt')
assert current['passed'] and current['pad_count']==144
text=a.COVERAGE.read_text(errors='replace')
a.clocks(text)
rejected(lambda:a.clocks(text.replace('| Speed Grade  : -6','| Speed Grade  : -5')))
rejected(lambda:a.clocks(text.replace('10.7740','20.7740')))
for mutation in (text.replace('Hold Summary(Fast Corner):','Hold Summary(Fast MUTANT):'),
                 text.replace('Setup Summary(Slow Corner):','Setup Summary(Slow MUTANT):')):
 rejected(lambda:a.parser.timing_rows(mutation,False))
with tempfile.TemporaryDirectory(prefix='resume_audit_') as folder:
 prr=Path(folder)/'bad.prr';prt=Path(folder)/'bad.prt'
 original_prr=(a.ARCHIVE/'place_route/video_correct_ddr_top.prr').read_text()
 original_prt=(a.ARCHIVE/'place_route/video_correct_ddr_top_prr.prt').read_text()
 assert 'B24' in original_prr and 'B24' in original_prt
 prr.write_text(original_prr.replace('B24','B23'));prt.write_text(original_prt)
 rejected(lambda:a.io(prr,prt))
print(json.dumps({'passed':True,'archived_144_io_reparsed':True,'actual_failed_timing_rejected':True,'missing_corner_mutations_rejected':2,'wrong_uart_pad_rejected':True}))
