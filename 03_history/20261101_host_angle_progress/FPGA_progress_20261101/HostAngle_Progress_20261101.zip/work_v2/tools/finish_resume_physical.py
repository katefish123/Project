"""Freeze the actual routed DB and use it for fresh bitgen and direct STA.

Offline only. Refuses an unfinished or failing native build. No seed project
is copied, so archived relative RCF paths cannot leak into this independent run.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Optimized execution forbidden')
import argparse,datetime,hashlib,json,re,shutil,subprocess,time
import audit_resume_native as audit
TOOL=Path('D:/softwares/PDS/PDS_2022.2-SP6.4/bin/pds_shell.exe')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def require(ok,message):
 if not ok:raise RuntimeError(message)

def selected(project,command,folder):
 text=project.read_text(errors='replace')
 section=text.split('(_command '+command,1)[1].split('(_widget',1)[0]
 matches=re.findall(r'\(_option input_db_file\s+\(_file "([^"]+)"',section)
 require(len(matches)==1,'No unique explicit DB for '+command)
 return (folder/matches[0]).resolve()

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--build',type=Path,required=True)
 ap.add_argument('--route-output',type=Path)
 a=ap.parse_args();build=a.build.resolve();candidate=build.parents[1]
 manifest=candidate/'project/source_manifest.json';m=json.loads(manifest.read_text())
 current=audit.source_identity(candidate)
 require(current==m['source_sha256'],'Sources changed')
 record=json.loads((build/'offline_build_inputs.json').read_text())
 require(record['status']=='completed' and record['returncode']==0 and record['sources_unchanged'],'Build unfinished')
 require(record['source_sha256']==current and record['manifest_sha256']==sha(manifest),'Build source identity mismatch')
 require(record['build_tcl_sha256']==sha(candidate/'project/build_full.tcl') and record['log_sha256']==sha(build/'build.log'),'Build recipe drift')
 up=a.route_output.resolve() if a.route_output else build
 route_inputs=[]
 if a.route_output:
  binding=up/'route_binding.json';rv=json.loads(binding.read_text())
  ex=up/'route_execution.json';ee=json.loads(ex.read_text())
  require(ee['exit_code']==0 and ee['inputs_unchanged'] and ee['binding_sha256']==sha(binding),'Route execution invalid')
  require(rv['source_manifest_sha256']==sha(manifest),'Route source identity mismatch')
  mandatory={'mapped_database':build/'device_map/video_correct_ddr_top_map.adf',
    'placed_database':build/'place_route/video_correct_ddr_top_plc.adf',
    'pcf':build/'device_map/video_correct_ddr_top.pcf'}
  require(set(rv['inputs'])==set(mandatory)|{'user_rcf'},'Unreviewed routing input inventory')
  require(Path(rv['upstream_build']).resolve()==build,'Wrong route parent build')
  route_text=(up/'route.tcl').read_text()
  from route_resume_whole_net import expected_script
  require(route_text==expected_script(candidate,rv['inputs']),'Route full recipe/header changed')
  for role,origin in mandatory.items():
   item=rv['inputs'][role]
   require(Path(item['origin']).resolve()==origin.resolve(),'Wrong mapped/placed/PCF parent '+role)
   option={'mapped_database':'-input_db_file','placed_database':'-input_place_db_file','pcf':'add_constraint'}[role]
   require(option+' {'+Path(item['copy']).as_posix()+'}' in route_text,'Route script does not select frozen '+role)
  rcf=rv['inputs']['user_rcf'];net='memory_ip/u_ddrphy_top/ddrphy_slice_top/all_group_ca_dly'
  require(Path(rcf['copy']).read_bytes()==('def_route -prior_net {'+net+'}\n').encode('ascii'),'Unreviewed user routing constraint')
  require('add_constraint {'+Path(rcf['copy']).as_posix()+'}' in route_text,'RCF not selected')
  for item in rv['inputs'].values():
   require(sha(Path(item['copy']))==item['sha256']==sha(Path(item['origin'])),'Route recipe input drift')
   route_inputs.extend((Path(item['copy']),Path(item['origin'])))
  route_inputs += [binding,ex,up/'route.tcl',up/'route.log',up/'Resume_Route.pds']
  require(ee['route_tcl_sha256']==sha(up/'route.tcl') and ee['log_sha256']==sha(up/'route.log'),'Route control drift')
  require(ee['whole_net_priority_parsed'] is True,'User routing constraint not parsed')
 timing_report=up/'report_timing/video_correct_ddr_top.rtr'
 audit.timing(timing_report)
 audit.io(up/'place_route/video_correct_ddr_top.prr',up/'place_route/video_correct_ddr_top_prr.prt')
 project=build/'Lens_Angle_1080p30.pds'
 paths=re.findall(r'_file "([^"]*sources/[^"]+)"',project.read_text(errors='replace'))
 compiled={(build/n).resolve().name:sha((build/n).resolve()) for n in paths}
 require(len(paths)==151 and compiled==current,'Compiled project input inventory differs')
 route_db=up/'place_route/video_correct_ddr_top_pnr.adf'
 require(route_db.is_file(),'Final actual routed DB absent')
 out=candidate/'independent_check'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
 (out/'inputs').mkdir(parents=True,exist_ok=False)
 files=[route_db,build/'device_map/video_correct_ddr_top.pcf',project,
        build/'offline_build_inputs.json',build/'build.log',candidate/'project/build_full.tcl',timing_report,
        up/'place_route/video_correct_ddr_top.prr',up/'place_route/video_correct_ddr_top_prr.prt',
        build/'device_map/video_correct_ddr_top_map.adf',build/'place_route/video_correct_ddr_top_plc.adf',*route_inputs]
 files=list(dict.fromkeys(files));copies={}
 for i,p in enumerate(files):
  dest=out/'inputs'/(str(i)+'_'+p.name);shutil.copyfile(p,dest)
  require(sha(dest)==sha(p),'Copy drift')
  copies[str(p)]={'copy':str(dest),'sha256':sha(dest)}
 db=Path(copies[str(route_db)]['copy']);pcf=Path(copies[str(build/'device_map/video_correct_ddr_top.pcf')]['copy'])
 script=(candidate/'project/build_full.tcl').read_text().split('compile -top_module')[0]
 script+='add_constraint {'+pcf.as_posix()+'}\n'
 script+='report_timing -force_to_run -input_db_file {'+db.as_posix()+'}\n'
 script+='gen_bit_stream -force_to_run -input_db_file {'+db.as_posix()+'} -create_mask_file TRUE -enable_mask_variable_memory_in_read_back TRUE\n'
 tcl=out/'finish.tcl';tcl.write_text(script,encoding='utf-8',newline='\n')
 binding={'source_sha256':current,'source_manifest':str(manifest),'source_manifest_sha256':sha(manifest),
   'compiled_inputs':compiled,'copies':copies,'explicit_db':str(db),'explicit_db_sha256':sha(db),
   'finish_tcl_sha256':sha(tcl),'driver_sha256':sha(Path(__file__)),'upstream_build':str(build),
   'upstream_route':str(up),'source_constraint_identity':'unchanged original V2 board_ddr.fdc',
   'hardware_accessed':False}
 state=out/'input_binding.json';state.write_text(json.dumps(binding,indent=2),encoding='utf-8')
 print('INDEPENDENT_PHYSICAL '+str(out),flush=True)
 executions=[];started=time.monotonic()
 def run(argv,name):
  args=[v.as_posix() if isinstance(v,Path) else str(v) for v in argv]
  with (out/name).open('w',encoding='utf-8') as f:
   result=subprocess.run(args,cwd=out,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
  executions.append({'argv':args,'cwd':str(out),'exit_code':result.returncode,'log':name,'log_sha256':sha(out/name)})
  (out/'processes.json').write_text(json.dumps(executions,indent=2),encoding='utf-8')
  require(result.returncode==0,'Failed '+name)
 run([TOOL,'-project_name','Independent_V2','-work_dir',out,'-file',tcl],'shell.log')
 require('Process "Generate Bitstream" done.' in (out/'shell.log').read_text(errors='replace'),'Fresh bitgen action did not complete')
 independent_project=out/'Independent_V2.pds'
 for command in ('cmd_report_post_pnr_timing','cmd_gen_bitstream'):
  require(selected(independent_project,command,out)==db.resolve(),'STA/bitgen DB differs')
 root_report=out/'video_correct_ddr_top.rtr'
 require(not root_report.exists(),'Refuse preexisting direct-worker report')
 before=sha(independent_project)
 shutil.copyfile(independent_project,out/'project_before_worker.pds')
 run([TOOL,'-action','report_timing','-project_file',independent_project],'worker.log')
 require('Report timing is finished successfully.' in (out/'worker.log').read_text(errors='replace'),'No direct STA completion')
 require(root_report.is_file() and root_report.stat().st_size>1000,'No fresh direct-worker report')
 tr=audit.timing(root_report)
 for original,v in copies.items():require(sha(Path(original))==v['sha256']==sha(Path(v['copy'])),'Physical input drift')
 require(current=={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()},'Source drift')
 require(sha(tcl)==binding['finish_tcl_sha256'] and sha(manifest)==binding['source_manifest_sha256'],'Recipe drift')
 bits=list((out/'generate_bitstream').glob('*.sbit'));masks=list((out/'generate_bitstream').glob('*.smsk'))
 require(len(bits)==len(masks)==1,'Paired final image absent')
 require(bits[0].stem==masks[0].stem,'Mask/image naming differs')
 require(bits[0].stat().st_size>1024*1024 and masks[0].stat().st_size>1024*1024,'Truncated/empty configuration image')
 artifact={p.name:{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in (bits[0],masks[0],db,root_report,independent_project)}
 result={'passed':True,'fresh_direct_worker_report':True,'same_explicit_db_for_sta_and_bitgen':True,
    'input_binding_sha256':sha(state),'processes_sha256':sha(out/'processes.json'),
    'project_before_worker_sha256':before,'project_after_worker_sha256':sha(independent_project),
    'timing':tr,'artifacts':artifact,'elapsed_seconds':time.monotonic()-started,'hardware_accessed':False,
    'auditor_sha256':sha(Path(audit.__file__)),'parser_sha256':sha(Path(audit.parser.__file__)),
    'archived_coverage_sha256':sha(audit.COVERAGE),
    'archived_io_audit_sha256':sha(audit.ARCHIVE/'native_audit.json')}
 (out/'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print('INDEPENDENT_SAME_DB_PASS min_slack='+str(tr['minimum_slack_ns']),flush=True)

if __name__=='__main__':main()
