"""Package only an already-emitted, freshly reverified offline qualification."""
from pathlib import Path,PureWindowsPath
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Optimized packaging forbidden')
import argparse,json,hashlib,shutil,zipfile,subprocess,re
from qualify_merged import qualify,require
from check_release_package import check
ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--physical',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 c=a.candidate.resolve();out=a.output.resolve();archive=out.with_suffix('.zip')
 require(not out.exists() and not archive.exists(),'Refusing package overwrite')
 qp=c/'candidate_qualification.json';require(qp.is_file(),'No emitted qualification')
 q=json.loads(qp.read_text());require(q==qualify(c,a.physical.resolve()),'Qualification drift/verification failed')
 out.mkdir();(out/'burn').mkdir();(out/'evidence/blobs').mkdir(parents=True)
 shutil.copyfile(qp,out/'candidate_qualification.json')
 shutil.copytree(c/'sources',out/'candidate_v2_resume/sources')
 shutil.copytree(c/'project',out/'candidate_v2_resume/project')
 # A source-only PDS entry with relative source paths accompanies the qualified
 # prebuilt image. Creating this entry performs no compile/place/route action.
 project_dir=out/'candidate_v2_resume/project'
 original=(c/'project/build_full.tcl').read_text()
 first,rest=original.split('\n',1)
 require(first.startswith('set root '),'Unknown original project root statement')
 local_root='set root [file normalize [file join [file dirname [info script]] ..]]\n'
 (project_dir/'rebuild_full.tcl').write_text(local_root+rest,encoding='utf-8',newline='\n')
 prepare=project_dir/'open_sources.tcl'
 prepare.write_text(local_root+rest.split('compile -top_module')[0],encoding='utf-8',newline='\n')
 argv=['D:/softwares/PDS/PDS_2022.2-SP6.4/bin/pds_shell.exe','-project_name','HostAngleV2','-work_dir',project_dir.as_posix(),'-file',prepare.as_posix()]
 with (project_dir/'create_project.log').open('w',encoding='utf-8') as log:
  result=subprocess.run(argv,cwd=project_dir,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 require(result.returncode==0,'Source-only project creation failed')
 source_project=project_dir/'HostAngleV2.pds'
 names=re.findall(r'_file "([^"]*sources/[^"]+)"',source_project.read_text(errors='replace'))
 require(all(not Path(n).is_absolute() and not PureWindowsPath(n).drive for n in names),'Portable project contains absolute source paths')
 require(len(names)==151 and {(project_dir/n).resolve().name:sha((project_dir/n).resolve()) for n in names}==q['source_sha256'],'Portable PDS source inventory differs')
 (project_dir/'entry_provenance.json').write_text(json.dumps({'source_only_project':True,'new_rebuild_qualified':False,
    'argv':argv,'exit_code':result.returncode,'log_sha256':sha(project_dir/'create_project.log'),
    'original_qualified_build_tcl_sha256':sha(c/'project/build_full.tcl'),
    'portable_rebuild_tcl_sha256':sha(project_dir/'rebuild_full.tcl'),
    'source_project_sha256':sha(source_project),'source_sha256':q['source_sha256']},indent=2),encoding='utf-8')
 shutil.copytree(ROOT/'calibration',out/'calibration')
 (out/'tools').mkdir()
 for p in (ROOT/'tools').glob('*.py'):shutil.copyfile(p,out/'tools'/p.name)
 mapping={}
 for origin,h in q['artifact_sha256'].items():
  p=Path(origin);require(sha(p)==h,'Evidence drift during copy')
  relative='evidence/blobs/'+h+'_'+p.name;dest=out/relative
  if not dest.exists():shutil.copyfile(p,dest)
  require(sha(dest)==h,'Evidence copy differs');mapping[origin]=relative
 (out/'evidence/path_map.json').write_text(json.dumps(mapping,indent=2),encoding='utf-8')
 program={'qualified_for_board_test':True,'hardware_accepted':False,'allowed_mode':'CRAM Program+Verify only','flash_allowed':False,'artifacts':{}}
 for role in ('sbit','smsk'):
  item=q['artifacts'][role];p=Path(item['path']);dest=out/'burn'/p.name;shutil.copyfile(p,dest)
  require(sha(dest)==item['sha256'],'Programming copy drift')
  program['artifacts'][role]={'relative_path':dest.relative_to(out).as_posix(),'sha256':sha(dest),'bytes':dest.stat().st_size}
 (out/'programming_manifest.json').write_text(json.dumps(program,indent=2),encoding='utf-8')
 (out/'README.md').write_text('# 全高清镜头校正＋上位机角度控制：待实板验收\n\n本包只完成离线资格，不代表实板或光学验收完成。目标1920×1080、30张新校正帧/秒。烧录只使用burn目录中成对文件，按programming_manifest.json核对SHA，模式限CRAM Program+Verify；不写Flash。\n\n源码在candidate_v2_resume/sources，PDS源码工程入口是candidate_v2_resume/project/HostAngleV2.pds，全部151份源和必要IP以包内相对路径绑定。该源码入口仅方便查看和重建；直接验收使用已合格的burn文件。rebuild_full.tcl保留原构建参数，仅将工程根目录改为包内相对路径；重建后的新产物仍须重新检查时序，不继承本包资格。\n\n原始构建配方和独立物理数据库、完整时序/IO、当前源回归证据通过evidence/path_map.json映射到不可变文件；原始绝对路径用于出处，不能冒充其它机器已重建。工具安装路径仍需按本机适配。\n\n标定属于R50/18mm试标定，独立实拍光学、端到端延迟及板端30秒新帧率验收仍待完成。\n',encoding='utf-8')
 files={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()}
 (out/'package_manifest.json').write_text(json.dumps({'files':files,'source_qualification_sha256':sha(qp)},indent=2),encoding='utf-8')
 check(out)
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
  for p in out.rglob('*'):
   if p.is_file():z.write(p,p.relative_to(out).as_posix())
 result=check(out,archive);result.update(zip_sha256=sha(archive),sbit_sha256=program['artifacts']['sbit']['sha256'],package=str(out));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
