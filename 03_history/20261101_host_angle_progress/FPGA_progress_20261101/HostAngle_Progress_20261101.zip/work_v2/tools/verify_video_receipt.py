"""Read-only final closure of a new archived-bench video run. No simulation."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Optimized evidence verification forbidden')
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
SNAP=ROOT.parent/'FPGA_handoff_20261030/A_lens_20261030'
CASES={
 'zero':('video_20261030_135116_949527_71c14726',0,None,False,False),
 'ninety':('video_20261030_135116_949527_a6d685fb',90,None,False,False),
 'switch':('video_20261030_135116_965544_57108aba',0,90,False,False),
 'raw':('video_20261030_135942_518802_be4a8060',0,None,True,False),
 'nearest':('video_20261030_135942_519642_30d8ed4b',12,None,False,True),
}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def require(v,msg):
 if not v:raise ValueError(msg)
def canonical(path,expected):
 data=path.read_bytes()
 for b in (data,data.replace(b'\r\n',b'\n'),data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')):
  if hashlib.sha256(b).hexdigest()==expected:return b
 raise ValueError('Archived hash mismatch '+str(path))

def verify(folder,current,case):
 folder=Path(folder);v=read(folder/'verification.json');i=read(folder/'inputs.json')
 require(v['passed'] is True and v['qualifies_simulated_30fps'] is True,'Run did not pass')
 require(v['case']==i['case']==case,'Wrong scenario')
 require(v['source_sha256']==i['source_sha256']==current and v['sources_unchanged'] is True,'Source identity differs')
 require(sha(folder/'inputs.json')==v['inputs_sha256'],'Inputs drift')
 ex=read(folder/'execution.json')
 require(sha(folder/'execution.json')==v['execution_sha256'] and len(ex)==4,'Execution drift/missing processes')
 require([Path(e['argv'][0]).name.lower() for e in ex]==['vlib.exe','vmap.exe','vlog.exe','vsim.exe'],'Unexpected simulator commands')
 for e in ex:require(e['exit_code']==0 and sha(folder/e['log'])==e['log_sha256'],'Nonzero exit or log drift')
 require(sha(folder/'simulation.log')==v['simulation_log_sha256'] and sha(folder/'compile.log')==v['compile_log_sha256'],'Verification log drift')
 simulation=(folder/'simulation.log').read_text(errors='replace');compile=(folder/'compile.log').read_text(errors='replace')
 require(not re.search(r'\*\* (?:Fatal|Error|Warning)(?:\s|:)',simulation+compile),'Simulation error/warning present')
 archive,angle,alt,raw,nearest=CASES[case];old=SNAP/'verification'/archive
 historical=read(old/'verification.json')
 require(sha(old/'verification.json')==i['archive_report_sha256'],'Historical report drift')
 expected={'angle_deg':angle,'alternating_angle_deg':alt,'raw':raw,'nearest':nearest,'frames':6,'pixel_phase_ns':0,'measurement_only':False}
 require(i['parameters']==expected,'Scenario parameters drift')
 require(all(historical['parameters'][n]==val for n,val in expected.items()),'Archive scenario mismatch')
 original=canonical(old/'tb_lens_video.sv',historical['bench_sha256'])
 require(hashlib.sha256(original).hexdigest()==i['archive_bench_sha256'],'Original bench binding differs')
 aggregate=json.loads(canonical(old/'fixtures.json',historical['fixtures_sha256']))
 anchors={str(p):sha(p) for p in (old/'verification.json',old/'tb_lens_video.sv',old/'fixtures.json')}
 artifacts={}
 for label in ('primary','alternate'):
  name='alternate' if label=='alternate' and alt is not None else 'primary'
  source=old/name/'fixtures.json'
  child=json.loads(canonical(source,aggregate[label+'_sha256']))
  anchors[str(source)]=sha(source)
  actual=folder/name
  for file in ('source.hex','expected.hex','H40.hex'):
   require(sha(actual/file)==child['files'][file]==i['fixtures'][label]['exact_simulation_files'][file],'Golden fixture drift')
   artifacts[str(actual/file)]=sha(actual/file)
  require(sha(actual/'fixtures.json')==i['fixtures'][label]['generated_record_sha256'],'Generated fixture record drift')
  generated=read(actual/'fixtures.json');image=Path(generated['source_image'])
  require(sha(image)==generated['source_image_sha256'],'Original image drift');anchors[str(image)]=sha(image)
  for n,h in generated['reference_sha256'].items():
   require(sha(Path(n))==h,'Golden reference code drift');anchors[n]=h
 paths={'source_fixture':folder/'primary/source.hex','source_alt':folder/('alternate/source.hex' if alt is not None else 'primary/source.hex'),
 'expected_fixture':folder/'primary/expected.hex','expected_alt':folder/('alternate/expected.hex' if alt is not None else 'primary/expected.hex'),
 'expected_h':folder/'primary/H40.hex','expected_h_alt':folder/('alternate/H40.hex' if alt is not None else 'primary/H40.hex')}
 def sub(m):
  require(m[2] in paths,'Unexpected memory fixture')
  return '$readmemh("'+paths[m[2]].as_posix()+'",'+m[2]+');'
 target,count=re.subn(r'\$readmemh\("([^"]+)",(\w+)\);',sub,original.decode().replace('\r\n','\n'))
 require(count==6 and (folder/'tb_lens_video.sv').read_text()==target,'More than six path changes in bench')
 require(sha(folder/'tb_lens_video.sv')==i['bench_sha256'],'Bench bytes drift')
 require(sha(folder/'runner_snapshot.py')==i['runner_sha256'],'Runner snapshot drift')
 require(sha(ROOT/'tools/check_lens_video.py')==i['oracle_tool_sha256'],'Oracle code drift')
 require((folder/'run.do').read_text()=='onerror {quit -code 2 -f}\nonbreak {resume}\nonfinish stop\nrun -all\nquit -f\n','Execution control drift')
 candidate=Path(i['candidate']);require(read(candidate/'project/source_manifest.json')['source_sha256']==current,'Candidate manifest differs')
 require(sha(candidate/'project/source_manifest.json')==i['manifest_sha256'],'Manifest bytes drift')
 actual={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
 require(actual==current,'Current sources drift')
 excluded={'ddr3_ip.v','ddr3_ip_ddrphy_top.v','ddr3_ip_slice_top_v1_10.v','config_pll_27m_10m.v','video_pll_27m_148m5.v'}
 files=sorted(p for p in (candidate/'sources').glob('*.v') if p.name not in excluded)
 compile_files=[Path(p).resolve() for p in ex[2]['argv'] if p.endswith(('.v','.sv'))]
 require(compile_files==[p.resolve() for p in files]+[(folder/'tb_lens_video.sv').resolve()],'Compiled RTL differs')
 args=ex[-1]['argv']
 for option in ('-gFRAMES=6','-gCORRECTED='+str(int(not raw)),'-gRGB_PATTERN='+str(int(raw)),'work.tb_raw_pipeline'):
  require(option in args,'Actual scenario option missing')
 match=re.search(r'FRESH30_RESULT swaps=(\d+) first_ns=(\d+) last_ns=(\d+) max_gap_ns=(\d+)',simulation)
 require(bool(match),'No actual fresh-frame result')
 fresh=dict(zip(('swaps','first_ns','last_ns','max_gap_ns'),map(int,match.groups())))
 require(fresh==v['freshness'] and fresh['swaps']>=6 and fresh['max_gap_ns']<=33333500,'Fresh-frame deadline failed')
 result=re.search(r'PASS LENS_ANGLE_VIDEO corrected=(\d+) native=1 pixels=(\d+) unique_scans=(\d+) published=(\d+)',simulation)
 require(bool(result) and int(result[1])==int(not raw) and int(result[2])>=12441600 and int(result[3])>=6 and int(result[4])>=6,'Missing native pixel/publication coverage')
 for p in (folder/'verification.json',folder/'inputs.json',folder/'execution.json',folder/'simulation.log',folder/'compile.log',folder/'run.do',folder/'modelsim.ini',folder/'runner_snapshot.py',folder/'tb_lens_video.sv'):
  artifacts[str(p)]=sha(p)
 return {'passed':True,'case':case,'freshness':fresh,'pixels':int(result[2]),'artifact_sha256':artifacts,'golden_anchor_sha256':anchors,
  'compile_exclusions':sorted(excluded),'scope':'Current custom RTL simulation; vendor PHY/FDC tracked for identity only; no hardware qualification'}
