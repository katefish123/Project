"""One causal route-only experiment from completed, failing native build.

No source, placement input, clock or timing-exception change. Default prepares
nothing; --run is explicit and refuses an incomplete or passing original build.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Optimized execution forbidden')
import argparse,json,hashlib,re,shutil,subprocess,time
import audit_resume_native as audit
TOOL=Path('D:/softwares/PDS/PDS_2022.2-SP6.4/bin/pds_shell.exe')
NET='memory_ip/u_ddrphy_top/ddrphy_slice_top/all_group_ca_dly'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def require(v,msg):
 if not v:raise ValueError(msg)

def expected_script(candidate,inputs):
 script=(candidate/'project/build_full.tcl').read_text().split('compile -top_module')[0]
 for role in ('pcf','user_rcf'):script+='add_constraint {'+Path(inputs[role]['copy']).as_posix()+'}\n'
 script+='pnr -force_to_run -input_db_file {'+Path(inputs['mapped_database']['copy']).as_posix()+'} -input_place_db_file {'+Path(inputs['placed_database']['copy']).as_posix()+'} -mode performance -groute_seed 91 -optimize_multi_corner_timing -slack_prior_in_global_router TRUE -enable_route_constraint_iterate -route_constraint_iterate_times 3 -route_constraint_slack 0.3 -fix_hold_violation_threshold 50\nreport_timing\ngen_bit_stream -create_mask_file TRUE -enable_mask_variable_memory_in_read_back TRUE\n'
 return script

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--build',type=Path,required=True);ap.add_argument('--run',action='store_true');a=ap.parse_args()
 build=a.build.resolve();candidate=build.parents[1];manifest=candidate/'project/source_manifest.json'
 current=audit.source_identity(candidate);record=json.loads((build/'offline_build_inputs.json').read_text())
 require(record['status']=='completed' and record['returncode']==0 and record['sources_unchanged'],'Original build unfinished; no route experiment started')
 require(current==record['source_sha256'] and sha(manifest)==record['manifest_sha256'],'Original source identity drift')
 require(current==json.loads(manifest.read_text())['source_sha256'],'Candidate manifest source mismatch')
 require(sha(candidate/'project/build_full.tcl')==record['build_tcl_sha256'],'Original build TCL drift')
 names=re.findall(r'_file "([^"]*sources/[^"]+)"',(build/'Lens_Angle_1080p30.pds').read_text(errors='replace'))
 compiled={(build/n).resolve().name:sha((build/n).resolve()) for n in names}
 require(len(names)==151 and compiled==current,'Actual compiled source inventory differs')
 require(sha(build/'build.log')==record['log_sha256'],'Original log drift')
 report=build/'report_timing/video_correct_ddr_top.rtr';rows=audit.parser.timing_rows(report.read_text(errors='replace'),False)
 require(any(r['slack_ns']<0 or r['failing_endpoints'] for r in rows),'Do not reroute a passing implementation')
 require('Process "Generate Bitstream" done.' in (build/'build.log').read_text(errors='replace'),'Original full flow incomplete')
 if not a.run:print('READY_FOR_EXPLICIT_SINGLE_ROUTE; no files/processes created');return
 out=build/'whole_net_route';require(not out.exists(),'Refusing experiment overwrite/retry')
 (out/'inputs').mkdir(parents=True)
 rcf=out/'whole_net_prior.rcf';rcf.write_bytes(('def_route -prior_net {'+NET+'}\n').encode('ascii'))
 origins={'mapped_database':build/'device_map/video_correct_ddr_top_map.adf',
  'placed_database':build/'place_route/video_correct_ddr_top_plc.adf',
  'pcf':build/'device_map/video_correct_ddr_top.pcf','user_rcf':rcf}
 inputs={}
 for role,p in origins.items():
  dest=out/'inputs'/p.name;shutil.copyfile(p,dest);require(sha(dest)==sha(p),'Input copy drift')
  inputs[role]={'origin':str(p),'copy':str(dest),'sha256':sha(dest)}
 script=expected_script(candidate,inputs)
 tcl=out/'route.tcl';tcl.write_text(script,encoding='utf-8',newline='\n')
 binding={'upstream_build':str(build),'source_manifest_sha256':sha(manifest),'source_sha256':current,
  'inputs':inputs,'route_tcl_sha256':sha(tcl),'driver_sha256':sha(Path(__file__)),
  'failed_original_report_sha256':sha(report),'original_execution_sha256':sha(build/'offline_build_inputs.json'),
  'single_variable':'one no-load whole-net priority RCF; same frozen mapped/placed/PCF inputs and route seed91',
  'hardware_accessed':False}
 bp=out/'route_binding.json';bp.write_text(json.dumps(binding,indent=2),encoding='utf-8')
 args=[TOOL.as_posix(),'-project_name','Resume_Route','-work_dir',out.as_posix(),'-file',tcl.as_posix()]
 print('SINGLE_ROUTE '+str(out),flush=True);start=time.monotonic()
 with (out/'route.log').open('w',encoding='utf-8') as log:
  result=subprocess.run(args,cwd=out,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 text=(out/'route.log').read_text(errors='replace')
 success_lines=[s for s in text.splitlines() if re.search(r'Executing\s*:\s*def_route -prior_net\s+\{?'+re.escape(NET)+r'\}?\s+successfully\.',s)]
 unchanged=current==audit.source_identity(candidate) and all(sha(Path(v['copy']))==v['sha256']==sha(Path(v['origin'])) for v in inputs.values())
 ex={'argv':args,'cwd':str(out),'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,
  'binding_sha256':sha(bp),'route_tcl_sha256':sha(tcl),'log_sha256':sha(out/'route.log'),
  'inputs_unchanged':unchanged,'whole_net_priority_parsed':bool(success_lines),'priority_parse_lines':success_lines,
  'qualified':False,'hardware_accessed':False}
 (out/'route_execution.json').write_text(json.dumps(ex,indent=2),encoding='utf-8')
 require(result.returncode==0 and unchanged and success_lines,'Route failed or no successful explicit constraint parse')
 final=out/'report_timing/video_correct_ddr_top.rtr';audit.timing(final)
 print('SINGLE_ROUTE_NATIVE_TIMING_PASSED; independent same-DB STA/bitgen remains required',flush=True)

if __name__=='__main__':main()
