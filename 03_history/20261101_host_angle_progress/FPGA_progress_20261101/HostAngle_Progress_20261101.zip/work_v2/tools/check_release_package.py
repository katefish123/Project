"""Portable read-only package/ZIP validation; never invokes external tools."""
from pathlib import Path,PureWindowsPath
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Optimized verification forbidden')
import argparse,json,hashlib,zipfile,re
sha=lambda b:hashlib.sha256(b).hexdigest()
def require(v,m):
 if not v:raise ValueError(m)
def check(root,archive=None):
 root=Path(root).resolve();m=json.loads((root/'package_manifest.json').read_text())
 actual={p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file() and p!=root/'package_manifest.json'}
 require(actual==m['files'],'Package inventory/hash drift')
 q=json.loads((root/'candidate_qualification.json').read_text())
 require(q['qualified_for_board_test'] is True and q['hardware_accepted'] is False,'Not an offline-qualified board-test package')
 mapping=json.loads((root/'evidence/path_map.json').read_text())
 require(set(mapping)==set(q['artifact_sha256']),'Missing frozen evidence')
 for origin,h in q['artifact_sha256'].items():
  target=(root/mapping[origin]).resolve();require(target.is_relative_to(root),'Evidence path escape')
  require(target.is_file() and sha(target.read_bytes())==h,'Evidence blob mismatch')
 sources=root/'candidate_v2_resume/sources'
 require({p.name:sha(p.read_bytes()) for p in sources.iterdir() if p.is_file()}==q['source_sha256'],'Packaged source differs')
 project_dir=root/'candidate_v2_resume/project';pds=project_dir/'HostAngleV2.pds'
 names=re.findall(r'_file "([^"]*sources/[^"]+)"',pds.read_text(errors='replace'))
 require(len(names)==151,'Packaged PDS source inventory incomplete')
 linked={}
 for name in names:
  require(not Path(name).is_absolute() and not PureWindowsPath(name).drive,'PDS source path is not relative')
  p=(project_dir/name).resolve();require(p.is_relative_to(root),'PDS refers outside package');linked[p.name]=sha(p.read_bytes())
 require(linked==q['source_sha256'],'Packaged PDS points at different source')
 program=json.loads((root/'programming_manifest.json').read_text())
 for role,extension in [('sbit','.sbit'),('smsk','.smsk')]:
  item=program['artifacts'][role];p=(root/item['relative_path']).resolve()
  require(p.is_relative_to(root) and p.suffix==extension and p.stat().st_size>1024*1024,'Invalid programming artifact')
  require(sha(p.read_bytes())==item['sha256']==q['artifacts'][role]['sha256'],'Programming/qualified image differs')
 require(program['allowed_mode']=='CRAM Program+Verify only' and program['flash_allowed'] is False,'Unreviewed programming mode')
 if archive:
  with zipfile.ZipFile(archive) as z:
   require(z.testzip() is None,'ZIP CRC failed')
   expected=dict(actual);expected['package_manifest.json']=sha((root/'package_manifest.json').read_bytes())
   require(len(z.namelist())==len(set(z.namelist()))==len(expected),'ZIP inventory/duplicate entry')
   require({n:sha(z.read(n)) for n in z.namelist()}==expected,'ZIP differs from checked folder')
 return {'passed':True,'files':len(actual)+1,'qualified_for_board_test':True,'hardware_accepted':False}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,required=True);ap.add_argument('--zip',type=Path);a=ap.parse_args();print(json.dumps(check(a.root,a.zip),indent=2))
if __name__=='__main__':main()
