"""Audit this machine's new V2 build, without claiming missing old DB integrity.

The failing archived V2 report supplies coverage keys only. Archived V1 actual
package and electrical reports supply pad bindings, not timing qualification.
"""
from pathlib import Path
import argparse,hashlib,json,re
import audit_native as parser
ROOT=Path(__file__).resolve().parents[1]
SNAP=ROOT.parent/'FPGA_handoff_20261030/A_lens_20261030'
ARCHIVE=SNAP/'candidate_host_angle_v1/build/pds_20261030_131255_389963'
COVERAGE=SNAP/'candidate_host_angle_v2_product_stage/build/pds_20261030_135116_814250/place_route/route_constraint_ite_1/video_correct_ddr_top.rtr'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def source_identity(candidate):
 original=json.loads((SNAP/'candidate_host_angle_v2_product_stage/project/source_manifest.json').read_text())['source_sha256']
 actual={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
 if set(actual)!=set(original):raise ValueError('Source inventory changed')
 allowed={'quad_packet_bridge.v','lens_affine_instance.v','ddr_quad_tile_cache.v'}
 changed={n for n in actual if actual[n]!=original[n]}
 approval=ROOT.parent/'team_merge_review/approved_merge1_sources.json'
 if approval.exists():
  if sha(approval)!='8896cd20f7ed191f3a1eb69136fa2808af03f0be66da45361932505f81aac101':raise ValueError('Reviewed approval artifact drift')
  reviewed=json.loads(approval.read_text())['source_sha256']
  if actual==reviewed:
   if actual['board_ddr.fdc']!=original['board_ddr.fdc']:raise ValueError('Constraints changed')
   return actual
 if not changed<=allowed:raise ValueError('Unreviewed RTL/constraint/vendor change '+str(changed-allowed))
 return actual

def clocks(text):
 if not re.search(r'(?m)^\| Speed Grade\s*:\s*-6\s*$',text):raise ValueError('Speed grade differs')
 expected={'sys_clk_27m':37.037037,'rx_pixel':6.734007,'cfg_clock':100.,'processing_clock':10.774410,
 'pixel_clock':13.468013,'tx_pixel':13.468013,'ref_clk':8.,'rst_clk':8.,'ddrphy_sysclk':8.,
 'phy_dq_clk_0':1.,'phy_dq_clk_1':1.,'phy_dq_sysclk_0':8.,'phy_dq_sysclk_1':8.}
 for name,period in expected.items():
  m=re.search(r'(?m)^\s*'+re.escape(name)+r'\s+([0-9.]+)\s+\{',text)
  # This PDS version quantizes clock values to1ps in the displayed report.
  # Exact FDC bytes are checked separately; do not loosen that constraint.
  if not m or abs(float(m[1])-round(period,3))>.000001:raise ValueError('Clock period changed '+name)

def timing(path):
 text=path.read_text(errors='replace');rows=parser.timing_rows(text)
 baseline=parser.timing_rows(COVERAGE.read_text(errors='replace'),False)
 keys=lambda rr:{(r['kind'],r['corner'],tuple(r['clocks'])) for r in rr}
 if keys(rows)!=keys(baseline):raise ValueError('Clock/category coverage changed')
 clocks(text)
 return {'passed':True,'rows':rows,'row_count':len(rows),'minimum_slack_ns':min(r['slack_ns'] for r in rows),
   'report_sha256':sha(path),'coverage_reference_sha256':sha(COVERAGE),
   'coverage_reference_role':'clock/category inventory only, archived V2 timing failed'}

def io(report,pins):
 oldreport=ARCHIVE/'place_route/video_correct_ddr_top.prr'
 oldpins=ARCHIVE/'place_route/video_correct_ddr_top_prr.prt'
 oldaudit=ARCHIVE/'native_audit.json'
 reference=json.loads(oldaudit.read_text())
 if not reference['io']['passed'] or reference['io']['pad_count']!=144:raise ValueError('Invalid archived IO evidence')
 before=parser.io_props(oldreport);after=parser.io_props(report)
 bp=parser.read_pinout(oldpins);ap=parser.read_pinout(pins)
 if len(after)!=144 or set(before)!=set(after) or set(bp)!=set(ap) or set(after)!=set(ap):raise ValueError('IO inventory changed')
 normalized={};discrepancies=[]
 for name,row in after.items():
  if row[:2]!=[ap[name]['direction'],ap[name]['pad']]:raise ValueError('Package/electrical mismatch '+name)
  if ap[name]['constrained']!='YES':raise ValueError('Unconstrained pin '+name)
  if row[2]!=ap[name]['physical_bank']:discrepancies.append(name)
  for key in ('pad','cell','function','direction','constrained','physical_bank'):
   if ap[name][key]!=bp[name][key]:raise ValueError('Pad binding changed '+name+' '+key)
  a=before[name].copy();b=row.copy()
  a[2]=bp[name]['physical_bank'];b[2]=ap[name]['physical_bank']
  if a!=b or a!=reference['io']['normalized_io'][name]:raise ValueError('IO electrical attributes changed '+name)
  normalized[name]=b
 if discrepancies and len({r[2] for r in after.values()})!=1:raise ValueError('Unreviewed nonuniform bank label defect')
 return {'passed':True,'pad_count':144,'normalized_io':normalized,'bank_label_discrepancies':discrepancies,
  'reference_role':'Archived V1 actual144 package/electrical bindings; V1 timing is not reused',
  'input_sha256':{str(p):sha(p) for p in (report,pins,oldreport,oldpins,oldaudit)}}

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--build',type=Path,required=True);a=ap.parse_args()
 build=a.build.resolve();candidate=build.parents[1]
 record=json.loads((build/'offline_build_inputs.json').read_text())
 actual=source_identity(candidate)
 manifest=candidate/'project/source_manifest.json';script=candidate/'project/build_full.tcl'
 if not(record['status']=='completed' and record['returncode']==0 and record['sources_unchanged'] and
   record['source_sha256']==actual==json.loads(manifest.read_text())['source_sha256'] and
   record['manifest_sha256']==sha(manifest) and record['build_tcl_sha256']==sha(script) and record['log_sha256']==sha(build/'build.log')):
  raise ValueError('Unfinished/unbound/drifted build')
 log=(build/'build.log').read_text(errors='replace')
 if 'Process "Generate Bitstream" done.' not in log:raise ValueError('Final bitstream action incomplete')
 failures=[];report=build/'report_timing/video_correct_ddr_top.rtr'
 try:tr=timing(report)
 except ValueError as e:
  failures.append(str(e));rows=parser.timing_rows(report.read_text(errors='replace'),False)
  tr={'passed':False,'report_sha256':sha(report),'row_count':len(rows),
      'minimum_slack_ns':min(r['slack_ns'] for r in rows),'negative_rows':[r for r in rows if r['slack_ns']<0 or r['failing_endpoints']]}
 try:ir=io(build/'place_route/video_correct_ddr_top.prr',build/'place_route/video_correct_ddr_top_prr.prt')
 except ValueError as e:failures.append(str(e));ir={'passed':False,'error':str(e)}
 result={'passed':not failures,'hardware_accessed':False,'failures':failures,'timing':tr,'io':ir,
   'source_sha256':actual,'native_inputs_sha256':sha(build/'offline_build_inputs.json'),
   'auditor_sha256':sha(Path(__file__)),'parser_sha256':sha(Path(parser.__file__)),
   'old_20261029_full_baseline_integrity_reproduced':False,
   'limitation':'Original10/29 complete source/DB package absent; archived IO/coverage references used explicitly; current candidate timing checked independently.'}
 (build/'native_resume_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps({'passed':result['passed'],'failures':failures,'minimum_slack_ns':tr['minimum_slack_ns'],'pads':ir.get('pad_count')},indent=2))
 raise SystemExit(0 if result['passed'] else 1)

if __name__=='__main__':main()
