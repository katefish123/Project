"""Read-only placement-stage IO audit; never qualifies unfinished routing."""
from pathlib import Path
import argparse,json
import audit_resume_native as audit
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--build',type=Path,required=True);a=ap.parse_args()
 b=a.build.resolve();candidate=b.parents[1]
 current=audit.source_identity(candidate)
 record=json.loads((b/'offline_build_inputs.json').read_text())
 if record['source_sha256']!=current:raise ValueError('Source identity differs')
 result=audit.io(b/'place_route/video_correct_ddr_top.prr',b/'place_route/video_correct_ddr_top_prr.prt')
 report={'stage':'placement only','qualified_for_board_test':False,'hardware_accessed':False,
    'source_sha256':current,'io':result,
    'limitation':'Final routing,104-corner rows and same-DB bitgen proof remain mandatory; do not inherit this as physical qualification.'}
 (b/'placement_io_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
 print(json.dumps({'placement_io_passed':result['passed'],'pads':result['pad_count'],'qualified_for_board_test':False},indent=2))
if __name__=='__main__':main()
