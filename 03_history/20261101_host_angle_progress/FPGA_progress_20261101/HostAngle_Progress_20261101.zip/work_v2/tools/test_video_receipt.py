"""Actual evidence plus deliberate wrong-source/case/log mutation rejection."""
from pathlib import Path
import unittest,json,tempfile,shutil,hashlib
from verify_video_receipt import verify
R=Path(__file__).resolve().parents[2]
F=R/'work_v2/verification/archived_video_ninety_20261031_144737_402134'
C=R/'work_v2/candidate_v2_timing2'
class Checks(unittest.TestCase):
 def test_actual_and_identity(self):
  current=json.loads((C/'project/source_manifest.json').read_text())['source_sha256']
  self.assertTrue(verify(F,current,'ninety')['passed'])
  bad=dict(current);bad['ddr_quad_tile_cache.v']='0'*64
  with self.assertRaises(ValueError):verify(F,bad,'ninety')
  with self.assertRaises(ValueError):verify(F,current,'raw')
 def test_warning_cannot_hide_behind_pass_token(self):
  current=json.loads((C/'project/source_manifest.json').read_text())['source_sha256']
  with tempfile.TemporaryDirectory() as temp:
   target=Path(temp)
   # Minimal mutation is rejected at log validation before fixture inspection.
   for name in ('verification.json','inputs.json','execution.json','simulation.log','compile.log','library.log','mapping.log'):
    shutil.copyfile(F/name,target/name)
   log=target/'simulation.log';log.write_bytes(log.read_bytes()+b'\n# ** Warning: injected evidence mutation\n')
   digest=hashlib.sha256(log.read_bytes()).hexdigest()
   v=json.loads((target/'verification.json').read_text());v['simulation_log_sha256']=digest
   ex=json.loads((target/'execution.json').read_text());ex[-1]['log_sha256']=digest
   (target/'execution.json').write_text(json.dumps(ex))
   v['execution_sha256']=hashlib.sha256((target/'execution.json').read_bytes()).hexdigest()
   (target/'verification.json').write_text(json.dumps(v))
   with self.assertRaisesRegex(ValueError,'error/warning'):verify(target,current,'ninety')
if __name__=='__main__':unittest.main()
