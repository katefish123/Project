"""Record actual child exits around unchanged numeric/control checkers.

Old checker PASS text alone is insufficient. This wrapper independently rejects
any child failure, even if a legacy checker catches its exception.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Optimized evidence execution forbidden')
import argparse,subprocess,runpy,json,hashlib
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--checker',choices=['affine','control'],required=True);ap.add_argument('--candidate',type=Path,required=True);a=ap.parse_args()
 script=ROOT/('check_affine_lens.py' if a.checker=='affine' else 'check_control_pipeline.py')
 original=subprocess.run;records=[]
 def observed(argv,*args,**kw):
  result=original(argv,*args,**kw)
  log=getattr(kw.get('stdout'),'name',None)
  records.append({'argv':[v.as_posix() if isinstance(v,Path) else str(v) for v in argv],
     'cwd':str(Path(kw['cwd']).resolve()),'exit_code':result.returncode,'log_path':str(log)})
  return result
 subprocess.run=observed;old_argv=sys.argv
 sys.argv=[str(script),'--candidate',str(a.candidate.resolve())];producer_exit=0;error=None
 try:runpy.run_path(str(script),run_name='__main__')
 except SystemExit as e:producer_exit=e.code or 0
 except Exception as e:producer_exit=1;error=repr(e)
 finally:subprocess.run=original;sys.argv=old_argv
 if not records:raise RuntimeError('No actual child process receipts')
 folder=Path(records[0]['cwd'])
 for r in records:
  if Path(r['cwd'])!=folder:raise RuntimeError('Mixed subprocess output directories')
  r['log_sha256']=sha(Path(r['log_path']))
 status=folder/'verification.json'
 passed=producer_exit==0 and len(records)==4 and all(r['exit_code']==0 for r in records) and status.is_file() and json.loads(status.read_text())['passed'] is True
 receipt={'passed':passed,'producer_exit_code':producer_exit,'producer_error':error,'records':records,
    'wrapper_sha256':sha(Path(__file__)),'producer_sha256':sha(script),
    'verification_sha256':sha(status) if status.exists() else None,'hardware_accessed':False}
 (folder/'strict_execution_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
 print('STRICT_COMPONENT_RECEIPT '+str(folder),flush=True)
 raise SystemExit(0 if passed else 1)
if __name__=='__main__':main()
