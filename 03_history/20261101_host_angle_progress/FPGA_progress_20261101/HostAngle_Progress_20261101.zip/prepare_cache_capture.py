"""One extra miss-only data hop; preserve original watchdog/response boundary."""
from pathlib import Path
import hashlib,json,shutil,difflib
R=Path(__file__).resolve().parent/'work_v2'
BASE=R/'candidate_v2_timing1';OUT=R/'candidate_v2_timing2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if OUT.exists():raise SystemExit('Refuse overwrite')
m=json.loads((BASE/'project/source_manifest.json').read_text())
assert all(sha(BASE/'sources'/n)==h for n,h in m['source_sha256'].items())
shutil.copytree(BASE,OUT)
p=OUT/'sources/ddr_quad_tile_cache.v';before=p.read_text()
text=before.replace('F_PREP=4,F_SELECT=5;', 'F_PREP=4,F_SELECT=5,F_CAPTURE=6;')
assert text!=before
text=text.replace('reg[4095:0]fill_data;', 'reg[4095:0]fill_data;\n reg[4095:0]incoming_data;')
old='''  if(!rst_n)fill_data<=0;
  else if(fill_state==F_WRITE)fill_data<={512'd0,fill_data[4095:512]};
  else if(fill_state==F_WAIT)fill_data<=rsp_block;'''
new='''  if(!rst_n)begin fill_data<=0;incoming_data<=0;end
  else begin
   // F_WAIT still consumes the original response/type/watchdog edge.
   // The owned payload then crosses one local register before RAM filling.
   if(fill_state==F_WAIT)incoming_data<=rsp_block;
   if(fill_state==F_WRITE)fill_data<={512'd0,fill_data[4095:512]};
   else if(fill_state==F_CAPTURE)fill_data<=incoming_data;
  end'''
assert text.count(old)==1;text=text.replace(old,new)
old='else begin fill_word<=0;fill_state<=F_WRITE;watchdog<=0;end'
assert text.count(old)==1
text=text.replace(old,'else begin fill_word<=0;fill_state<=F_CAPTURE;watchdog<=0;end')
old='    F_WRITE:if(fill_word==14)begin'
assert text.count(old)==1;text=text.replace(old,'    F_CAPTURE:fill_state<=F_WRITE;\n'+old)
p.write_text(text,encoding='utf-8',newline='\n')
(OUT/'ddr_quad_tile_cache.v.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='timing1/cache',tofile='timing2/cache')),encoding='utf-8')
t=OUT/'project/build_full.tcl';t.write_text(t.read_text().replace(BASE.as_posix(),OUT.as_posix()),encoding='utf-8',newline='\n')
m.update(source_sha256={p.name:sha(p) for p in (OUT/'sources').iterdir() if p.is_file()},
    build_tcl_sha256=sha(t),parent_candidate=str(BASE),parent_manifest_sha256=sha(BASE/'project/source_manifest.json'),
    cache_change={'before':sha(BASE/'sources/ddr_quad_tile_cache.v'),'after':sha(p),
                  'scope':'one miss-only data register hop; no hit-path/capacity/watchdog threshold change'},qualified=False)
(OUT/'project/source_manifest.json').write_text(json.dumps(m,indent=2),encoding='utf-8')
print(OUT)
