"""Serialize remaining full-video scenarios after the running90-degree test."""
from pathlib import Path
import time,subprocess,sys,json,hashlib
R=Path(__file__).resolve().parent
first=R/'work_v2/verification/archived_video_ninety_20261031_144737_402134'
out=R/'video_suite_execution.json'
if out.exists():raise SystemExit('Refuse overwrite')
record={'status':'waiting_for_ninety','hardware_accessed':False,'argv':sys.argv,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runs':[]}
def save():out.write_text(json.dumps(record,indent=2),encoding='utf-8')
save()
deadline=time.monotonic()+7200
while not (first/'verification.json').exists():
 if time.monotonic()>deadline:raise SystemExit('Missing90-degree result; no further tests started')
 time.sleep(5)
d=json.loads((first/'verification.json').read_text())
if not d['passed']:raise SystemExit('90-degree failed; no further scenarios started')
record['runs'].append({'case':'ninety','verification':str(first/'verification.json'),
 'sha256':hashlib.sha256((first/'verification.json').read_bytes()).hexdigest()})
for name in ('zero','switch','raw','nearest'):
 record['status']='running_'+name;save()
 argv=[sys.executable,'-X','utf8',str(R/'work_v2/tools/run_archived_video.py'),
 '--candidate',str(R/'work_v2/candidate_v2_timing2'),'--case',name]
 log=R/('suite_'+name+'.log')
 with log.open('w',encoding='utf-8') as f:
  result=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 record['runs'].append({'case':name,'argv':argv,'exit_code':result.returncode,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 save();print(name+' exit='+str(result.returncode),flush=True)
 if result.returncode:
  record['status']='failed_'+name;save();raise SystemExit(result.returncode)
record['status']='all_five_processes_passed';save()
print(record['status'],flush=True)
