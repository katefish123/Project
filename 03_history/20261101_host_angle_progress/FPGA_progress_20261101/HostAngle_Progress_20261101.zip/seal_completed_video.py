from pathlib import Path
import sys,json,re,hashlib
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'work_v2/tools'))
from verify_video_receipt import verify
C=R/'work_v2/candidate_v2_timing2'
current=json.loads((C/'project/source_manifest.json').read_text())['source_sha256']
suite=json.loads((R/'video_suite_execution.json').read_text())
assert suite['status']=='all_five_processes_passed'
proofs=[]
for run in suite['runs']:
 if run['case']=='ninety':folder=Path(run['verification']).parent
 else:
  assert run['exit_code']==0
  log=Path(run['log']);assert hashlib.sha256(log.read_bytes()).hexdigest()==run['log_sha256']
  folder=Path(re.search(r'ARCHIVED_VIDEO (.+)',log.read_text()).group(1).strip())
 proofs.append(verify(folder,current,run['case']))
assert {p['case'] for p in proofs}=={'zero','ninety','switch','raw','nearest'}
record={'all_five_current_source_video_receipts_verified':True,'candidate':str(C),
 'source_sha256':current,'proofs':proofs,'hardware_accepted':False,'physical_qualified':False}
(R/'completed_timing2_video_seal.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print('FIVE_VIDEO_RECEIPTS_SEALED pixels='+str(sum(p['pixels'] for p in proofs)))
