"""Derive a repair candidate from audited V2; retain original capacity/clocks."""
from pathlib import Path
import hashlib,json,shutil,difflib
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'work_v2/candidate_v2_resume'
OUT=ROOT/'work_v2/candidate_v2_timing1'
SNAP=ROOT/'FPGA_handoff_20261030/A_lens_20261030'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    if OUT.exists():raise SystemExit('Refuse overwrite')
    old=json.loads((BASE/'project/source_manifest.json').read_text())
    assert all(sha(BASE/'sources'/n)==h for n,h in old['source_sha256'].items())
    proof=ROOT/'bridge_validation/verification/bridge_decode_20261031_144205_975338/verification.json'
    assert json.loads(proof.read_text())['passed']
    shutil.copytree(BASE,OUT)
    bridge=OUT/'sources/quad_packet_bridge.v'
    bridge.write_bytes((SNAP/'candidate_host_angle_v3_cache64/sources/quad_packet_bridge.v').read_bytes())
    p=OUT/'sources/lens_affine_instance.v'
    text=p.read_text()
    marker=' always @(posedge clk or negedge rst_n)begin\n  if(!rst_n)begin req_valid'
    assert text.count(marker)==1
    pos=text.index(marker)
    tail=text[pos:]
    original=tail
    # Capture bounded source coordinates before row multiplication. All
    # sideband/valid/error values receive the exact same extra cycle.
    stage=''' // Separate full-width coordinate/range selection from row address multiply.
 reg address_valid,address_inside,address_error,address_nn;
 reg[11:0]address_bx,address_by,address_ex,address_ey;
 reg[23:0]address_tag;reg[7:0]address_fx,address_fy;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   address_valid<=0;address_inside<=0;address_error<=0;address_nn<=0;
   address_bx<=0;address_by<=0;address_ex<=0;address_ey<=0;
   address_tag<=0;address_fx<=0;address_fy<=0;
  end else begin
   address_valid<=lens_valid;address_inside<=inside_now;address_error<=lens_error;
   address_nn<=nn;address_tag<=lens_tag[23:0];
   address_bx<=inside_now?bx[11:0]:12'd0;address_by<=inside_now?by[11:0]:12'd0;
   address_ex<=inside_now?ex[11:0]:12'd0;address_ey<=inside_now?ey[11:0]:12'd0;
   address_fx<=lens_x[7:0];address_fy<=lens_y[7:0];
  end
 end
'''
    replacements={
        'req_valid<=lens_valid;req_inside<=inside_now;req_error<=lens_error;req_tag<=lens_tag[23:0];':
        'req_valid<=address_valid;req_inside<=address_inside;req_error<=address_error;req_tag<=address_tag;',
        'inside_now?by*1920+bx':'address_inside?address_by*24\'d1920+address_bx',
        'inside_now?by*1920+ex':'address_inside?address_by*24\'d1920+address_ex',
        'inside_now?ey*1920+bx':'address_inside?address_ey*24\'d1920+address_bx',
        'inside_now?ey*1920+ex':'address_inside?address_ey*24\'d1920+address_ex',
        "inside_now&&!nn?lens_x[7:0]":"address_inside&&!address_nn?address_fx",
        "inside_now&&!nn?lens_y[7:0]":"address_inside&&!address_nn?address_fy",
    }
    for a,b in replacements.items():
        assert tail.count(a)==1,a
        tail=tail.replace(a,b)
    p.write_text(text[:pos]+stage+tail,encoding='utf-8',newline='\n')
    tcl=OUT/'project/build_full.tcl'
    tcl.write_text(tcl.read_text().replace(BASE.as_posix(),OUT.as_posix()),encoding='utf-8',newline='\n')
    current={p.name:sha(p) for p in (OUT/'sources').iterdir() if p.is_file()}
    changes={n:{'before':old['source_sha256'][n],'after':h} for n,h in current.items() if old['source_sha256'][n]!=h}
    assert set(changes)=={'quad_packet_bridge.v','lens_affine_instance.v'}
    old.update(source_sha256=current,build_tcl_sha256=sha(tcl),migration_only=False,
        parent_candidate=str(BASE),parent_manifest_sha256=sha(BASE/'project/source_manifest.json'),
        functional_changes=changes,bridge_request_equivalence_sha256=sha(proof),qualified=False)
    (OUT/'project/source_manifest.json').write_text(json.dumps(old,indent=2),encoding='utf-8')
    for n in changes:
        (OUT/(n+'.diff')).write_text(''.join(difflib.unified_diff((BASE/'sources'/n).read_text().splitlines(True),
            (OUT/'sources'/n).read_text().splitlines(True),fromfile='V2/'+n,tofile='timing1/'+n)),encoding='utf-8')
    print(json.dumps({'candidate':str(OUT),'changed':list(changes),'qualified':False}))

if __name__=='__main__':main()
