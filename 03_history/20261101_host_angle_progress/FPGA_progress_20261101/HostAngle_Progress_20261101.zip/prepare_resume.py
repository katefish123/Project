"""Create a byte-audited local V2 workspace. Never edits the Git snapshot."""
from pathlib import Path
import hashlib, json, shutil

ROOT=Path(__file__).resolve().parent
SNAP=ROOT/'FPGA_handoff_20261030/A_lens_20261030'
OUT=ROOT/'work_v2'
sha=lambda b:hashlib.sha256(b).hexdigest()

def main():
    if OUT.exists(): raise SystemExit('Refusing to overwrite workspace')
    original=SNAP/'candidate_host_angle_v2_product_stage'
    manifest=json.loads((original/'project/source_manifest.json').read_text())
    validated={}; mapping={}
    for name, expected in manifest['source_sha256'].items():
        data=(original/'sources'/name).read_bytes()
        alternatives=[data,data.replace(b'\r\n',b'\n'),data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
        matches=[b for b in alternatives if sha(b)==expected]
        if not matches: raise RuntimeError('Unrecoverable source: '+name)
        validated[name]=matches[0]
        mapping[name]={'snapshot_sha256':sha(data),'canonical_sha256':expected,'newline_restored':sha(data)!=expected}
    assert len(validated)==151
    candidate=OUT/'candidate_v2_resume'
    (candidate/'sources').mkdir(parents=True)
    (candidate/'project').mkdir()
    for name,data in validated.items(): (candidate/'sources'/name).write_bytes(data)
    for part in ('tools','calibration'):shutil.copytree(SNAP/part,OUT/part)
    tcl=(original/'project/build_full.tcl').read_text()
    old='C:/D/FPGA/A_lens_20261030/candidate_host_angle_v2_product_stage'
    assert tcl.count(old)==1
    tcl=tcl.replace(old,candidate.as_posix())
    (candidate/'project/build_full.tcl').write_text(tcl,encoding='utf-8',newline='\n')
    new_manifest=dict(manifest)
    new_manifest.update(snapshot_manifest_sha256=sha((original/'project/source_manifest.json').read_bytes()),
        snapshot_directory=str(original),build_tcl_sha256=sha((candidate/'project/build_full.tcl').read_bytes()),qualified=False,
        migration_only=True)
    (candidate/'project/source_manifest.json').write_text(json.dumps(new_manifest,indent=2),encoding='utf-8')
    reference=ROOT/'FPGA_handoff_20261030/external_reference/B_lens_v2'
    rules={
        'C:/pango/PDS_2022.2-SP6.4/bin':'D:/softwares/PDS/PDS_2022.2-SP6.4/bin',
        'C:/modeltech64_2020.4/win64':'D:/softwares/modelsim/win64',
        'C:/D/FPGA/A_software_20261024/reference/B_lens_v2':reference.as_posix(),
        'C:/D/FPGA/A_software_20261024/candidate_30fps/sim/tb_1080p30.sv':(ROOT/'dependencies/tb_1080p30.sv').as_posix(),
        "candidate_host_angle_v2_product_stage":"candidate_v2_resume",
    }
    migrated={}
    for p in (OUT/'tools').glob('*.py'):
        before=p.read_bytes();text=before.decode('utf-8')
        for a,b in rules.items():text=text.replace(a,b)
        p.write_text(text,encoding='utf-8',newline='\n')
        migrated[p.name]={'original_sha256':sha(before),'local_sha256':sha(p.read_bytes())}
    record={'scope':'V2 migration only; no functional RTL changes, no hardware',
        'script_sha256':sha(Path(__file__).read_bytes()),'source_byte_mapping':mapping,
        'tool_mapping':migrated,'text_relocations':rules,'candidate':str(candidate),
        'missing_original_bench':not (ROOT/'dependencies/tb_1080p30.sv').exists(),
        'source_manifest_sha256':sha((candidate/'project/source_manifest.json').read_bytes())}
    (OUT/'migration.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps({'candidate':str(candidate),'sources':len(mapping),'restored_newlines':sum(v['newline_restored'] for v in mapping.values())}))

if __name__=='__main__':main()
