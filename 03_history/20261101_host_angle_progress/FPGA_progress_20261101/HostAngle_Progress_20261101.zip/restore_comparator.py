from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
audit=Path('C:/Users/Lenovo/Documents/ChatGPT/FPGA/initial_display_fix/resume_audit_20261031/frozen_dependency_audit.json')
out=R/'dependencies/frozen_comparator';out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entries=json.loads(audit.read_text(encoding='utf-8'))
for e in entries:
    data=Path(e['path']).read_bytes()
    if e['restore_mode']=='LF':data=data.replace(b'\r\n',b'\n')
    assert hashlib.sha256(data).hexdigest()==e['expected_sha256'],e['name']
    (out/e['name']).write_bytes(data)
(out/'binding.json').write_text(json.dumps({'audit_sha256':sha(audit),'entries':entries},indent=2),encoding='utf-8')
p=R/'work_v2/tools/check_affine_lens.py'
text=p.read_text().replace('C:/D/FPGA/A_board_20261029/candidate_de_frame_guard_v2/sources',out.as_posix())
p.write_text(text,encoding='utf-8',newline='\n')
print(out)
