"""Record additional runtime-only relocation in the derived tools."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changes={}
for p in (R/'work_v2/tools').glob('*.py'):
    before=sha(p);text=p.read_text(encoding='utf-8')
    text=text.replace('C:/pango/PDS_2022.2-SP6.4','D:/softwares/PDS/PDS_2022.2-SP6.4')
    if sha(p)!=hashlib.sha256(text.encode()).hexdigest():
        p.write_text(text,encoding='utf-8',newline='\n')
    if sha(p)!=before:changes[p.name]={'before':before,'after':sha(p)}
(R/'work_v2/runtime_adaptation.json').write_text(json.dumps({'script_sha256':sha(Path(__file__)),
    'scope':'runtime paths only, snapshot untouched','changes':changes},indent=2),encoding='utf-8')
print(json.dumps(changes,indent=2))
