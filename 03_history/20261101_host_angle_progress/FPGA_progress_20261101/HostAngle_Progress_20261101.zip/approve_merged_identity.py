"""Freeze reviewed source identity; this is not a timing/release qualification."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
candidate=R/'work_v2/candidate_team_merge1'
team=Path('D:/FPGA/team_downloads/20261031_team_update/unpacked/FPGA_team_update_20261031/changes/FPGA_handoff_20261030/A_lens_20261030/candidate_host_angle_v2_product_stage/project/source_manifest.json')
base=R/'FPGA_handoff_20261030/A_lens_20261030/candidate_host_angle_v2_product_stage/project/source_manifest.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
actual={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
incoming=json.loads(team.read_text())['source_sha256'];original=json.loads(base.read_text())['source_sha256']
assert len(actual)==151 and set(actual)==set(incoming)==set(original)
assert {n for n in actual if actual[n]!=incoming[n]}=={'ddr_quad_tile_cache.v'}
assert actual==json.loads((candidate/'project/source_manifest.json').read_text())['source_sha256']
assert actual['board_ddr.fdc']==original['board_ddr.fdc']
report=R/'team_merge_review/PIPELINE.md'
assert sha(report)=='bcd4a5c405e2fae0d6d09363caeaed3358b62cd4273df82b4b50a81ee3e0c195'
out=R/'team_merge_review/approved_merge1_sources.json'
assert not out.exists()
out.write_text(json.dumps({'source_sha256':actual,'team_manifest_sha256':sha(team),
 'original_manifest_sha256':sha(base),'review_sha256':sha(report),
 'merge_driver_sha256':sha(R/'prepare_team_merge.py'),'cache_delta_sha256':sha(candidate/'cache_merge.diff'),
 'qualified':False,'role':'Reviewed source allowlist only; no timing/hardware qualification'},indent=2),encoding='utf-8')
print(sha(out))
