# 2026-10-31 V2 resume

## 11月1日01:25 CURRENT (overrides all older sections)

### Later observations through02:34

No optimization/extraheavyPDS started. Activeprimary49504/child38876 samebuild. Detail19=41374unrouted/1076CPU sec;20=40506/1139.8sec (read02:33). Stillpositiveprogress,nofinalRTR. ChildactualCPU10110.6s at02:00/WS1GB, consistentonebusycore. Allsource151unchanged. Rootquotaownerlaterreportedminimum27% above15;doNOTduplicateAPI/automation.

Placement-only144IOcheckactuallypassed via tools/audit_placement_io.py, recordedmainbuild/placement_io_audit.json explicitlyqualifiedfalse. FinalIOmuststillreauditafterroute.

ReadinstalledofficialPDSmanualusingpdfskill/text+visualpage118; review_phy/PHYSICAL_OPTIONS_FACTS.md recordsfacts. PG2L100H issinglethreadrouterusingLogosgeneral/routerdefaults. TeamnewTCLhasexplicit-fix_hold_violation,seeds37/41,oneRCFiterationandreportonly; localfrozenflowretains73/91/3iters+maskbitgen andnofix_holdenable(postholddefaultOFF),butinrouteholddefaultON(200psSRB/100psclocktree). DoNOTclaimholdmustfailordisableactualchecks. Ifactualnegativehold,postholdflagisanexplicitdocumentedfutureexperiment,notautomaticmixwithone-netCAexperiment. CurrentTCLunmodified. ManualtempPNGsdeletedafterinspection,originalmanualuntouched.

Currentremainingworkonlyphysicalwait/actualnativefinalaudit→sameDBfreshSTA/bitgen→qualifyemit→package/check→rootupload. Noqualifiedmanifest/packageyet. DoNOTendturnjustbecausebackgroundjobstarted; user explicitlyaskedpersist orconditionalquotastop.

User says persist until actual qualified_for_board_test package, hardware still forbidden here. NEW conditional stop: root hardware/upload chat01a138e8-582f-7090-8ece-6119c3df7598 alone monitors quota via automationfpga every5min from01:20. Any available5h/week<15% BEFOREcomplete→root explicitly notifies developer to stop optimization/newheavy work, save recoverable progress and uploadUNQUALIFIED snapshot, NOcompletionmarker. Above thresholdkeepgoing. Latestrootconfirmation tick01:24:19,remaining5h70/week30, phase monitoring; doNOTduplicatequota calls/automation. Root alone Gitcommits/push/remotecheck; ifqualified first DATAcommit/push/allfilesverified then separateUPLOAD_COMPLETE.txt-onlycommit referencingDATAsha. Developer soleRTL/PDS/packagewriter. SeeSTATUS_20261101.md.

CURRENT151sources unchanged candidate_team_merge1. Actualall5newvideo passed androotreverified62208000pixels via seal_merge_video.py→completed_team_merge1_video_seal.json; maxgap33333300ns each6swaps. merge_video_suite_execution.json completedall5, no ModelSimfullvideo running. No needrepeat.

MAINPDS remainsonebuild parent49504/child38876 (samebuild, notduplicate), session11739, buildpds_20261031_224731_129913. Detailedrouteiter16 now43607 unrouted vs89723initial;15=44523,14=45792, strictlydecreasing;16CPU929.5s. Global0 anddetail43k differentphases. ChildWS1GB/private2.7GB/freeRAM2GB; LUT60%/DRM70%, no provenbadconstraint/resourcefullness. Readonlyreview_phy/MERGED_ROUTE_PROGRESS.md sayswait, no blindrestart/seed/clockchange. No finalrtr orqualifiedbit. Oldtiming2buildwasinterruptedandnotreused. Avoidhighfrequencyscanninglogs; onlyreadonmtime/newactualstage.

Newstrictcomponentreceipts (use THESE inqualification): affine_lens_20261101_010235_075592, control_pipeline_20261101_010241_510553. Unchangedlegacyproducercheckers (whichcatchRuntimeError) arewrappedby strict_component_runner.py thatrecordsallactual4childargv/rc andproducerexit, rejectsnonzeroindependently. Bothrealreplayed7968/640legacy and16384control, all4rc0+producer0. receiptfilename strict_execution_receipt.json; qconsumeswrapper/producer/v/logSHA. Oldercomponentpassesdonotclaimactualargv0.

Actualsynthleafschemaadaptation DONE: check_native_lens_merged.py separatefromoldchecker, validatesexact3extraN0/affine_x2[7]_inv/affine_y2[0]_inv,actualparentLUT1inversionsandresetLUT3INITFB=abort|!rst_n|state0; nolegacy/nx/nyassumption. Latestpass native_lens_merged_20261031_231508_799686,4075points4068checked/301errors7cancel,all4actualargv0+hashreceipt; localresetwindowskeepGRShigh. Earlier231311/231352passpre-finalcheckersarchivedonly. review_timing/MERGED_NATIVE_LEAF.md capturesactualsynthSHA ff6b1021516b288d70673d29758324e76b63965023f03ccd21ce3c6a338f08cc.

GATESREADY (noqualifiedresultyet): audit_resume_native.source_identity nowallowsEXACTapprovedmerge1 151set via team_merge_review/approved_merge1_sources.json SHA8896cd20f7ed191f3a1eb69136fa2808af03f0be66da45361932505f81aac101; originalFDCbyteunchanged, old3-sourcebranch retainedforhistory. Mainclockparserexplicit-6/13periods/104keys/144IO strict. Selfchecksactualnegative/missingcorner/badUARTpadpassed.

finish_resume_physical.py reviewedfreshproject(no seed)+frozenactual_pnr.adf/PCF/map/place/recipe+directworkerSTA+sameexplicitDBbitgen; requiresallmainfinaltiming/IOpassfirst. --build main path, optional--route-output onlyifreviewedfallback. Mustactuallyrunafterfullmaincomplete; noindependent_checkexistsyet.

route_resume_whole_net.py drafted/reviewed,NOTRUN. Itrejectsrunning/passingoriginalflow; onactualfullnegativeandcausalsupport--runuses4frozenroleinputs(map/place/pcf/userRCF),same91,onlyoneCAwhole-netpriorityRCF,actualparse-successline+executionJSON. PreflightrecordTCL/manifest/compiled151strict; finisherreconstructsentireexpected_script==route.tcl. NoFDC/timingexceptionchanges. CurrentdefaultdryrunproperlyrefusedOriginalbuildunfinished,nofiles/newprocesses. Do NOTstartwhilemainrunning.

qualify_merged.py DEFAULTREADONLY consumesexactnew151/all5video/strictaffinecontrol/native4075/cache+bridge actual4rc0,allgoldenanchors(actualoldSV/report/aggregate/child,sourcePNG,reference.py) frozenartifactmap; requiresactualindependentphysical5canonicalroles(currentuniquematchingstemimage/mask>1MB,explicitDB,rootrtr,project),before/afterprojects+2DBselections,actualshell/workerargv/token,104rows/144IO. Missingphysicalactualtestrefuses,noemit. --emitonlyafterpassed writescandidate_qualification.json, qualified_for_board_testtrue/hardware_acceptedfalse; nooldbaselineintegrityoropticsclaim, inheritedF_CMD/F_WAITwatchdogcontract explicitlynotfixed.

package_merged.py onlyacceptsemittedq==freshrecomputedqualify, freezesallevidenceblobs/path_map,151sources/IP/tools/calibration,correctburnpair+programming_manifestCRAMonly/flashfalse,ZIP+CRC+inventoryviareadonlycheck_release_package.py. NEW source-onlyPDSentry: afterqualificationONLYmetadata pds_shell -project_nameHostAngleV2 overopen_sources.tcl (headeronlyset_arch/add_design/add_constraint,nocompile/pnr), relative-root rebuild_full.tcl originalotherflagsunchanged,parse151sourcehashandrejectabsolute/drive/UNCpaths. Notactuallyrun,nopackagecreateduntilqualified. READMEclearlysourceview/rebuilddoesnotinheritburnqualification; portablecheckerdoesnotexecuteexternaltools. PackagepathplannedD:/FPGA/deliveries/FullHD_HostAngleV2_20261031(.zip);doNOTpublishunqualifiedbit.

ReadonlyreleasegateP2review3groupsclosed: physicalroles/actualworker; affinecontrolactualexits+tool/loghash;goldenanchorcopy. review_timing/RELEASE_GATE_MERGED_REVIEW.md hasappendixsource-onlyentry;lastP2relativepathguardfixedbyPath.is_absolute+PureWindowsPath.drive inproducerandcheckerafterappendix. Noimportantremainingstaticblock,stillneedACTUALallphysical/packageexecution. NoGitpushbydeveloper.

Immediate work: waitcurrentdetailedroute/newreportwithoutbusyloop; ifpassesactualnativeaudit→independentSTA/bitgen→qualifyemit→package/check→handoffrootexactSHA(allfiles/dataGitthenmarker). Iffailslocateactualpaths, continuecausalfixunderexistingauthorizationuntilqualifiedorrootexplicitquotastop. DoNOTendonlybecausetaskisbackground. No board/OBS/UART/JTAG operations.

## LATEST OVERRIDE (22:27 client31October; read first)

### NEWEST22:47 override

Merged candidate now exists: work_v2/candidate_team_merge1. prepare_team_merge.py reconstructs exact incoming151 byteammanifest (fallbackoriginalsnapshot bytes onlymatchhash), then incomingcache adds local F_CAPTURE=6/incoming3072 packedpayload hop. All13teamRTLretained, bridge/lenssupersets, onlycache differsincoming. team_reconstruction.json andcache_merge.diff preserveidentity. No oldcandidate overwritten.

Newactualpasses: affine_lens_20261031_223502_823659 (7968/640legacy), control_pipeline_20261031_223734_823123 (16384pixels), cache_team_validation/candidate_20261031_223800_715884 (trueoldV2 reference,2560req/lane3670rows), strictbridge_team_validation/extended_20261031_223806_090627/verification/bridge_decode_20261031_223806_099746(two widths5000packets/lane). NewFIFO hasASYNC_REG/syn_preserve/allow_retiming attribute-only changes, newbridge run usesnewFIFO dependency; agentcredit recordingexactdelta. New90fullvideo started session4065, archived_video_ninety_20261031_223744_954675; needcheckactualfinalreceipt once (mayalreadyfinished bynextturn). Do NOT inherittiming2pass.

ONLYnewPDS session11739: candidate_team_merge1/build/pds_20261031_224731_129913. Old31999absentinterrupted. Newcurrentmasterwraprun_native_build.py. Newrootfullsourcefrozen; do notmutatewhilerunning. NootherPDS/worker.

Nextremaining4videos mustbeexplicitlyqueuedforMERGE1after90pass; oldrun_remaining_video.py hardcodesTIMING2andold90, doNOTrerunit. Adaptseparateorparameterizedwrapperwithnewoutputreceipt avoidingoverwriteoldvideo_suite_execution.json. Need native_lensactualfullsynthtestonnewvm whenfilecomplete (structurechecker mayneedhonestactualnetadaptation). Re-readallnewreceipts.

IMPORTANTnewnativegate: audit_resume_native.source_identity CURRENTLYpermitsONLY3vsOct30andwillrejectmerged13; safelyfails, notreadyfornewqualification. Needfreezeexplicitapproved13+mergedcache expectedall151 andbindnewapprovalSHAinhelper, FDC/PLL/vendor/Bleafstillmustexactoriginal. NewphysicalsameDBfinisherusesaudit.source_identity, requiresadaptbeforeuse. Noqualifiedpackageyet.

Readonlythreewayreport team_merge_review/PIPELINE.md SHA bcd4a5c405e2fae0d6d09363caeaed3358b62cd4273df82b4b50a81ee3e0c195. Proposedlocalhandoff FullHD_HostAngleV2_20261031 tohardwareownerONLYafteractualnewqualification. Theyknowpending. NoGUI/UART/JTAG/OBS/devices here.

Hardware owner relayed direct user instruction to continue from newest team increment. Package isolated at D:/FPGA/team_downloads/20261031_team_update/unpacked/FPGA_team_update_20261031, ZIP SHA06cdc482bc8e1198dcd35f134feecbb425d94ce2373832b503d5db6a3660361d, basecommit eeecd20e1b44b2984ac9aee2cdb0893ed341d9e1. 98files manifestverified; 13RTL patches. Team native audit FAILED setup-1.302/hold-.766, not release. Team4 video_vm passes belong exactteam151source set, NOT futuremergedcandidate. nearest12missing in teamsoftwarematrix.

Root checked Get-CimInstance onlyforpds_shell.exe: NONE. Prior session31999 is Unknownprocess; build.log last15:46:49 vs22:27:07 current. Original offline_build_inputs stillrunning is stale. Do NOT interpret that build as successful or stillactive; no secondPDS currently. Fulltiming2regression finished all5, sealed by root actual verify_video_receipt checks into completed_timing2_video_seal.json:62208000 exactpixelcomparisons. sourcecandidate2 frozen/physicalunqualified. Keep allreceipts.

Hardwareowner produced read-only threeway previews: D:/FPGA/team_downloads/20261031_team_update/merge_preview_summary.json and merge_preview/<file>/merge_preview.v. 13base_git_blobs match frozenOct30. Only3conflicts bridge/cache/lensaffine; other10local==base, can acceptteamdelta. Conflictmarkedpreviews NEVER compile. User sayscontinuewiththisprogress. Root soleproductionwriter, hardwareowner onlyreadsaudits/preparesboardlater.

Agent stream_independent_review resumed onlyreadonly: team_merge_review/PIPELINE.md, focusing those3choices. Root initialinspection: incomingbridge is5elasticstages (local4+verify), incominglens includeslocalbounded12bitcoordinate/addressstage plusprelensaffinevalidstage; incomingcache changesRAM256→192bit packedRGB24, fill4096→3072, addsNoutputstage; localmissF_CAPTURE notpresent. Need decide incomingcache+adaptF_CAPTURE3072 vs whetherteamengine stagealreadybreakslonghop. Do notblindoverlay. No mergedcandidate yet/no newPDS yet. Next deriveexplicit3waydecision, freezeall151newSHA, re-runrelevantnumerical/control/cache/full5video (cannotinheritoldpassbyname), then onePDS and originalstrictphysicalgates.

Tools addedsinceearliernotes: verify_video_receipt.py (readonlyfullchain/current151/actual4argvexit0/log/6pathbench/3hex/new6unique30fps), test_video_receipt.py actualreceipt+wrongsource/wrongcase/injectedwarning mutants passed2methods. seal_completed_video.py actualranall5 successfully. finish_resume_physical.py independentfreshsameDBpipeline reviewed bystreamagent, no importantremainingblocker; notexecutedbecausemainbuildnevercompleted. audit_resume_native.source_identity currently permitsONLY3localchanges againstOct30; MUST explicitlyadaptreviewedallowedset/anchor forincoming13+mergednewcode, cannotclaimoldgatepassesnewcandidate. Oldassess_candidate stillmissingbaseline.

Earliersectionsbelowdescribeoldrunningstateandarehistorical, overriddenabove.

User resumed through hardware owner chat 01a138e8-582f-7090-8ece-6119c3df7598. This development chat exclusively owns production RTL and one heavy PDS process. Hardware owner alone handles devices/OBS/UART/JTAG. No hardware access here.

Scope: native1920x1080,30 unique corrected frames/sec, Brown k1/k2/p1/p2 plus host affine rotation/scale, single resampling. Auto tracking/IMU/perspective deferred. V2 cache128/tile128 retained. V3 cache64 did not meet90deg fps and is not production baseline.

Snapshot: FPGA_handoff_20261030/A_lens_20261030, from main d16b2021f4f9678516f2fc087beecb1f6c19ac4d. Never mutate snapshot. work_v2/candidate_v2_resume currently exact original151 canonical RTL/FDC hashes.23 files required newline restoration; migration.json binds raw/canonical hashes. build Tcl/tool paths relocated separately, not evidence of functional change. prepare_resume.py refuses overwrite.

Real local control simulation passed: work_v2/verification/control_pipeline_20261031_144202_398552/verification.json,16384 pixels/4frames,2 commits, atomic midframe and reset cases. No port opened.

V2 old physical evidence: ite1 decode -.448ns/cacheRAM→response -.529ns; ite2 processing lens.out_y→addr01 -.655ns, engine.source_cache→cache.fill_data -1.036ns. DDRPHY also fails setup/hold independently. Old .sbit files not qualified.

Independent bridge validation: bridge_validation/verification/bridge_decode_20261031_144205_975338 passesV2 vsV3 reciprocal bridge request comparisons (5000packets/lane each1920andfallback128); only bridge+CDC, notcache64. Original testbench compile errors preserved. Agent adding boundary evidence; no production change yet.

Open dependencies: original A_software_20261024/candidate_30fps/sim/tb_1080p30.sv exact bench and frozen10/29 lens comparator. Hardware owner is finding Git originals; do not substitute generated downstreambench. B reference is snapshot/external_reference/B_lens_v2. numpy/cv2 installed; current versions2.5.2/5.0.0 must be recorded for new fixtures.

Parallel read-only owners: stream_independent_review → review_timing (RTL/cache paths), processing_stall_audit → review_phy (physical constraints), credit_stall_audit → bridge_validation (test tool and bench portability). Root alone edits production, starts PDS. No PDS currently started in this resumed task.

## Current live jobs and frozen candidate

Frozen production candidate: work_v2/candidate_v2_timing2. Parent timing1 onlychanged bridge and lens_affine_instance; timing2 adds cache F_CAPTURE=6, incoming4096 register then fill_data nextcycle beforeF_WRITE. Hit throughput/capacity/watchdog threshold unchanged. Do not mutate while build/tests active. Baseline151 sources in candidate_v2_resume remain exact originalcanonical.

Timing1 actual UART/control16384 pixels/4frames, passed work_v2/verification/control_pipeline_20261031_144349_253185. Timing2 exact affine7968 stimuli/640legacy comparator passed affine_lens_20261031_144714_263075; frozen6 comparator restored with hardware owner's exactSHAaudit, dependencies/frozen_comparator/binding.json. VendorPLL simulation passed video_clocks_20261031_144502_272836.

Only PDS: execsession31999, work_v2/candidate_v2_timing2/build/pds_20261031_144757_496870; running original seed73/91 fullnormalflow, no userRCF yet. Source/manifest/Tcl bound offline_build_inputs. Do not start anotherPDS until complete.

Full90 video: execsession42415, verification/archived_video_ninety_20261031_144737_402134. New run_archived_video.py deliberately uses historicalSHA-bound derivedbench, not missing tb1080original; replaces only6readmemh paths, regenerates3hex and matches allhistoricSHA. Firstattempt144725 failed vsim.ini Windowsbackslash, preserved; fixedPath.as_posix secondrun isactive. Currentfirst3frames correct, third31.389ms; not finalpassyet.

Suite execsession3669 run_remaining_video.py waitsfirst90 actualpass then serializeszero/switch/raw/nearest; records video_suite_execution.json and suite_*.log. OneModelSimfullvideoatonce. No need manual nextcase launches.

Added historicalfixture aggregate→childhash closure to latest runner AFTER90 snapshot started; agentprocessing_stall_audit will independently seal this first90 missingclosure withoutrerun, rest4useupdatedrunner. Original simulationgold/deadlineassertionsunmodified.

Native gate: tools/audit_resume_native.py uses failedV2 actualreport104coveragekeysONLY and archivedV1 actualprr/prt+IOaudit144padsONLY; independently checks currenttimingallcorners and currentIO. Does notclaim missing10/29wholebaselineintegrity. check_resume_auditor.py actualselfcheck passed realfailure rejection/cornerremoved rejection/wrongUARTpad rejection. Oldassess_candidate.py stillrequiresmissingoldbaseline, do notuseasnewqualifiedor silentlybypass. Needsnewexactevidencequalificationintegration afteractualbuild.

Agentcredit found their strictbridge/cachelocal dofile `onfinish stop` plusonbreakcode3 yields nonzero althoughgold tokenpresent. They are correcting onfinish exit and rerunning with enforcedactualexit0. Earlierbridgepass alone not finalqualificationuntilactualrerun. Root'srun_archived_video and control tests enforceactualexit0.

Next: waitactualfullvideo/cache/synthresults, auditnewgate+runner, then nativefinal104rows/IO. IfPHYfails, reviewed one-netCA RCF experiment onlysamefinalmapped/placedDB/seed91; archivedDBnotavailable but newbuildcreatesit. Never qualify fromexit0/bitexistence; nohardwarebeforequalifiedpackagehandoff.

Merged remaining-video orchestrator is now running session88889 via run_remaining_merge_video.py; waits new90 directory then serializes zero/switch/raw/nearest for candidate_team_merge1 only. Outputs merge_video_suite_execution.json and suite_merge_*.log; never rerun old wrapper. Agentcredit final new receipts hash-verified by cache_team_validation/verify_team.py (read-only) and verified_summary.json; reports bothteam_validation directories. No more test repetitions needed absent changes.
