"""Derive a separate actual-netlist schema checker; preserve original helper."""
from pathlib import Path
R=Path(__file__).resolve().parent/'work_v2/tools'
p=R/'check_native_lens.py';out=R/'check_native_lens_merged.py'
assert not out.exists()
text=p.read_text()
start=text.index("    standard={'clk'")
end=text.index("    out=ROOT/'verification'",start)
new=r'''    standard={'clk','in_valid','in_tag','in_x','in_y'}
    extra=set(ports)-standard
    ix=next(p for p in extra if p.endswith('affine_x2[7]_inv'))
    iy=next(p for p in extra if p.endswith('affine_y2[0]_inv'))
    reset='N0'
    assert extra=={ix,iy,reset}, extra
    # New affine input registers expose two factored inverted bits. Verify
    # actual parent primitive truth tables AND exact bit connections.
    cells=[]
    for port,bit in [(ix,'affine_x2[7]'),(iy,'affine_y2[0]')]:
        inv=next(c for c in re.findall(r'(?m)^    GTP_LUT1 .*?\);',algorithm,re.S)
                 if re.search(r'\.Z\s*\('+re.escape(bindings[port])+r'\s*\)',c))
        assert ".INIT(2'b01)" in inv and ('.I0 ('+bit+')') in inv
        assert bindings['in_x']=='affine_x2' and bindings['in_y']=='affine_y2'
        cells.append(inv)
    cell='\n'.join(cells)
    algorithm_instance=re.search(r'(?m)^    lens_affine_instance\s+.*?\);',processor,re.S).group()
    algorithm_bindings={m[1].strip():m[2].strip() for m in re.finditer(r'\.(\\\S+|\w+)\s*\(([^)]*)\)',algorithm_instance)}
    reset_parent=algorithm_bindings[bindings[reset]]
    reset_cell=next(c for c in re.findall(r'(?m)^    GTP_LUT3 .*?\);',processor,re.S)
                    if re.search(r'\.Z\s*\('+re.escape(reset_parent)+r'\)',c))
    # INIT FB: abort | !rst_n | state0. Standalone leaf stimulus holds
    # abort/state0 low and reconstructs the active-high reset as !rst_n.
    assert ".INIT(8'b11111011)" in reset_cell and '.I0 (abort)' in reset_cell
    assert '.I1 (rst_n)' in reset_cell and '.I2 (state_reg[0])' in reset_cell
    assert bindings['in_valid']=='v2' and 'affine_inside2' in bindings['in_tag']
    assert "1'bx" in bindings['in_tag']
    assert re.search(r'out_tag.*?\\lens_out_tag\[11\]_floating',instance,re.S)
'''
text=text[:start]+new+text[end:]
text=text.replace("[(nx,'nx'),(ny,'ny'),(ix,'~in_x[7]'),(iy,'~in_y[0]'),(reset,'~rst_n')]",
                  "[(ix,'~in_x[7]'),(iy,'~in_y[0]'),(reset,'~rst_n')]")
text=text.replace("'native_lens_'+datetime", "'native_lens_merged_'+datetime")
out.write_text(text,encoding='utf-8',newline='\n')
print(out)
