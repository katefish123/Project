"""Prepare a separate counter-only proposal; never launches an EDA process."""
from pathlib import Path
import json, hashlib, shutil, difflib
R=Path(__file__).resolve().parent
OLD=R/'work_v2/candidate_team_merge1'
NEW=R/'work_v2/candidate_reason_decode1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if NEW.exists():raise SystemExit('Refuse overwrite')
m=json.loads((OLD/'project/source_manifest.json').read_text())
assert {p.name:sha(p) for p in (OLD/'sources').iterdir()}==m['source_sha256']
name='video_correct_ddr_continuous_core.v'
before=(OLD/'sources'/name).read_text()
needle=" if(processed_rejected!=previous_rejected)\n processor_reason_counts[mode_reason*32+:32]<=processor_reason_counts[mode_reason*32+:32]+1'b1;"
assert before.count(needle)==1
lines=[' if(processed_rejected!=previous_rejected)begin',' case(mode_reason)']
for n in range(16):
    lines.append(f" 4'd{n}:processor_reason_counts[{n*32}+:32]<=processor_reason_counts[{n*32}+:32]+1'b1;")
lines+=[' endcase',' end']
after=before.replace(needle,'\n'.join(lines))
(NEW/'project').mkdir(parents=True)
shutil.copytree(OLD/'sources',NEW/'sources');(NEW/'build').mkdir()
(NEW/'sources'/name).write_text(after,encoding='utf-8',newline='\n')
current={p.name:sha(p) for p in (NEW/'sources').iterdir()}
assert {n for n in current if current[n]!=m['source_sha256'][n]}=={name}
tcl=(OLD/'project/build_full.tcl').read_text().replace(OLD.as_posix(),NEW.as_posix())
(NEW/'project/build_full.tcl').write_text(tcl,encoding='utf-8',newline='\n')
m.update(source_sha256=current,build_tcl_sha256=sha(NEW/'project/build_full.tcl'),
 qualified=False,hardware_accepted=False,source_approval_pending=True,
 proposal='Only diagnostic reason-counter dynamic update becomes16 constant-index cases; original physical options retained; no PDS run')
(NEW/'project/source_manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
(NEW/'counter_decode.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='approved_merge1/'+name,tofile='reason_decode1/'+name)),encoding='utf-8')
(NEW/'reason_decode_proposal.json').write_text(json.dumps({'source_sha256':current,
 'parent_source_sha256':json.loads((OLD/'project/source_manifest.json').read_text())['source_sha256'],
 'single_changed_file':name,'target_unchanged':True,'active_decongest4_candidate_mutated':False,
 'qualified_for_board_test':False,'physical_build_started':False,'approval_pending':True,
 'risk':'May trade dynamic word muxes for extra incrementers; synthesis/packing/routing must be measured. No speed or routability improvement asserted.'},indent=2)+'\n',encoding='utf-8')
print(NEW)
