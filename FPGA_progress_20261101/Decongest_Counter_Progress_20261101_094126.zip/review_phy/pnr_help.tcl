pnr -help
