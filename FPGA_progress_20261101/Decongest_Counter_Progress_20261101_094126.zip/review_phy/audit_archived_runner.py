"""Read-only migration evidence audit; no imports from runners, no simulation."""
from pathlib import Path
import ast,hashlib,json,re,datetime
BASE=Path(__file__).resolve().parent.parent
ROOT=BASE/'work_v2';OUT=BASE/'review_phy'
RUNNER=ROOT/'tools/run_archived_video.py'
SNAP=BASE/'FPGA_handoff_20261030/A_lens_20261030/verification'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def variants(data):
    lf=data.replace(b'\r\n',b'\n')
    return [data,lf,lf.replace(b'\n',b'\r\n')]
def historical_match(path,want):
    found=[v for v in variants(path.read_bytes()) if hashlib.sha256(v).hexdigest()==want]
    return {'matched':bool(found),'raw_sha256':sha(path),'expected_sha256':want}
tree=ast.parse(RUNNER.read_text())
cases=next(ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CASES' for t in node.targets))
result={'audit_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audit_script_sha256':sha(Path(__file__)),
        'runner_sha256':sha(RUNNER),'historical':{},'new_runs':[]}
for case,(name,angle,alt,raw,nearest) in cases.items():
    old=SNAP/name;h=json.loads((old/'verification.json').read_text())
    f=json.loads((old/'fixtures.json').read_text());b=historical_match(old/'tb_lens_video.sv',h['bench_sha256'])
    record={'historical_report_sha256':sha(old/'verification.json'),'bench_binding':b,
       'root_fixture_binding':historical_match(old/'fixtures.json',h['fixtures_sha256']),
       'parameters':h['parameters'],'historical_passed':h['passed'],'child_fixture_binding':{}}
    for label in ['primary','alternate']:
        folder=old/('alternate' if label=='alternate' and alt is not None else 'primary')
        record['child_fixture_binding'][label]=historical_match(folder/'fixtures.json',f[label+'_sha256'])
    result['historical'][case]=record
for run in sorted((ROOT/'verification').glob('archived_video_*')):
    if not (run/'inputs.json').exists():continue
    inp=json.loads((run/'inputs.json').read_text());case=inp['case'];name,angle,alt,raw,nearest=cases[case]
    old=SNAP/name;record={'directory':str(run),'case':case,'inputs_sha256':sha(run/'inputs.json'),
       'source_count':len(inp['source_sha256']),'checks':{},'executions':[]}
    c=record['checks'];candidate=Path(inp['candidate']);now={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
    c['current_candidate_matches_inputs']=now==inp['source_sha256']
    c['candidate_manifest_matches_inputs']=json.loads((candidate/'project/source_manifest.json').read_text())['source_sha256']==inp['source_sha256']
    c['manifest_hash_matches_inputs']=sha(candidate/'project/source_manifest.json')==inp['manifest_sha256']
    c['original_snapshot_matches_historical_bench']=sha(run/'archived_bench.original.sv')==inp['archive_bench_sha256']==result['historical'][case]['bench_binding']['expected_sha256']
    text=(run/'archived_bench.original.sv').read_text();arrays=[]
    paths={'source_fixture':run/'primary/source.hex','source_alt':run/('alternate/source.hex' if alt is not None else 'primary/source.hex'),
      'expected_fixture':run/'primary/expected.hex','expected_alt':run/('alternate/expected.hex' if alt is not None else 'primary/expected.hex'),
      'expected_h':run/'primary/H40.hex','expected_h_alt':run/('alternate/H40.hex' if alt is not None else 'primary/H40.hex')}
    def replace(m):
        arrays.append(m[2]);return '$readmemh("'+paths[m[2]].as_posix()+'",'+m[2]+');'
    expected,count=re.subn(r'\$readmemh\("([^"]+)",(\w+)\);',replace,text)
    c['exact_six_unique_path_substitutions']=count==6 and set(arrays)==set(paths) and (run/'tb_lens_video.sv').read_text()==expected
    c['bench_still_matches_inputs_hash']=sha(run/'tb_lens_video.sv')==inp['bench_sha256']
    c['runner_snapshot_matches_inputs_hash']=sha(run/'runner_snapshot.py')==inp['runner_sha256']
    for label in ['primary','alternate']:
        folder=run/('alternate' if label=='alternate' and alt is not None else 'primary')
        oldfolder=old/('alternate' if label=='alternate' and alt is not None else 'primary')
        oldfiles=json.loads((oldfolder/'fixtures.json').read_text())['files']
        c[label+'_hex_files_still_match_history_and_inputs']=all(sha(folder/n)==oldfiles[n]==inp['fixtures'][label]['exact_simulation_files'][n] for n in ['source.hex','expected.hex','H40.hex'])
    if (run/'execution.json').exists():
        for e in json.loads((run/'execution.json').read_text()):
            record['executions'].append({'executable':e['argv'][0],'exit_code':e['exit_code'],'log':e['log'],
                'log_hash_matches':sha(run/e['log'])==e['log_sha256'],'log_sha256':sha(run/e['log'])})
    record['verification_exists']=(run/'verification.json').exists()
    if record['verification_exists']:
        v=json.loads((run/'verification.json').read_text());record['verification']={'passed':v['passed'],'freshness':v['freshness'],'failure':v['failure']}
        record['verification_sha256']=sha(run/'verification.json')
        c['verification_inputs_binding']=v['inputs_sha256']==sha(run/'inputs.json')
        c['verification_execution_binding']=v['execution_sha256']==sha(run/'execution.json')
        c['verification_source_binding']=v['source_sha256']==inp['source_sha256']
        c['verification_log_binding']=v['simulation_log_sha256']==sha(run/'simulation.log') and v['compile_log_sha256']==sha(run/'compile.log')
    record['control_artifacts_current_sha256']={n:sha(run/n) for n in ['run.do','modelsim.ini'] if (run/n).exists()}
    result['new_runs'].append(record)
(OUT/'ARCHIVED_RUNNER_EVIDENCE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'historical':{k:{'bench':v['bench_binding']['matched'],'root_fixture':v['root_fixture_binding']['matched'],'children':[x['matched'] for x in v['child_fixture_binding'].values()]} for k,v in result['historical'].items()},
 'runs':[{'case':r['case'],'directory':r['directory'],'source_count':r['source_count'],'all_checks':all(r['checks'].values()),'verification_exists':r['verification_exists'],'executions':len(r['executions'])} for r in result['new_runs']]},indent=2))
