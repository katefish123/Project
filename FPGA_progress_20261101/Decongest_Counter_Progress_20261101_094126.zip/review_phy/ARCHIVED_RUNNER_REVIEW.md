# Archived V2 视频迁移与 native 门禁审查（只读）

审查对象：`work_v2/tools/run_archived_video.py`、两次90°运行目录、冻结五模式历史bench/verification/fixture记录，以及新增`audit_resume_native.py`与其parser/checker。未启动仿真/PDS，未修改root工具或生产候选。离线补验脚本与结果保存在本目录。

## 结论

未发现当前迁移把旧PASS当成新PASS、删除逐像素检查或删除新帧间隔检查。旧bench的SHA被验证，只换六个readmemh路径，当前151源输入确实重新编译，首轮ini错误被保留为失败。第二轮90°在本次取证时尚无最终verification，因此本审查不把它计作新通过。

初审发现的历史fixture记录链断点已由root在新版runner补齐；正在运行的旧snapshot未被改动。本次独立离线验算为这两次90°补封同一aggregate→child→hex链，实际全部匹配，无须因此重跑仿真。五模式历史链也全部匹配。

新native auditor确实拒绝真实V2失败报告与缺corner变体，重新解析V1真实144IO，仅把V2失败报告作为104覆盖键清单，没有把旧timing pass复用成当前timing。但它还不是“最终物理DB、独立STA与bitstream配对闭包”的完整签核器；具体门禁要求见后文。

## 已实际核查的迁移闭包

`audit_archived_runner.py`读取文件，未import或执行视频runner。实际结果见`ARCHIVED_RUNNER_EVIDENCE.json`，其中绑定当前helper SHA、每个历史verification SHA、两次新inputs SHA和run control文件当前SHA。

1. 五模式历史bench均可由raw/LF/CRLF有限规范化精确还原至其`verification.bench_sha256`。没有以“语义相近”代替SHA。模式分别zero0°、ninety90°、switch0/90°、raw、nearest12°；均frames6、phase0、非measurement_only。
2. 每个历史`fixtures.json`对`verification.fixtures_sha256`匹配；aggregate中的primary_sha256/alternate_sha256对真实child记录匹配；child记录再给出source.hex、expected.hex、H40.hex的历史hash。五组全部通过。
3. 两次新ninety均为151项source SHA，和inputs、当前candidate_v2_timing2源码、source_manifest、manifest自身hash一致。这里是完整输入身份绑定，不代表151项全部参与行为仿真：compile选择`.v`并明确排除DDR IP/PLL实现文件；板级PHY/PLL时序由native和clock tests另证。
4. 两次已保存的`archived_bench.original.sv`字节SHA等于历史bench记录。独立重新构造六个替换后与本次bench完全一致；六个数组各出现一次：source_fixture/source_alt/expected_fixture/expected_alt/expected_h/expected_h_alt。除此之外没有字符修改（文本换行规范化除外）。`runner_snapshot.py`对inputs.runner_sha256也匹配。
5. 两次新primary/alternate的3hex目前仍逐文件匹配历史与inputs记录；non-switch alternate指向同primary，switch历史确有alternate。实际源码与fixture在本次离线重查时没有漂移。
6. execution.json已完成的每条实际argv/cwd/exitcode/logSHA重新核对，均匹配实际日志；正在运行的vsim尚未结束时只出现前三条记录是合理的，不能视为缺失的成功返回码。

初审旧runner仅记录child hash、未验证aggregate链；root新版`bound_json`现在明确先校aggregate再校child，且只接受已知expectedSHA的raw/LF/CRLF三种字节。当前helper和正在跑的runner_snapshot SHA不同是有意版本边界，本次补验结果不把snapshot伪装成新版代码。

## scoreboard、帧新鲜度与服务模型

以冻结90°bench原始行号为例，迁移后逐字保留：

- :114–115合法内存命令与engine/source fault检查。
- :127–135 RAW/结果BANK不可覆盖在显帧；source写与corrected DDR写均逐RGB字检查。
- :150–160独立统计image_swap_pulse+不同frame ID的新帧，计算max_fresh_gap；:156的33,333,500ns期限仍在。
- :172–182模式/实际源BANK身份/ID单调/边界黑色及每个HDMI像素精确比较仍在。
- :190 RAW不得调用处理器；:196的H40系数检查；:204运行路径必须连接RUNTIME_AFFINE/TILED_ORDER/cache128仍在。
- :212–218必须六个不同完整scan、至少6×1920×1080逐像素检查、足够实际写量与publication，然后才打印FRESH30_RESULT和PASS。
- :220有全局timeout，:228 processor与writer tiled-order一致检查仍在。

固定bench依然使用READ_DELAY28、WRITE_DELAY18和事务周期性的延迟spike；没有放宽DDR服务模型。新runner还要求FRESH30_RESULT存在、swaps>=6且max_gap<=33,333,500ns，Fatal/Error/Warning均拒绝。bench内部只从第三次fresh swap起直接fatal间隔，但它统计包含早期gap的maximum，新runner对max_gap的判据没有跳过初始两帧。

这是约六帧的模型化1920×1080/30fps证据；不能据此声称板上30fps、长时间稳定或实测端到端延迟。原`tb_1080p30.sv`在交接树仍未找到，所以其原始SHA无法重现；保留“archived derived bench”名称和缺失边界是必要的。

## 当前两次90°状态

- `archived_video_ninety_20261031_144725_055717`：实际4条执行记录。vsim报vsim-7无法打开带反斜杠/花括号的modelsim.ini路径，verification.passed=false、failure=simulation.log、freshness=null；没有当成资格。
- `archived_video_ninety_20261031_144737_402134`：Path.as_posix修复后重新执行，前三条vlib/vmap/vlog退出0，已出现真实新帧与处理日志；取证时未有最终verification。运行中日志不具有最终SHA，不进行通过推断。

其它四模式尚待root调度实际新运行。历史5个passed=true仅用于提供冻结测试资产与参考参数，不补齐当前矩阵。

## 视频门禁建议（多数可最终离线封存，无需重新仿真）

1. 合格集合必须五模式各有**当前同一151 source SHA**、新目录、完成的4条执行/全部exit0、最终新verification.passed和日志hash；遗漏/运行中/首轮失败不能用历史报告补位。
2. 当前旧snapshot运行使用本次离线closure结果补封；记录独立helper SHA、历史report/aggregate/child/三hex及本次inputs SHA。不要事后重写正在跑的inputs/runner_snapshot。
3. 封存最终bench、runner_snapshot、run.do、modelsim.ini、oracle snapshot及全部文件SHA。当前inputs没有绑定run.do/ini字节；本审查已记录当前二者SHA，但这是当前快照，不是执行前证明。最终qualified结果宜把实际执行控制文件纳入artifact清单，并离线核对run.do仍是固定run-all/error策略。
4. 运行结束后重查bench/fixtures/hash链。现runner已复核生产sources，但没有在pass表达式里复核bench/fixtures/control文件；正常隔离目录没有被改动的证据，本次离线检查也全部匹配。将此作为最终封存门禁，避免资格后证据漂移。
5. 明确simulation compile exclusions，不把inputs里的PHY `.vp`/FDC身份绑定描述成它们的行为或时序验证。
6. 原assess_candidate.py目前仍筛选`video_*`、`native_audit.json`且依赖缺失的C:/D原baseline；新`archived_video_*`和`native_resume_audit.json`不会自动被旧聚合器接受。这会安全拒绝/缺项或异常，并非假通过。后续集成必须显式新增迁移证据角色，保留baseline_integrity_reproduced=false，不重命名旧报告冒充旧闭包。

## native迁移门禁只读复核

`NATIVE_GATE_READONLY_CHECK.json`绑定三个工具SHA，实际纯读取调用确认：

- 真实失败V2 timing被拒绝；失败报告有104summary rows。
- 缺Fast Hold或缺Slow Setup的两个变体均被拒绝。
- V1真实PRR/PRT与记录重新解析144IO成功。

root已实际运行的check_resume_auditor还覆盖UART错脚拒绝；本审查读取其实现，确实把B24 PRR变B23、PRT保留原样，必须在package/electrical比较处拒绝。

`audit_resume_native.py:15–28`调用默认require_pass=True的parser：必须All Constraints Met，十节两角唯一、每节非空、所有数值finite、slack/TNS非负且fail endpoints0、slow/fast覆盖相等，再与V2真实失败报告的104个(kind,corner,clocks)键精确相等，检查13个时钟周期。它不会因V2旧报告“覆盖存在”就绕过本次timing。

`:30–53`比对当前/旧PRR、当前/旧PRT、旧native_audit.normalized_io三方；IO set144、pad/direction/constrained/cell/function/physical-bank相同、电气列全部相同。对PDS bank列统一标签缺陷的规范化沿用PRT physical function bank，但并未放开真实pad或IO电气。

`:57–66`还要求本次build.completed/returncode0/source unchanged/current源与manifest一致、manifest/TCL/logSHA匹配和实际Generate Bitstream done token。运行中新build不满足这些条件，不会被签核。

仍需补的物理签核闭包：

- **[P1，最终资格前]** 当前native_resume_audit只绑定RTR内容、输入源与build log，没有显式冻结`place_route`物理DB、对应report_timing实际input DB和bitgen实际input DB/最终sbit+smsk的同一性。新唯一build目录+从头全流程降低旧报告串用风险，但不等价独立同DB STA/bitgen证明。最终物理资格需这些DB/worker/action与产物SHA，且缺文件或不配对拒绝，不能只凭done token。
- **[P2]** parser目标检查包含PG2L100H/FBG676/2022.2-SP6.4/multi corner，未显式要求Speed Grade=-6；period检查不检查waveform/相位，coverage keys不检查各类路径endpoint数。因此它单独不是时序约束未被放宽的证明。当前FDC逐字绑定与独立clock约束检查应作为资格前提，并显式保持同speedgrade/原clock relationships/exceptions。不要拿“104键相同”替代约束身份。
- **[P2]** `native_resume_audit.json`如遇missing/乱码report会异常退出而没有统一失败JSON，属于可诊断性缺口；调用方须把无有效审计结果当作不通过。其当前异常并不会安全地转成passed=true。
- 旧IO normalized audit现在作为已冻结信任锚使用，并通过真实报告重复比对。封存时继续绑定其自身SHA；不可将V1 timing资格嫁接到本次V2。

未发现现有负timing行、缺corner或UART错脚会被这套判据放过；上述缺口针对最终证据配对和约束身份，不是对正在跑的PDS结果作失败/通过预言。

## 审查结束补记

最后一次重查时，第二轮ninety已实际结束并通过：4条真实执行均exit0，new verification.passed=true，sources_unchanged=true，swaps6、max_gap33,333,300ns，逐像素12,441,600，unique_scans6、published7。最终inputs/execution/log/source链也已重新校对，全部匹配；simulation.log SHA256为61f9e4e512dce0569d3724c6a290b6c670af44c8c2e48a7c7efa4d41b02114de。它可以计入当前90°模型仿真证据，不能扩展成其余四模式或native物理通过。

此时zero新目录archived_video_zero_20261031_145239_419965正在运行，已有151源与6-path/3hex链补验，尚无final verification，不计通过。前文“第二轮未完成”描述保留为初次取证时点，最终以本段及JSON audit_utc快照为准。
