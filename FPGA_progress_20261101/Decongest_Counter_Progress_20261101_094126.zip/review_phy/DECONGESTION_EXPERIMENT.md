# Controlled congestion repair, 2026-11-01

Scope already authorized by the user's resume: diagnose the actual Route-0008 failure and run isolated, evidence-based repairs without changing target clocks, source semantics or numerical algorithms.

The original detailed router ended with Route-4022 (congestion), 35,026 unrouted nets and Route-0008. This is a routing failure, not a failed final timing audit. Its physical report used CLMA 11,480/11,675 and CLMS 4,901/4,975. Those occupied-cluster counts do not prove logic exhaustion or pinpoint a congested region. The 6,136-load engine CE also exists in the prior candidate and is a hypothesis, not an established cause.

Alternatives: (1) use the vendor's placement decongestion option on unchanged RTL; (2) redesign and distribute the payload CE, requiring a new source approval and functional validation; (3) change packing strategy, another separate experiment. Prefer (1) first because the tool explicitly diagnoses congestion and it changes no functional contract. No seed sweep or blind repeat is planned.

Single semantic variable: placement decongestion from the installed documented default 1 to 4. The installed User Guide physical PDF pages 112, 118 and 252 documents the option, its area/timing tradeoff and conservative 0..4 range at high resource use. Seeds 73/91, performance mode, all clocks/FDC, corner optimization, routing options and final acceptance gates stay unchanged. Path relocation is recorded separately.

Create candidate_team_decongest4 with exactly the approved 151 source bytes. Keep the failed candidate immutable. Run one complete fresh physical build. No old failed routed DB is eligible for timing or bit generation. Compare actual routing convergence and final result; a changed placement or faster initial route is not success. Require every native timing/IO gate, then independent same-DB STA/paired bit generation and package checks. An option that worsens timing is rejected by the same gates.

No implementation success, board qualification or hardware acceptance is asserted here. At the user's actual quota threshold <=10%, preserve recoverable progress and stop further optimization; root alone uploads. Quota is checked by root at its estimated check time, not by this development chat.
