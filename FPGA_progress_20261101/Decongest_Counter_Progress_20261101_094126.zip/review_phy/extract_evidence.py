"""Read-only local timing evidence extraction; starts no implementation tools."""
from pathlib import Path
import re,json,hashlib,difflib
OUT=Path(__file__).resolve().parent
BASE=OUT.parent/'FPGA_handoff_20261030/A_lens_20261030/candidate_host_angle_v2_product_stage'
BUILD=BASE/'build/pds_20261030_135116_814250'
OLD=Path('D:/FPGA/deliveries/FullHD_LiveRepair_20261024')
REPORTS={f'v2_ite{i}':BUILD/f'place_route/route_constraint_ite_{i}/video_correct_ddr_top.rtr' for i in (1,2)}
REPORTS['old_reference']=OLD/'validation/final_timing.rtr'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
all_paths={};extract=[]
for name,p in REPORTS.items():
    text=p.read_text(errors='replace');rows=[]
    for m in re.finditer(r'^Startpoint\s+:.*?^ Slack \((?:MET|VIOLATED)\).*?$',text,re.M|re.S):
        block=m.group();line=text.count('\n',0,m.start())+1
        def field(key):
            mm=re.search(r'^'+re.escape(key)+r'\s+:\s*(.*)',block,re.M)
            return mm.group(1).strip() if mm else None
        slack=float(re.search(r'^ Slack \((?:MET|VIOLATED)\)\s+(-?[\d.]+)',block,re.M).group(1))
        if field('Path Group') in ('phy_dq_sysclk_0','phy_dq_sysclk_1'):
            rows.append({'line':line,'start':field('Startpoint'),'end':field('Endpoint'),'group':field('Path Group'),
                         'type':field('Path Type'),'skew':field('Clock Skew'),'slack_ns':slack})
            extract.append(f'\n### {name}:{line}\n'+block+'\n')
    all_paths[name]=rows
(OUT/'phy_paths.json').write_text(json.dumps(all_paths,indent=2)+'\n')
(OUT/'phy_path_blocks.txt').write_text(''.join(extract))
for label,p in REPORTS.items():
    s=p.read_text(errors='replace').splitlines()
    (OUT/(label+'_summary.txt')).write_text('\n'.join(f'{i+1}: {s[i]}' for i in range(min(240,len(s))))+'\n')
oldfdc=OLD/'sources/board_ddr.fdc';newfdc=BASE/'sources/board_ddr.fdc'
a=oldfdc.read_text().splitlines();b=newfdc.read_text().splitlines()
(OUT/'fdc_reference.diff').write_text('\n'.join(difflib.unified_diff(a,b,fromfile=str(oldfdc),tofile=str(newfdc)))+'\n')
log=BUILD/'place_route/route_constraint_ite_2/run.log'
lines=log.read_text(errors='replace').splitlines()
(OUT/'current_rcf_parse_excerpt.txt').write_text('\n'.join(f'{i+1}: {lines[i]}' for i in range(60, min(86,len(lines))))+'\n')
official=Path('D:/softwares/PDS/PDS_2022.2-SP6.4/ip/system_ip/ips2l_hmic_s/ips2l_hmic_eval/ips2l_hmic_s/createFiles.tcl')
lines=official.read_text(errors='replace').splitlines()
(OUT/'official_whole_net_syntax.txt').write_text('\n'.join(f'{i+1}: {lines[i]}' for i in range(524,537))+'\n')
inputs=[*REPORTS.values(),oldfdc,newfdc,log,BASE/'project/build_full.tcl',BASE/'project/build_parent_reference.tcl',BUILD/'impl.tcl',official]
ipnames=['ddr3_ip.v','ddr3_ip_ddrphy_top.v','ddr3_ip_slice_top_v1_10.v']
inputs += [folder/n for folder in [BASE/'sources',OLD/'sources'] for n in ipnames]
manifest={'scope':'Read-only audit; no PDS, ModelSim, hardware, or production edits',
          'inputs_sha256':{str(p):sha(p) for p in inputs},'script_sha256':sha(Path(__file__)),
          'checkpoint_files_in_supplied_build':[str(p.relative_to(BUILD)) for p in BUILD.rglob('*') if p.suffix.lower() in ('.adf','.pcf','.rcf')],
          'ddr_constraint_section_equal':a[365:1017]==b[365:1017]}
manifest['old_reference_ip_file_equality']={n:sha(BASE/'sources'/n)==sha(OLD/'sources'/n) for n in ipnames}
(OUT/'evidence_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'reports':{n:len(v) for n,v in all_paths.items()},'ddr_section_equal':manifest['ddr_constraint_section_equal'],'checkpoints':manifest['checkpoint_files_in_supplied_build']},indent=2))
