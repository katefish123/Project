# 合并候选长详细路由只读诊断（2026-11-01）

对象：`work_v2/candidate_team_merge1/build/pds_20261031_224731_129913`。未启动、终止或修改任何PDS/仿真进程；生产源、TCL、FDC、PCF均只读。

**建议：让当前唯一构建继续推进，等待当前详细路由轮完成；现有证据不足以合理重启、换seed、调整priority或改CE实现。** 没有最终RTR，不能预测时序合格，也不能把当前慢解释为死锁。

## 实际进展

独立子日志 `place_route/route_constraint_ite_1/run.log:131–181`（快照见同目录MERGED_ROUTE_DETAIL_SNAPSHOT.log）：global route在iteration51降到0，随后打印Global routing takes109.55sec / Total116218subnets，之后进入详细路由。

| 详细轮 | unrouted | 本轮CPU秒 |
|---|---:|---:|
|0|89723|22.281|
|5|67549|119.875|
|10|51843|546.438|
|11|49826|713.547|
|12|48476|922.266|
|13|47110|724.359|
|14|45792|731.391|

这15个已完成详细轮的unrouted严格下降，总降43931（约48.96%）。最近三轮分别再少1350、1366、1318，仍有实质正进展；每轮CPU时间并非单调上升（922→724→731），不支持仅以“越来越慢”判定卡死。global0与detail45k是不同阶段，不能当作已经布好后又丢掉45k网。bucket size扩大仅能说明搜索工作变化，缺少设备分区overflow/资源明细，不能据此定位具体拥塞点。

主/子日志本次读取时均最后更新在00:42:05，末轮14；总日志与子日志一致，没有最终RTR。本报告不以读取时间戳推断进程是否故障；root取得的同build进程CPU增长是补充活性证据。root提供的freeRAM约2GB/private2.7GB/WS1GB也不构成内存耗尽证明；本审查未自行测得page-fault/IO-stall数据，不能完全排除内存压力，但没有据此中断任务的依据。

## 特殊物理约束与priority

- 实际加载的是`device_map/video_correct_ddr_top.pcf`。其149–151仅三条PHY实例固定：两IOCLK gate CLMA357354/357660 FF3和CPD369466；其余为端口绑定。没有额外def_route/region/用户实例簇或大量固定cell。
- 源FDC对应387–389正是同三条固定PHY位置。没有额外PAP_REGION/用户placement固定点。端口share-pin提示随后均成功，不是未满足约束。
- 正在运行ite1子日志没有执行用户RCF，也没有旧V2那种CA带冒号load的RouteConstraintEditor2001/2006。因此不能把旧失败的自动branch RCF解析问题套用为当前首次详细路由慢的原因。
- 实际TCL与build.log27370的PNR参数一致：place73/route91，performance、dc_duplication、multi_corner、slack_prior_in_global_router、3次route-constraint迭代、slack0.3、fix_hold_threshold50。与前次既有配置一致，没有发现负数/极端priority参数或新增手工route。0.3是优化目标、50是hold修复余量，不能擅自改成放宽签核。

## 高扇出/CE与局部拥塞的证据边界

主build.log24247有maximumfanout6136；同时存在Unable to honor max fanout constraint（包括DDR IP的data_in_ready_1和大量N*综合网）。这是真实高扇出压力线索，却没有给出对应6136扇出的网名、CE sink清单或它在哪个region造成overflow。

FF统计表的YES CE条目至少有13553个寄存器。其含义是大量寄存器带CE，不是“同一个CE网驱动13553个sink”。全设计最大fanout也可能包括时钟/复位或其它控制网，不能直接归到新增merged RTL某个valid/enable。

只读搜索生产.v的syn_keep/syn_preserve/PAP_LOC/region：发现的保留属性仅为已有async FIFO/snapshot reset-release同步级；没有新添加针对大结果阵列的dont-touch/maxfan布局禁令。clock_utilization报告证明专用clock buffers已分配；其容量表是资源清单，不是局部布线拥塞图。

因此LUT60%、DRM70%不能证明无局部拥塞，也不足以证明死局；当前资料没有把慢路由定位到特定CE网的可证因果链。不能为“修慢”无证据复制寄存器、重构CE、加约束或启动并行seed。

## 一项可执行安排

继续当前唯一进程，下一次**新详细轮日志落盘**后对比该子日志的iteration/unrouted/CPU增长。当前应等待，不重启。若仍下降则保留运行；若以后出现多轮无下降、明确fatal/资源分配错误或CPU/日志均停止，再先封存日志与当前checkpoint，依据具体错误决定下一步，不用任意固定时长直接判死。

待出现实际详细路由/STA报告后，按其真实最差setup/hold端点及具体网fanout再定位；如工具提供region拥塞/overflow表，优先收集那份实际输出。现在没有这类证据，故不提出“调一个priority必然改善”的实验。

## 证据封存

MERGED_ROUTE_PROGRESS_EVIDENCE.json保存此次15轮数值、只读输入SHA和当时RTR清单（空）；MERGED_ROUTE_DETAIL_SNAPSHOT.log是子日志当前字节快照。活动日志随后会变化，快照hash仅代表本次观察，不要求活日志保持静止。
