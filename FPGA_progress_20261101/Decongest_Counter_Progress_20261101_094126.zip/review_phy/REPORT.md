# V2 DDRPHY 物理时序只读复核（2026-10-31）

本次没有启动 PDS/ModelSim、没有设备操作、没有修改生产 RTL/FDC/TCL。审查对象是交接 V2 的 ite1、ite2 实际 RTR、对应实现日志和约束；不能将它们当成新的签核结果。

## 结论

DDRPHY 跨域 setup 的直接失败机制是有很大真实布线延时的 CA 控制路径；hold 是另一条过短的 CKE 控制路径。报告里存在约 -2.5ns 的 setup clock skew，但旧合格实现几乎同样的 skew，不支持“新增错误时钟相位/clock definition 导致这次失败”的判断。当前自动路由优化的两条 CA load 约束还确实被解析器拒绝，给出了一个有针对性的最小物理实验：保留同 map/place 和原 seed91，只补一条 CA whole-net priority RCF。它仅用于检验该网的路由资源分配，不能保证 setup 收敛，也没有理由声称能修复 CKE hold。

交接目录未包含 `.adf/.pcf/.rcf` 实现输入（脚本递归实查为空），不能直接从报告恢复同 checkpoint 重路由。要么找回此次原 map/place/PCF，要么先对当前待测源生成并冻结一个 baseline checkpoint，再从同一 checkpoint 做单项 A/B。不要用旧版本 DB 搭配 V2 源。

## 实际数值

以下都是 ddrphy_sysclk -> phy_dq_sysclk_0，单位 ns。完整原始行号保存在 `v2_ite1_summary.txt` / `v2_ite2_summary.txt` / `old_reference_summary.txt`。

| 报告 | slow setup WNS | slow hold WHS | fast setup WNS | fast hold WHS |
|---|---:|---:|---:|---:|
| V2 ite1 | -2.391 | -0.596 | +1.533 | -0.605 |
| V2 ite2 | -2.144 | -0.460 | +1.464 | -0.514 |
| 10/24旧合格参考 | +0.421 | +0.711 | +3.037 | +0.291 |

ite2 还有 ddrphy_sysclk -> phy_dq_sysclk_1 slow setup -0.710ns，以及 UI 同域 setup -1.036ns、processing -0.655ns。UI 时钟名包含 ddrphy 并不代表每条路径都在 PHY：同域最坏是用户 engine/result cache 相关路径（ite2:2943–3028），其它失败包括 selftest 和 display RAM 数据路径。不能把全部 UI setup 失败归到 DDRPHY 专用物理单元。

## setup 证据：CA 路由，不是增加算法逻辑级数

ite2 RTR:4054–4130 最坏 PHY setup：

- 起点 `i_dqs_group[3]...this_group_ca_dly`，CLMA_285_546；终点 `i_mem_addr_0[0]...TX_DATA[2]`，IOLHR_364_522。
- 中间 reduction LUT `i_dqs_group[0]...all_group_ca_dly_r2` 在 CLMA_285_534；最终 `adj_addr_7:0_2[0]` 在 CLMA_357_529。
- 数据延时：Logic0.764ns、Route7.965ns（91.248%），总8.729ns，仅2级逻辑。
- 路由分段：`debug_data [273]` 3.695ns；`all_group_ca_dly` fanout52 为2.445ns；最终 `adj_addr [1]` 到 IO 为1.825ns。不能只盯52扇出网，最慢的第一段比它更长。
- Launch clock delay5.543ns，capture delay2.617ns，CPR+0.417，skew=-2.509ns；capture edge10ns（既有 multicycle2），required12.128ns、arrival14.272ns，slack=-2.144ns。
- ite1 最坏起点是 `phy_addr_r[2]`（4110行），该数据网单段路由5.117ns；同迭代也存在 CA reduction 路径（4191行起）。所以两个迭代的最差起点发生轮换，体现多个分支的路由压力，不能把一个最差网名当成全部原因。

这些证明真实数据布线延时过长；仅由文字 RTR 不能进一步确定具体拥塞资源、哪些可用线段被占、某个合法新 cell site。不要凭 CLMA 坐标猜 PCF 槽位，也不要直接把 `_perm` 路径当成可接受的物理约束实例名。

## hold 证据：独立短支路，不能靠 setup priority 保证修复

ite2:4297–4369 slow hold：`phy_cke_r[1]`（CLMS_339_421）到 `u_outbuft_cke/TX_DATA[3]`（IOLHR_364_426）。只有 tco0.158 + route0.414 =0.572ns、0级逻辑；arrival4.719ns，required5.179ns，hold=-0.460ns。TX_DATA[5]/[7]同源同数值。fast 最坏在12088行起，WHS=-0.514ns。

这是需要增加该最小数据路径真实延时/改变经过合法资源的路径的问题。移动 PLL/IOCLKDIV、改相位或切掉这些路径都没有依据；把 CA setup 路线缩短也可能损害其它 hold。现 TCL 已启用 `-optimize_multi_corner_timing`、`-fix_hold_violation_threshold 50`；50ps是优化余量，不能把它当成允许负hold的签核阈值。

## 旧合格参考查证与边界

参考是 `D:/FPGA/deliveries/FullHD_LiveRepair_20261024/validation/final_timing.rtr`，实际写明 All Constraints Met。它只提供本机可实现经验，不能作为 V2 的资格。

- 本次实际 diff 证明 FDC 第366–1017行 DDR reference/generated clocks、edges、multicycle、uncertainty、固定PHY site及全部DDR管脚约束逐行相同。clock groups也相同。
- 差异是 processing period17.508418->10.774410、pixel period6.734007->13.468013，以及新UART pin约束；没有通过换DDR频率/时序定义取得参考合格。
- 三个明文 DDR IP 文件 `ddr3_ip.v`、`ddr3_ip_ddrphy_top.v`、`ddr3_ip_slice_top_v1_10.v` SHA256都相同。未声称所有加密文件/用户逻辑/映射相同。
- 旧参考最坏CA路径（4103行起）launch5.549/capture2.617/CPR0.417，skew=-2.515ns，和V2 -2.509仅差6ps。旧CA起点CLMA315552，reduction CLMA309582；旧worst endpoint是RAS IO，不是V2同一个地址端点，不能把两条数据路径直接逐段相减当成因果量。
- 旧最坏hold skew=-1.497，V2=-1.498，时钟差也近乎不变；旧最坏hold端点为CS，说明旧报告top3未给CKE精确最小路径，不能声称CKE增加了具体多少路由。

本机旧经验 `output/live_repair_20261024/timing_hold_audit/CA_PHYSICAL_OPTIONS_20261024.md`、`output/stall_repair_20261024/physical_fallback/DESIGN.md`记录过相同带冒号load解析问题；本次已用V2自身日志重新证实，不套用旧结论。

## 当前自动RCF有可复现的解析失败

V2 `place_route/route_constraint_ite_2/run.log:66–74`：

- `phy_addr_r [2]` 到 `adj_addr_7:0_2[0]/...:I3` 被识别为截断的 `adj_addr_7` invalid。
- `all_group_ca_dly` 到 `adj_addr_7:0_2[2]/...:I3` 同样 invalid。
- `all_group_ca_dly` 到 `adj_addr_15:8_2[3]/...:I2` 被截为 `adj_addr_15` invalid。
- 错误为 RouteConstraintEditor-2001/2006，原文件名指向 `all_route_constraint_ite.rcf`；该RCF本体不在交接包，但日志保留了语句和失败。
- 第75–76行对 `debug_data [66]` 的 branch priority成功。这不支持“全部自动RCF均无效”，也不能证明网273获得同样优先级。

## 仅建议一个物理实验（未执行）

独立 `ca_whole_net.PROPOSED.rcf` 只有：

```tcl
def_route -prior_net {memory_ip/u_ddrphy_top/ddrphy_slice_top/all_group_ca_dly}
```

语法在本机官方 IP 生成器 `D:/softwares/PDS/PDS_2022.2-SP6.4/ip/system_ip/ips2l_hmic_s/ips2l_hmic_eval/ips2l_hmic_s/createFiles.tcl:525–534` 输出同形式whole-net priority；摘录已保存。网名由V2 RTR与解析日志双方确认。避开-load能避免这条用户约束经过带冒号load的解析路径，不能修复工具自动生成的其它branch约束。

因果假设：当前CA priority分支被拒绝，fanout52有2.445ns路由，给这一个网完整优先级可能重新分配快线，减少CA setup数据延时。**不是保证**：其上游3.695ns和末段1.825ns仍可能主导；CKE hold和其它域仍可能失败。

执行前必须找回/重新产生并冻结 baseline map、placement、PCF和完整源/约束清单。从同一baseline仅添加这一RCF，以同gplace73/groute91及原优化选项重路由一次；不重新综合网表、不换seed、不改FDC或IO电气、不加falsepath/multicycle、不移动专用PLL/IOCLKDIV。缺失map/place时不提供假装可直接执行的TCL。

判别输出：用户whole-net语句解析成功；记录3.695/2.445/1.825各段、source/reduction/final LUT位置、setup clock skew、CKE slow/fast hold和全部时钟域。若CA网路由确实缩短且相应路径改善，支持该机制；若仍由其它段主导，记为单项实验未解决，不无穷换seed。任何合格声明仍要求对最终同一DB执行独立全域两角setup/hold/其它原签核检查；不能复用10/24报告。

对后续 hold 的唯一当前建议是先从待测DB查询该CKE支路实际min/max路线与可用合法路由资源，再决定一次局部延时修复。报告没有合法目标pin链/site，故不编造manual_route或placement命令，避免把它混进本次单项实验。

## 产物

`evidence_manifest.json`绑定原始文件SHA256与本次提取脚本；`phy_paths.json`/`phy_path_blocks.txt`逐条保存三份报告的全部24条跨PHY路径及原始起始行号；summary、FDC diff、当前解析错误和官方语法摘录可独立核查。实验RCF仅为提案，未加载。
