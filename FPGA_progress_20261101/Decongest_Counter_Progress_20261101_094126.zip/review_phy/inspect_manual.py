"""Read installed official PDS docs; print bounded option excerpts only."""
from pathlib import Path
import pymupdf,re
root=Path('D:/softwares/PDS/PDS_2022.2-SP6.4/doc')
for name in ['Pango_Design_Suite_User_Guide.pdf','Timing_Analyzer_User_Guide.pdf','Route_Constraint_Editor_User_Guide.pdf']:
 with pymupdf.open(root/name) as doc:
  count=0
  for number,page in enumerate(doc):
   text=page.get_text()
   matches=list(re.finditer(r'fix[_\s-]*hold[_\s-]*violation|hold violation.*(?:fix|optim)',text,re.I))
   if matches:
    print(name,'page',number+1)
    for m in matches[:2]:print(text[max(0,m.start()-180):m.end()+520])
    count+=1
    if count>=5:break
