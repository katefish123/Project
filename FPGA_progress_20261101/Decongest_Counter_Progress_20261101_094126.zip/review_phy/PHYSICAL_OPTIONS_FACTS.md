# Installed PDS options: evidence for later physical repair

These are observations, not an authorization to alter the active implementation.

Primary source: installed `D:/softwares/PDS/PDS_2022.2-SP6.4/doc/Pango_Design_Suite_User_Guide.pdf`, physical PDF pages110–118 and253. Page118 was rendered and visually inspected; the vendor explicitly identifies PG2L100H as a single-thread router using the Logos-series general/router option defaults. Therefore one fully used CPU core is expected; it is not evidence of a frozen process or a reason to launch another build.

The manual distinguishes post-route hold optimization from hold optimization during routing. Post-route repair defaults off; in-route repair defaults on. In-route extra optimization margins default to200ps for clock paths crossingSRB and100ps for clock-tree paths. The threshold alone is not equivalent to the post-route enable flag. Final acceptance must still inspect actual hold slacks/endpoints.

The team increment's TCL explicitly uses `-fix_hold_violation`, seeds37/41, one route-constraint iteration, and ends with timing analysis. The current independently frozen full-flow TCL uses seeds73/91, three constraint iterations and paired bitgen; it specifies a50ps post-hold threshold but has no explicit post-hold-enable option in the saved project. This does **not** establish that current hold will fail: in-route repair still exists, and no final current report exists yet. Do not retrospectively edit the active TCL or its manifest to match another recipe.

The vendor also documents placement decongestion as an area/routing-time versus timing tradeoff. It is a possible controlled future experiment only after actual evidence warrants it, not a reason to sweep seeds or lower timing requirements now.

If actual final hold violations remain, explicit post-hold repair is a documented candidate for a separate, provenance-bound physical experiment. Do not silently combine it with the one-variable CA whole-net RCF experiment. Keep all original clocks, relationships, exceptions and all104-corner checks. A threshold or option does not replace an actual passing report.

If the flow ever completes a full routed iteration that already meets all104 timing rows and144IO, further QoR retries are not the acceptance requirement. Selecting such an immutable routed result would still require a separately reviewed source/DB provenance path plus a fresh same-DB STA and paired bitgen; a placement estimate or mid-route slack cannot be used. Current finishing scripts deliberately continue to reject incomplete original flows and have not been weakened to accept an unfinished stage.

No PDS process was started/stopped, and no active source/constraint/recipe was modified during this inspection.
