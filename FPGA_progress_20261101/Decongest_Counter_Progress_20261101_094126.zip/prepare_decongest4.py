"""Derive one isolated, source-identical placement congestion experiment."""
from pathlib import Path
import hashlib, json, shutil

ROOT = Path(__file__).resolve().parent
old = ROOT / 'work_v2/candidate_team_merge1'
new = ROOT / 'work_v2/candidate_team_decongest4'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
if new.exists():
    raise SystemExit('Refusing candidate overwrite')
manifest = json.loads((old / 'project/source_manifest.json').read_text())
actual = {p.name: sha(p) for p in (old / 'sources').iterdir() if p.is_file()}
assert len(actual) == 151 and actual == manifest['source_sha256']
approved = json.loads((ROOT / 'team_merge_review/approved_merge1_sources.json').read_text())
assert actual == approved['source_sha256']
original = (old / 'project/build_full.tcl').read_text()
assert sha(old / 'project/build_full.tcl') == manifest['build_tcl_sha256']
assert original.count('pnr -gplace_seed 73 ') == 1
assert '-plc_decongestion' not in original and '-dump_router_congestion_plot' not in original
# This is a full native build, not a reuse of a failed routed database.
relocated = original.replace(old.as_posix(), new.as_posix())
script = relocated.replace('pnr -gplace_seed 73 ',
    'pnr -plc_decongestion 4 -dump_router_congestion_plot TRUE -gplace_seed 73 ')
assert script.replace('-plc_decongestion 4 -dump_router_congestion_plot TRUE ', '') == relocated
(new / 'project').mkdir(parents=True)
shutil.copytree(old / 'sources', new / 'sources')
(new / 'build').mkdir()
(new / 'project/build_full.tcl').write_text(script, encoding='utf-8', newline='\n')
assert {p.name: sha(p) for p in (new / 'sources').iterdir()} == actual
manifest.update(build_tcl_sha256=sha(new / 'project/build_full.tcl'),
    qualified=False, hardware_accepted=False,
    physical_experiment='Default placement decongestion 1 -> 4; congestion plots enabled for observation only',
    experiment_parent=str(old), experiment_parent_manifest_sha256=sha(old / 'project/source_manifest.json'))
(new / 'project/source_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
binding = {'source_sha256': actual, 'source_identical_to_approved_merge1': True,
    'old_build_tcl_sha256': sha(old / 'project/build_full.tcl'),
    'new_build_tcl_sha256': sha(new / 'project/build_full.tcl'),
    'optimization_delta': {'plc_decongestion': {'old_documented_default': 1, 'new': 4}},
    'observation_delta': {'dump_router_congestion_plot': True},
    'seeds': {'place': 73, 'route': 91}, 'timing_constraints_unchanged': True,
    'full_original_flow_retained': True, 'qualified_for_board_test': False,
    'design_note_sha256': sha(ROOT / 'review_phy/DECONGESTION_EXPERIMENT.md')}
(new / 'experiment_binding.json').write_text(json.dumps(binding, indent=2) + '\n', encoding='utf-8')
print(new)
