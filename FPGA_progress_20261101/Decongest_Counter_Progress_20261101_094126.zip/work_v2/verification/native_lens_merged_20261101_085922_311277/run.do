onerror {quit -code 2 -f}
onbreak {resume}
onfinish stop
run -all
quit -f
