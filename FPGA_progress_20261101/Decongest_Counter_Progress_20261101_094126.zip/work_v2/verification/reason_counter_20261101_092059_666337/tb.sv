
`timescale 1ns/1ps
module tb_reason_counter;
 reg clk=0,rst=1,start=0;reg[31:0]generation=0,rejected=0;reg[3:0]reason=0;
 wire[511:0]old_counts,new_counts;wire[31:0]old_generation,new_generation;
 reason_old original(clk,rst,start,generation,rejected,reason,old_generation,old_counts);
 reason_new proposed(clk,rst,start,generation,rejected,reason,new_generation,new_counts);
 reg[511:0]expected=0;reg[31:0]expected_generation=0,previous=0,seed=32'h38b17543;
 integer cycles=0,increments=0,wraps=0,reset_checks=0,index,k;
 always #5 clk=~clk;
 task verify;
 begin
  if(old_counts!==expected||new_counts!==expected||old_generation!==expected_generation||new_generation!==expected_generation)
   $fatal(1,"counter mismatch cycle=%0d reason=%0d",cycles,reason);
 end endtask
 task tick;
 reg[31:0]prior_count;
 begin
  @(posedge clk);
  if(!rst)begin expected=0;previous=0;expected_generation=0;end
  else begin
   if(start)expected_generation=generation;
   if(rejected!=previous)begin
    prior_count=expected[reason*32+:32];
    expected[reason*32+:32]=prior_count+32'd1;
    if(prior_count==32'hffffffff)wraps=wraps+1;
    increments=increments+1;
   end
   previous=rejected;
  end
  #1;cycles=cycles+1;verify;
  @(negedge clk);
 end endtask
 task reset_now;
 begin
  #1;rst=0;#1;expected=0;previous=0;expected_generation=0;verify;
  reset_checks=reset_checks+1;tick;#1;rst=1;
 end endtask
 task seed_rollover;
 begin
  expected={16{32'hffffffff}};
  original.processor_reason_counts=expected;proposed.processor_reason_counts=expected;
  #1;verify;
 end endtask
 initial begin
  #1;reset_now;
  // Every reason, repeated values, adjacent reasons, and simultaneous start.
  for(index=0;index<16;index=index+1)begin
   reason=index;rejected=rejected+1;start=1;generation=32'h10203040+index;tick;
   start=0;tick;reason=15-index;tick;
  end
  // Every word must wrap modulo32 without modifying any other word.
  seed_rollover;
  for(index=0;index<16;index=index+1)begin reason=index;rejected=rejected+1;tick;end
  // A jump in the upstream total increments once, not by the jump amount.
  reason=7;rejected=rejected+99;tick;tick;
  rejected=32'hffffffff;reason=3;tick;rejected=0;tick;
  reset_now;rejected=0;start=0;tick;
  for(k=0;k<4096;k=k+1)begin
   seed=seed^(seed<<13);seed=seed^(seed>>17);seed=seed^(seed<<5);
   reason=seed[3:0];start=seed[5];generation=seed;
   if(seed[6:4]!=0)rejected=rejected+{28'd0,seed[11:8]}+1;
   if(k==1024||k==3072)reset_now;
   tick;
  end
  if(wraps!=16||reset_checks!=4||increments<3000)$fatal(1,"coverage incomplete");
  $display("REASON_COUNTER_PASS cycles=%0d increments=%0d rollover_words=%0d async_resets=%0d",cycles,increments,wraps,reset_checks);
  $finish;
 end
endmodule
