module reason_new(input proc_clk,common_rst_n,start,input[31:0]descriptor_generation,processed_rejected,input[3:0]mode_reason,output[31:0]processing_frame_id,output[511:0]counts);
reg[511:0]processor_reason_counts;assign counts=processor_reason_counts;
 reg[31:0]processing_generation,previous_rejected;
 assign processing_frame_id=processing_generation;
 always @(posedge proc_clk or negedge common_rst_n)begin
 if(!common_rst_n)begin processing_generation<=0;previous_rejected<=0;processor_reason_counts<=0;end
 else begin
 if(start)processing_generation<=descriptor_generation;
 previous_rejected<=processed_rejected;
 if(processed_rejected!=previous_rejected)begin
 case(mode_reason)
 4'd0:processor_reason_counts[0+:32]<=processor_reason_counts[0+:32]+1'b1;
 4'd1:processor_reason_counts[32+:32]<=processor_reason_counts[32+:32]+1'b1;
 4'd2:processor_reason_counts[64+:32]<=processor_reason_counts[64+:32]+1'b1;
 4'd3:processor_reason_counts[96+:32]<=processor_reason_counts[96+:32]+1'b1;
 4'd4:processor_reason_counts[128+:32]<=processor_reason_counts[128+:32]+1'b1;
 4'd5:processor_reason_counts[160+:32]<=processor_reason_counts[160+:32]+1'b1;
 4'd6:processor_reason_counts[192+:32]<=processor_reason_counts[192+:32]+1'b1;
 4'd7:processor_reason_counts[224+:32]<=processor_reason_counts[224+:32]+1'b1;
 4'd8:processor_reason_counts[256+:32]<=processor_reason_counts[256+:32]+1'b1;
 4'd9:processor_reason_counts[288+:32]<=processor_reason_counts[288+:32]+1'b1;
 4'd10:processor_reason_counts[320+:32]<=processor_reason_counts[320+:32]+1'b1;
 4'd11:processor_reason_counts[352+:32]<=processor_reason_counts[352+:32]+1'b1;
 4'd12:processor_reason_counts[384+:32]<=processor_reason_counts[384+:32]+1'b1;
 4'd13:processor_reason_counts[416+:32]<=processor_reason_counts[416+:32]+1'b1;
 4'd14:processor_reason_counts[448+:32]<=processor_reason_counts[448+:32]+1'b1;
 4'd15:processor_reason_counts[480+:32]<=processor_reason_counts[480+:32]+1'b1;
 endcase
 end
 end end

endmodule
