onerror {quit -code 2 -f}
onbreak {quit -code 3 -f}
onfinish exit
run -all
quit -f
