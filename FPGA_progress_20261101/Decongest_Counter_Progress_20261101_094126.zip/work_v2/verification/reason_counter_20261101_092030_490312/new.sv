module reason_new(input proc_clk,common_rst_n,start,input[31:0]descriptor_generation,processed_rejected,input[3:0]mode_reason,output[31:0]processing_frame_id,output[511:0]counts);
reg[511:0]processor_reason_counts;assign counts=processor_reason_counts;
 reg[31:0]processing_generation,previous_rejected;
 assign processing_frame_id=processing_generation;
 always @(posedge proc_clk or negedge common_rst_n)begin
 if(!common_rst_n)begin processing_generation<=0;previous_rejected<=0;processor_reason_counts<=0;end
 else begin
 if(start)processing_generation<=descriptor_generation;
 previous_rejected<=processed_rejected;
 if(processed_rejected!=previous_rejected)
 processor_reason_counts[mode_reason*32+:32]<=processor_reason_counts[mode_reason*32+:32]+1'b1;
 end end

endmodule
