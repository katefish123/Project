"""Strict association between actual synthesis proof and physical-build origin."""
from pathlib import Path
import hashlib, json

def resolve_native_leaf(build, legacy_directory):
 build=Path(build).resolve(); folder=Path(legacy_directory).resolve()
 receipt=build/'native_leaf_receipt.json'
 sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 if receipt.is_file():
  record=json.loads(receipt.read_text(encoding='utf-8-sig'))
  folder=Path(record['directory']).resolve()
  for name in ('inputs','verification'):
   p=folder/(name+'.json')
   if not p.is_file() or sha(p)!=record[name+'_sha256']:
    raise ValueError('Native leaf receipt drift: '+name)
 inputs=json.loads((folder/'inputs.json').read_text(encoding='utf-8-sig'))
 expected=build/'synthesize/video_correct_ddr_top_syn.vm'
 if Path(inputs['full_netlist']).resolve()!=expected:
  raise ValueError('Native leaf belongs to another build')
 if not expected.is_file() or sha(expected)!=inputs['full_netlist_sha256']:
  raise ValueError('Native leaf full netlist drift')
 return folder
