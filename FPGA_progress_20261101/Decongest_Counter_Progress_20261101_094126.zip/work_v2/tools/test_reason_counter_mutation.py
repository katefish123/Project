"""Check that the real counter regression rejects a deliberately wrong lane."""
from pathlib import Path
import datetime, subprocess, json, sys
R=Path(__file__).resolve().parents[2]
src=R/'work_v2/candidate_reason_decode1/sources/video_correct_ddr_continuous_core.v'
out=R/'work_v2/verification'/('reason_counter_deliberate_mutant_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
out.mkdir()
text=src.read_text()
old="4'd15:processor_reason_counts[480+:32]<=processor_reason_counts[480+:32]+1'b1;"
new="4'd15:processor_reason_counts[448+:32]<=processor_reason_counts[480+:32]+1'b1;"
assert text.count(old)==1
bad=out/src.name;bad.write_text(text.replace(old,new),encoding='utf-8',newline='\n')
args=[sys.executable,str(R/'work_v2/tools/check_reason_counter_equivalence.py'),'--reference',
 str(R/'work_v2/candidate_team_merge1/sources'/src.name),'--candidate',str(bad)]
result=subprocess.run(args,capture_output=True,text=True)
(out/'expected_rejection.log').write_text(result.stdout+result.stderr,encoding='utf-8')
assert result.returncode!=0 and 'counter mismatch' in result.stdout,result.stdout
(out/'mutation_check.json').write_text(json.dumps({'purpose':__doc__,'argv':args,
 'exit_code':result.returncode,'expected_rejection':True,'production_sources_changed':False},indent=2)+'\n',encoding='utf-8')
print('Deliberate wrong-lane mutation rejected; evidence '+str(out))
