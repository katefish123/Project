"""The chosen synthesized-leaf proof must belong to this physical build."""
from pathlib import Path
import tempfile, json, hashlib, unittest
from native_leaf_binding import resolve_native_leaf

class BindingTests(unittest.TestCase):
 def test_current_build_and_drift(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d); build=root/'current'; proof=root/'proof'; proof.mkdir()
   (build/'synthesize').mkdir(parents=True)
   net=build/'synthesize/video_correct_ddr_top_syn.vm'; net.write_bytes(b'current netlist')
   inputs=proof/'inputs.json'
   inputs.write_text(json.dumps({'full_netlist':str(net),'full_netlist_sha256':hashlib.sha256(net.read_bytes()).hexdigest()}))
   self.assertEqual(resolve_native_leaf(build,proof),proof)
   net.write_bytes(b'changed')
   with self.assertRaisesRegex(ValueError,'netlist drift'):resolve_native_leaf(build,proof)

 def test_previous_build_cannot_qualify_new_build(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d); proof=root/'proof'; proof.mkdir()
   (proof/'inputs.json').write_text(json.dumps({'full_netlist':str(root/'old/synthesize/video_correct_ddr_top_syn.vm'),'full_netlist_sha256':'old'}))
   with self.assertRaisesRegex(ValueError,'another build'):resolve_native_leaf(root/'new',proof)

 def test_explicit_receipt_hash_is_required(self):
  with tempfile.TemporaryDirectory() as d:
   build=Path(d); proof=build/'proof'; proof.mkdir()
   (build/'native_leaf_receipt.json').write_text(json.dumps({'directory':str(proof),'inputs_sha256':'wrong','verification_sha256':'wrong'}))
   (proof/'inputs.json').write_text('{}');(proof/'verification.json').write_text('{}')
   with self.assertRaisesRegex(ValueError,'receipt drift'):resolve_native_leaf(build,proof)

if __name__=='__main__':unittest.main()
