"""Read-only evidence gate by default; --emit only after actual same-DB success."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
if not __debug__:raise RuntimeError('Optimized verification forbidden')
import argparse,hashlib,json,re
import audit_resume_native as audit
from verify_video_receipt import verify
from finish_resume_physical import selected
from native_leaf_binding import resolve_native_leaf
ROOT=Path(__file__).resolve().parents[1];R=ROOT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def require(ok,msg):
 if not ok:raise ValueError(msg)

def qualify(candidate,physical):
 current=audit.source_identity(candidate);artifacts={};proofs={}
 def bind(p):
  p=Path(p);require(p.is_file(),'Missing evidence '+str(p));artifacts[str(p.resolve())]=sha(p);return sha(p)
 def tree(folder):
  for p in folder.rglob('*'):
   if p.is_file() and not any(n in ('work','__pycache__') for n in p.relative_to(folder).parts):bind(p)
 require(read(candidate/'project/source_manifest.json')['source_sha256']==current,'Source manifest mismatch')
 for p in (candidate/'sources').iterdir():bind(p)
 for p in (candidate/'project').iterdir():
  if p.is_file():bind(p)
 experiment=candidate/'experiment_binding.json'
 if experiment.is_file():
  exp=read(experiment);bind(experiment)
  require(exp['source_sha256']==current and exp['source_identical_to_approved_merge1'] is True,'Experiment source identity drift')
  require(bind(candidate/'project/build_full.tcl')==exp['new_build_tcl_sha256'],'Experiment recipe drift')
  require(bind(R/'review_phy/DECONGESTION_EXPERIMENT.md')==exp['design_note_sha256'],'Experiment design note drift')
  bind(R/'prepare_decongest4.py')
 bind(R/'team_merge_review/approved_merge1_sources.json')
 suite=read(R/'merge_video_suite_execution.json');require(suite['status']=='all_five_processes_passed','Video matrix incomplete')
 bind(R/'merge_video_suite_execution.json');cases=set()
 for run in suite['runs']:
  case=run['case'];require(case not in cases,'Repeated scenario');cases.add(case)
  if case=='ninety':folder=Path(run['verification']).parent;require(bind(folder/'verification.json')==run['sha256'],'First video receipt drift')
  else:
   require(run['exit_code']==0 and bind(Path(run['log']))==run['log_sha256'],'Video process failure/drift')
   folder=Path(re.search(r'ARCHIVED_VIDEO (.+)',Path(run['log']).read_text()).group(1).strip())
  checked=verify(folder,current,case);proofs['video_'+case]={'directory':str(folder),'freshness':checked['freshness'],'pixels':checked['pixels']}
  for n,h in checked['golden_anchor_sha256'].items():require(bind(Path(n))==h,'Golden anchor drift')
  tree(folder)
 require(cases=={'zero','ninety','switch','raw','nearest'},'Missing video scenarios')
 component_defs=[('affine','affine_lens_20261101_010235_075592','AFFINE_LENS_PASS','check_affine_lens.py'),
  ('control','control_pipeline_20261101_010241_510553','CONTROL_PIPELINE_PASS','check_control_pipeline.py'),
  ('native_leaf','native_lens_merged_20261031_231508_799686','NATIVE_LENS_PASS','check_native_lens_merged.py')]
 for role,name,token,checker in component_defs:
  folder=ROOT/'verification'/name
  if role=='native_leaf':
   require((physical/'input_binding.json').is_file(),'Independent physical proof not yet complete')
   native_build=Path(read(physical/'input_binding.json')['upstream_build']).resolve()
   folder=resolve_native_leaf(native_build,folder)
   if (native_build/'native_leaf_receipt.json').is_file():bind(native_build/'native_leaf_receipt.json')
  v=read(folder/'verification.json');i=read(folder/'inputs.json')
  require(v['passed'] is True,'Component failed '+role)
  require(bind(folder/'inputs.json')==v.get('inputs_sha256',v.get('input_manifest_sha256')),'Component inputs drift')
  require(bind(folder/'simulation.log')==v['simulation_log_sha256'],'Component log drift')
  if 'compile_log_sha256' in v:require(bind(folder/'compile.log')==v['compile_log_sha256'],'Component compile-log drift')
  for key,name in [('host_sha256','send_lens_angle.py'),('golden_checker_sha256','check_affine_lens.py')]:
   if key in i:require(bind(ROOT/'tools'/name)==i[key],'Component tool drift '+name)
  text=(folder/'simulation.log').read_text(errors='replace')+(folder/'compile.log').read_text(errors='replace')
  require(token in text and not re.search(r'\*\* (?:Fatal|Error|Warning)(?:\s|:)',text),'Component errors/warnings')
  require(bind(ROOT/'tools'/checker)==i['checker_sha256'],'Component checker drift')
  if role in ('affine','control'):
   strict=read(folder/'strict_execution_receipt.json');bind(folder/'strict_execution_receipt.json')
   require(strict['passed'] is True and strict['producer_exit_code']==0 and strict['verification_sha256']==bind(folder/'verification.json'),'No strict component success')
   require(strict['producer_sha256']==i['checker_sha256'] and strict['wrapper_sha256']==bind(ROOT/'tools/strict_component_runner.py'),'Strict producer/wrapper drift')
   require(len(strict['records'])==4,'Missing strict child executions')
   for e in strict['records']:require(e['exit_code']==0 and bind(Path(e['log_path']))==e['log_sha256'],'Strict child failure/drift')
  if 'calibration_sha256' in i:
   require(bind(ROOT/'calibration/r50_18mm_hdmi_trial.json')==i['calibration_sha256'],'Calibration profile drift')
  bench_name={'affine':'tb_affine_lens.sv','control':'tb_control_pipeline.sv','native_leaf':'tb_native_lens.sv'}[role]
  require(bind(folder/bench_name)==i.get('bench_sha256',i.get('testbench_sha256')),'Component testbench drift')
  source=i.get('source_sha256',i.get('input_sha256',{}))
  for n,h in source.items():
   p=Path(n)
   if p.name in current:require(h==current[p.name],'Wrong component source '+p.name)
   if n in current:p=candidate/'sources'/n
   require(bind(p)==h,'Component external input drift')
  for key in ('snapshot_sha256','vector_sha256','vectors_sha256','golden_reference_sha256','frozen_comparator_inputs_sha256','frozen_comparator_generated_sha256'):
   for n,h in i.get(key,{}).items():require(bind(Path(n))==h,'Component bound-file drift '+n)
  for n,h in i.get('fixtures',{}).items():require(bind(folder/n)==h,'Component fixture drift')
  if role=='native_leaf':
   require(bind(folder/'actual_lens.vm')==i['extracted_sha256'],'Extracted actual netlist drift')
   for name,h in i['primitive_sha256'].items():
    require(bind(Path('D:/softwares/PDS/PDS_2022.2-SP6.4/arch/vendor/pango/verilog/simulation')/(name+'.v'))==h,'Primitive model drift')
   require(source==current and bind(Path(i['full_netlist']))==i['full_netlist_sha256'],'Wrong synthesized source/netlist')
   ex=read(folder/'execution.json');require(bind(folder/'execution.json')==v['execution_sha256'] and len(ex)==4,'Missing native execution')
   for e in ex:require(e['exit_code']==0 and bind(folder/e['log'])==e['log_sha256'],'Native execution failure')
  proofs[role]={'directory':str(folder),'verification_sha256':bind(folder/'verification.json')};tree(folder)
 # Actual independent cache and bridge tests with original V2 reference.
 for role,folder in [('cache',R/'cache_team_validation/candidate_20261031_223800_715884'),
  ('bridge',R/'bridge_team_validation/extended_20261031_223806_090627/verification/bridge_decode_20261031_223806_099746')]:
  v=read(folder/'verification.json');i=read(folder/'inputs.json');require(v['passed'] is True,'Component failed '+role)
  require(bind(folder/'inputs.json')==v['inputs_sha256'],'Unit inputs drift')
  if role=='cache':
   ex=v['records']
   for j,e in enumerate(ex):require(e['exit_code']==0 and bind(folder/f'step{j}.log')==e['log_sha256'],'Cache process failure')
   for n,h in i['local_sha256'].items():require(bind(folder/n)==h,'Cache snapshot drift')
   for n,h in i['production_sha256'].items():require(bind(Path(n))==h,'Cache production source drift')
   require(current['ddr_quad_tile_cache.v'] in i['production_sha256'].values(),'Wrong merged cache')
  else:
   ee=read(folder/'execution.json');require(bind(folder/'execution.json')==v['execution_sha256'],'Bridge execution drift')
   ex=ee['records']
   for e in ex:require(e['exit_code']==0 and bind(folder/e['log'])==e['log_sha256'],'Bridge process failure')
   for n,h in i['source_sha256'].items():require(bind(Path(n))==h==current[Path(n).name],'Bridge source drift')
   require(bind(Path(i['reference_path']))==i['reference_sha256'],'Bridge reference drift')
   require(bind(folder/'tb_bridge.sv')==i['testbench_sha256'],'Bridge bench drift')
   for n,h in i['fixtures'].items():require(bind(folder/n)==h,'Bridge fixture drift')
  require(len(ex)==4,'Missing unit processes');tree(folder);proofs[role]={'directory':str(folder),'verification_sha256':bind(folder/'verification.json')}
  logs='\n'.join(p.read_text(errors='replace') for p in folder.glob('*.log'))
  require('_PASS' in logs and not re.search(r'\*\* (?:Fatal|Error|Warning)(?:\s|:)',logs),'Unit failure/warning')
 # Nothing may be emitted before the actual independent physical proof exists.
 require((physical/'verification.json').is_file(),'Independent physical proof not yet complete')
 f=read(physical/'verification.json');b=read(physical/'input_binding.json')
 require(f['passed'] and f['fresh_direct_worker_report'] and f['same_explicit_db_for_sta_and_bitgen'],'No physical qualification')
 require(b['source_sha256']==current and bind(candidate/'project/source_manifest.json')==b['source_manifest_sha256'],'Physical source drift')
 require(bind(physical/'input_binding.json')==f['input_binding_sha256'],'Physical binding drift')
 processes=read(physical/'processes.json');require(bind(physical/'processes.json')==f['processes_sha256'] and len(processes)==2,'Physical execution drift')
 for e in processes:require(e['exit_code']==0 and bind(physical/e['log'])==e['log_sha256'],'Physical process failure')
 db=Path(b['explicit_db']);require(bind(db)==b['explicit_db_sha256'],'Routed DB drift')
 project=physical/'Independent_V2.pds'
 require(bind(physical/'finish.tcl')==b['finish_tcl_sha256'],'Independent recipe drift')
 require(bind(physical/'project_before_worker.pds')==f['project_before_worker_sha256'] and bind(project)==f['project_after_worker_sha256'],'Worker project drift')
 for command in ('cmd_report_post_pnr_timing','cmd_gen_bitstream'):
  require(selected(project,command,physical)==db.resolve(),'Selected physical DB differs')
  require(selected(physical/'project_before_worker.pds',command,physical)==db.resolve(),'Pre-worker DB differs')
 tool='D:/softwares/PDS/PDS_2022.2-SP6.4/bin/pds_shell.exe'
 require(processes[0]['argv']==[tool,'-project_name','Independent_V2','-work_dir',physical.as_posix(),'-file',(physical/'finish.tcl').as_posix()],'Unexpected independent shell command')
 require(processes[1]['argv']==[tool,'-action','report_timing','-project_file',project.as_posix()],'Unexpected direct STA command')
 require('Report timing is finished successfully.' in (physical/'worker.log').read_text(errors='replace'),'No direct worker completion')
 require('Process "Generate Bitstream" done.' in (physical/'shell.log').read_text(errors='replace'),'No independent bitgen completion')
 for n,entry in b['copies'].items():require(bind(Path(n))==entry['sha256']==bind(Path(entry['copy'])),'Physical recipe input drift')
 timing=audit.timing(physical/'video_correct_ddr_top.rtr')
 up=Path(b['upstream_route']);io=audit.io(up/'place_route/video_correct_ddr_top.prr',up/'place_route/video_correct_ddr_top_prr.prt')
 chosen={}
 bits=list((physical/'generate_bitstream').glob('*.sbit'));masks=list((physical/'generate_bitstream').glob('*.smsk'))
 require(len(bits)==len(masks)==1 and bits[0].stem==masks[0].stem,'No unique current image/mask pair')
 expected_artifacts={'sbit':bits[0],'smsk':masks[0],'physical_database':db,'report':physical/'video_correct_ddr_top.rtr','project':project}
 for name,item in f['artifacts'].items():
  require(bind(Path(item['path']))==item['sha256'],'Selected physical artifact drift')
  role='sbit' if name.endswith('.sbit') else 'smsk' if name.endswith('.smsk') else 'physical_database' if name.endswith('.adf') else 'report' if name.endswith('.rtr') else 'project'
  require(role not in chosen and Path(item['path']).resolve()==expected_artifacts[role].resolve(),'Physical artifact belongs to another run')
  require(item['bytes']==Path(item['path']).stat().st_size,'Artifact size drift')
  chosen[role]=item
 require(set(chosen)==set(expected_artifacts),'Incomplete selected artifacts')
 require(bits[0].stat().st_size>1024*1024 and masks[0].stat().st_size>1024*1024,'Truncated programming pair')
 tree(physical)
 for p in (audit.COVERAGE,audit.ARCHIVE/'native_audit.json',audit.ARCHIVE/'place_route/video_correct_ddr_top.prr',audit.ARCHIVE/'place_route/video_correct_ddr_top_prr.prt'):bind(p)
 for p in (ROOT/'tools').glob('*.py'):bind(p)
 return {'qualified_for_board_test':True,'hardware_accepted':False,'target_fps':30,'resolution':[1920,1080],
  'scope':'Brown k1/k2/p1/p2 + PC affine; one resample; full native resolution',
  'source_sha256':current,'proofs':proofs,'timing':timing,'io':io,'artifacts':chosen,'artifact_sha256':artifacts,
  'qualifier_sha256':sha(Path(__file__)),'old_20261029_full_baseline_integrity_reproduced':False,
  'optical_calibration_independently_accepted':False,
  'watchdog_policy':'Inherited F_CMD/F_WAIT deadline/type boundary unchanged; this pipeline repair does not claim recovery or unbounded preaccept-stall immunity.',
  'remaining':'Actual board30fps/host commands and independent optics/latency verification'}

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--physical',type=Path,required=True);ap.add_argument('--emit',action='store_true');a=ap.parse_args()
 q=qualify(a.candidate.resolve(),a.physical.resolve())
 if a.emit:
  p=a.candidate/'candidate_qualification.json';require(not p.exists(),'Refusing qualification overwrite')
  p.write_text(json.dumps(q,indent=2),encoding='utf-8')
 print(json.dumps({'qualified_for_board_test':True,'hardware_accepted':False,'minimum_slack_ns':q['timing']['minimum_slack_ns'],'pads':q['io']['pad_count']},indent=2))
if __name__=='__main__':main()
