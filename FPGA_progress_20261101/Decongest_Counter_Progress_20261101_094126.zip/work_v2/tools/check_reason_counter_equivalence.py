"""Compare exact source-extracted diagnostic counter blocks, not whole video/PNR."""
from pathlib import Path
import argparse, datetime, hashlib, json, re, shutil, subprocess

ROOT=Path(__file__).resolve().parents[1]
TOOLS=Path('D:/softwares/modelsim/win64')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def extract(source,name):
 text=source.read_text()
 start=text.index(' reg[31:0]processing_generation,previous_rejected;')
 end=text.index(' c_frame_mode_controller modes(',start)
 block=text[start:end]
 return ('module '+name+'(input proc_clk,common_rst_n,start,input[31:0]descriptor_generation,processed_rejected,'
  'input[3:0]mode_reason,output[31:0]processing_frame_id,output[511:0]counts);\n'
  'reg[511:0]processor_reason_counts;assign counts=processor_reason_counts;\n'+block+'\nendmodule\n'),block

BENCH=r'''
`timescale 1ns/1ps
module tb_reason_counter;
 reg clk=0,rst=1,start=0;reg[31:0]generation=0,rejected=0;reg[3:0]reason=0;
 wire[511:0]old_counts,new_counts;wire[31:0]old_generation,new_generation;
 reason_old original(clk,rst,start,generation,rejected,reason,old_generation,old_counts);
 reason_new proposed(clk,rst,start,generation,rejected,reason,new_generation,new_counts);
 reg[511:0]expected=0;reg[31:0]expected_generation=0,previous=0,seed=32'h38b17543;
 integer cycles=0,increments=0,wraps=0,reset_checks=0,index,k;
 always #5 clk=~clk;
 task verify;
 begin
  if(old_counts!==expected||new_counts!==expected||old_generation!==expected_generation||new_generation!==expected_generation)
   $fatal(1,"counter mismatch cycle=%0d reason=%0d",cycles,reason);
 end endtask
 task tick;
 reg[31:0]prior_count;
 begin
  @(posedge clk);
  if(!rst)begin expected=0;previous=0;expected_generation=0;end
  else begin
   if(start)expected_generation=generation;
   if(rejected!=previous)begin
    prior_count=expected[reason*32+:32];
    expected[reason*32+:32]=prior_count+32'd1;
    if(prior_count==32'hffffffff)wraps=wraps+1;
    increments=increments+1;
   end
   previous=rejected;
  end
  #1;cycles=cycles+1;verify;
  @(negedge clk);
 end endtask
 task reset_now;
 begin
  #1;rst=0;#1;expected=0;previous=0;expected_generation=0;verify;
  reset_checks=reset_checks+1;tick;#1;rst=1;
 end endtask
 task seed_rollover;
 begin
  expected={16{32'hffffffff}};
  original.processor_reason_counts=expected;proposed.processor_reason_counts=expected;
  #1;verify;
 end endtask
 initial begin
  #1;reset_now;
  // Every reason, repeated values, adjacent reasons, and simultaneous start.
  for(index=0;index<16;index=index+1)begin
   reason=index;rejected=rejected+1;start=1;generation=32'h10203040+index;tick;
   start=0;tick;reason=15-index;tick;
  end
  // Every word must wrap modulo32 without modifying any other word.
  seed_rollover;
  for(index=0;index<16;index=index+1)begin reason=index;rejected=rejected+1;tick;end
  // A jump in the upstream total increments once, not by the jump amount.
  reason=7;rejected=rejected+99;tick;tick;
  rejected=32'hffffffff;reason=3;tick;rejected=0;tick;
  reset_now;rejected=0;start=0;tick;
  for(k=0;k<4096;k=k+1)begin
   seed=seed^(seed<<13);seed=seed^(seed>>17);seed=seed^(seed<<5);
   reason=seed[3:0];start=seed[5];generation=seed;
   if(seed[6:4]!=0)rejected=rejected+{28'd0,seed[11:8]}+1;
   if(k==1024||k==3072)reset_now;
   tick;
  end
  if(wraps!=16||reset_checks!=4||increments<3000)$fatal(1,"coverage incomplete");
  $display("REASON_COUNTER_PASS cycles=%0d increments=%0d rollover_words=%0d async_resets=%0d",cycles,increments,wraps,reset_checks);
  $finish;
 end
endmodule
'''

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--reference',type=Path,required=True);ap.add_argument('--candidate',type=Path,required=True)
 a=ap.parse_args();reference=a.reference.resolve();candidate=a.candidate.resolve()
 # Read and extract before creating any output, so missing/unknown schema fails closed.
 old,oldblock=extract(reference,'reason_old');new,newblock=extract(candidate,'reason_new')
 inputs={str(reference):sha(reference),str(candidate):sha(candidate)}
 out=ROOT/'verification'/('reason_counter_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'));out.mkdir()
 for name,text in [('old.sv',old),('new.sv',new),('tb.sv',BENCH)]:
  (out/name).write_text(text,encoding='utf-8',newline='\n')
 ini=out/'modelsim.ini';shutil.copyfile(TOOLS.parent/'modelsim.ini',ini)
 script=out/'run.do';script.write_text('onerror {quit -code 2 -f}\nonbreak {quit -code 3 -f}\nonfinish exit\nrun -all\nquit -f\n')
 record={'source_sha256':inputs,'checker_sha256':sha(Path(__file__)),
  'extracted_block_sha256':{'old':hashlib.sha256(oldblock.encode()).hexdigest(),'new':hashlib.sha256(newblock.encode()).hexdigest()},
  'bench_sha256':sha(out/'tb.sv'),'scope':__doc__}
 (out/'inputs.json').write_text(json.dumps(record,indent=2)+'\n')
 argv=[[TOOLS/'vlib.exe',out/'work'],[TOOLS/'vmap.exe','-modelsimini',ini,'work',out/'work'],
  [TOOLS/'vlog.exe','-sv','-modelsimini',ini,out/'old.sv',out/'new.sv',out/'tb.sv'],
  [TOOLS/'vsim.exe','-c','-modelsimini',ini,'work.tb_reason_counter','-do',script]]
 executions=[]
 print('REASON_COUNTER '+str(out),flush=True)
 for n,args in enumerate(argv):
  args=[v.as_posix() if isinstance(v,Path) else str(v) for v in args]
  log=out/f'step{n}.log'
  with log.open('w') as f:result=subprocess.run(args,cwd=out,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
  executions.append({'argv':args,'exit_code':result.returncode,'log':log.name,'log_sha256':sha(log)})
  (out/'execution.json').write_text(json.dumps(executions,indent=2)+'\n')
  if result.returncode:break
 logs='\n'.join(p.read_text(errors='replace') for p in out.glob('step*.log'))
 passed=(len(executions)==4 and all(x['exit_code']==0 for x in executions)
  and 'REASON_COUNTER_PASS' in logs and not re.search(r'\*\* (?:Error|Fatal|Warning)(?:\s|:)',logs)
  and all(sha(Path(p))==h for p,h in inputs.items()))
 v={'passed':passed,'hardware_accessed':False,'whole_video_proof':False,'physical_proof':False,
  'inputs_sha256':sha(out/'inputs.json'),'execution_sha256':sha(out/'execution.json'),
  'observations':[line for line in logs.splitlines() if '_PASS' in line or '** Error' in line or '** Fatal' in line]}
 (out/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
 raise SystemExit(0 if passed else 1)

if __name__=='__main__':main()
