"""One-time source/state seal; no EDA, hardware, quota API or Git operations."""
from pathlib import Path
import json, hashlib, re, datetime
R=Path(__file__).resolve().parent
stamp='20261101_094126'
out=R/'review_phy'/('pause_'+stamp)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reference=json.loads(Path('D:/FPGA/deliveries/HostAngle_Progress_20261101/snapshot_manifest.json').read_text(encoding='utf-8-sig'))
baseline={Path(f['path']).name:f['sha256'] for f in reference['files'] if f['path'].startswith('work_v2/candidate_team_merge1/sources/')}
assert len(baseline)==151
primary=R/'work_v2/candidate_team_decongest4'
proposal=R/'work_v2/candidate_reason_decode1'
sources=lambda c:{p.name:sha(p) for p in (c/'sources').iterdir() if p.is_file()}
a=sources(primary);b=sources(proposal)
assert a==baseline
changed={n:{'old':baseline[n],'new':b[n]} for n in b if b[n]!=baseline[n]}
assert set(b)==set(baseline) and set(changed)=={'video_correct_ddr_continuous_core.v'}
assert b==json.loads((proposal/'project/source_manifest.json').read_text())['source_sha256']
build=primary/'build/pds_20261101_085234_854638'
copies={}
for rel,name in [('build.log','active_build_log_prefix.log'),
 ('offline_build_inputs.json','offline_build_inputs_snapshot.json'),
 ('Lens_Angle_1080p30.pds','active_project_snapshot.pds'),
 ('place_route/video_correct_ddr_top.prr','placement_report_snapshot.prr'),
 ('place_route/video_correct_ddr_top_prr.prt','placement_pinout_snapshot.prt'),
 ('placement_io_audit.json','placement_io_audit_snapshot.json')]:
 src=build/rel;dest=out/name;data=src.read_bytes();dest.write_bytes(data)
 copies[rel]={'origin':str(src),'snapshot':str(dest),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
log=(out/'active_build_log_prefix.log').read_text(errors='replace')
rows=list(re.finditer(r'Unrouted nets (\d+) at the end of iteration (\d+)\.\s*route iteration \d+, CPU time elapsed ([\d.]+)',log))
last=rows[-1]
record=json.loads((out/'offline_build_inputs_snapshot.json').read_text())
obs=json.loads((out/'processes.json').read_text(encoding='utf-8-sig'))
important=[
 'CONTINUE.md','RESUME_STATE_20261101.json','QUOTA_STOP_'+stamp+'.json',
 'prepare_decongest4.py','prepare_reason_decode.py','seal_quota_'+stamp+'.py',
 'work_v2/tools/native_leaf_binding.py','work_v2/tools/test_native_leaf_binding.py',
 'work_v2/tools/qualify_merged.py','work_v2/tools/check_reason_counter_equivalence.py',
 'work_v2/tools/test_reason_counter_mutation.py',
 'work_v2/candidate_team_decongest4/project','work_v2/candidate_team_decongest4/experiment_binding.json',
 'work_v2/candidate_team_decongest4/build/pds_20261101_085234_854638/native_leaf_receipt.json',
 'work_v2/candidate_team_decongest4/build/pds_20261101_085234_854638/synthesize/video_correct_ddr_top_syn.vm',
 'work_v2/candidate_reason_decode1/project','work_v2/candidate_reason_decode1/reason_decode_proposal.json',
 'work_v2/candidate_reason_decode1/counter_decode.diff','work_v2/candidate_reason_decode1/counter_equivalence_receipt.json',
 'work_v2/candidate_reason_decode1/sources/video_correct_ddr_continuous_core.v',
 'work_v2/verification/native_lens_merged_20261101_085922_311277',
 'work_v2/verification/reason_counter_20261101_092030_490312',
 'work_v2/verification/reason_counter_20261101_092059_666337',
 'work_v2/verification/reason_counter_20261101_092154_164561',
 'work_v2/verification/reason_counter_20261101_092258_920054',
 'work_v2/verification/reason_counter_deliberate_mutant_20261101_092258_571647',
 'review_phy/DECONGESTION_EXPERIMENT.md','review_phy/DECONGEST4_CONGESTION_EVIDENCE.json',
 'review_phy/DECONGEST4_ROUTE_COMPARISON.json','review_phy/REASON_COUNTER_PROPOSAL.md',
 'review_phy/pause_'+stamp,
 'work_v2/candidate_team_decongest4/build/pds_20261101_085234_854638/place_route/route_constraint_ite_1/CongestionNetInfo/CongestionNetInfo_1.txt',
 'work_v2/candidate_team_decongest4/build/pds_20261101_085234_854638/place_route/route_constraint_ite_1/CongestionNetInfo/CongestionNetInfo_4.txt',
 'work_v2/candidate_team_decongest4/build/pds_20261101_085234_854638/place_route/route_constraint_ite_1/CongestionPlot/CongestionPlot_1.txt',
 'work_v2/candidate_team_decongest4/build/pds_20261101_085234_854638/place_route/route_constraint_ite_1/CongestionPlot/CongestionPlot_4.txt']
j={'status':'paused_by_explicit_user_quota_condition','reason':'FPGA_QUOTA_STOP_'+stamp,
 'sealed_at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 'threshold_policy':'actual remaining <=10; root measured weekly7/5h18 at09:41:26',
 'optimization_stopped':True,'new_heavy_tasks_started_after_stop':False,'pds_force_terminated':False,
 'process_observation':obs,'build':str(build),'actual_build_record_status':record['status'],
 'actual_build_returncode':record.get('returncode'),
 'latest_completed_detail_iteration':int(last[2]),'unrouted_nets':int(last[1]),'last_iteration_cpu_seconds':float(last[3]),
 'uploaded_source_base_commit':'71927c2fbcce8cbc7849320d1bea72cc50d3e210',
 'prior_failure_seal_commit':'9f24d89304842e0601cbd8dbfede16f409e795e5',
 'primary_source_count':len(a),'primary_source_changed_vs_uploaded_base':[],
 'primary_source_sha256':a,'proposal_source_count':len(b),'proposal_only_changed_source':changed,
 'proposal_status':'Only local counter equivalence/negative-mutation tested; not approved by source gate, no full-video or physical proof, no PDS started',
 'frozen_observations':copies,'important_incremental_paths':important,
 'root_owned_review_directories':[p.name for p in R.glob('root_parallel_*') if p.is_dir()],
 'qualified_for_board_test':False,'hardware_accepted':False,'upload_complete_marker_allowed':False,
 'missing':['Successful complete routing and all-corner native timing/IO for primary',
 'Independent same-DB STA and paired bitstream/mask','Qualified release package and actual board acceptance',
 'For counter proposal, explicit exact-source profile approval and its full-video/physical evidence before use'],
 'recovery':'Do not start duplicate PDS or terminate existing job. It may finish naturally after this snapshot. Local map/place checkpoints remain in build path; final routed DB is not proven. Explicit user resume is required for further work. Restore unchanged primary151 and proposal150 from the uploaded base sources by these SHA maps if incremental upload omits duplicate source copies. Include the one changed proposal core. Frozen live-log prefix is diagnostic, not a completed build.',
 'exclusion_guidance':'Uploader must enumerate excluded generated DB/map/place files, ModelSim work/libraries, pycache/wave files, and large regenerable full-frame vectors. Do not exclude actual new synthesized VM or small unit proof inputs silently; they bind the native proof. Do not classify deliberately failing mutation or the first testbench compile failure as production failure or passing evidence.'}
(R/('QUOTA_STOP_'+stamp+'.json')).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
state=json.loads((R/'RESUME_STATE_20261101.json').read_text())
state.update(status='paused_by_user_quota_condition',current_pause_record='QUOTA_STOP_'+stamp+'.json',
 latest_completed_detail_iteration=int(last[2]),last_detail={'unrouted':int(last[1]),'cpu_seconds':float(last[3])},
 observed_pds_processes=[p['ProcessId'] for p in obs['processes']],next_action='Wait explicit user resume; no new optimization, heavy tasks or polling.')
(R/'RESUME_STATE_20261101.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=R/'CONTINUE.md'
prefix='## 11月1日09:43 CURRENT：<=10%条件暂停，唯一decongest4构建保留\n\n以QUOTA_STOP_20261101_094126.json为准；覆盖后文恢复状态。停止优化/新重型任务/轮询，不强杀当前PDS。根09:41实测weekly7/5h18。主候选decongest4仍精确151原源，已取得本build实际4075输入native叶子证明及144placement IO检查，但route未完/最终时序未知，不能烧录。计数器候选reason_decode1仅一core诊断改写，4169周期等价和故意错通道拒绝测试已过，未源批准/全视频/物理验证，不能混用主候选证明。\n\n冻结日志/工程/placement观察见review_phy/pause_20261101_094126。活构建可在封存后自然完成，恢复时需读取实际新终态，不信旧running字段。原map/place数据库留本机，根负责增量上传及显式排除清单，不写UPLOAD_COMPLETE。等待用户明确恢复。\n\n'
p.write_bytes(prefix.encode('utf-8')+p.read_bytes())
print(json.dumps({k:j[k] for k in ['status','actual_build_record_status','latest_completed_detail_iteration','unrouted_nets','primary_source_count','primary_source_changed_vs_uploaded_base','proposal_only_changed_source','root_owned_review_directories']},indent=2))
